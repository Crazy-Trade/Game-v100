# دستورالعمل جامع بازسازی Tycoon Simulator v2.0

## 🎯 هدف کلی

بازسازی کامل بازی با:
1. ✅ دیزاین حرفه‌ای و معتادکننده (سیستم دیزاین جدید)
2. ✅ 88 دارایی متنوع (از 32 به 88)
3. ✅ آنالیزور مالی حرفه‌ای (تکنیکال + فاندامنتال + سنتیمنت)
4. ✅ چارت ارزش کمپانی
5. ✅ بهبود عمیق معاملات (اسپات و مارجین)
6. ✅ نقشه راه رمزارز تاثیرگذار
7. ✅ عمق و داستان بازی
8. ✅ بهبود مدیریت شرکت

---

## 📚 اسناد طراحی

لطفاً قبل از شروع، اسناد زیر را مطالعه کنید:

1. **سیستم دیزاین**: `/workspace/docs/design-system-v2.md`
   - پالت رنگی جدید (نیوی عمیق + طلایی + آبی)
   - فونت‌های جدید (Samim, Yekan, Sahel)
   - کامپوننت‌ها و انیمیشن‌ها
   - اصول UI/UX و Game Design

2. **لیست دارایی‌ها**: `/workspace/docs/assets-expanded.md`
   - 88 دارایی در 5 کتگوری
   - قیمت‌گذاری و نوسان هر دارایی

3. **آنالیزور مالی**: `/workspace/docs/financial-analyzer-design.md`
   - اندیکاتورها و تحلیل تکنیکال
   - سیستم امتیازدهی و توصیه‌ها
   - UI آنالیزور

4. **دستورالعمل اصلی بازی**: `/workspace/user_input_files/دستورالعمل بازی.txt`
   - منطق اصلی بازی
   - ویژگی‌های پایه

---

## 🎨 بخش 1: بازسازی کامل UI/UX

### 1.1 پیاده‌سازی سیستم دیزاین

**فایل**: `src/styles/design-system.css` یا استفاده از Tailwind config

```css
/* رنگ‌های اصلی */
:root {
  --bg-primary: #0A0E27;
  --bg-secondary: #131832;
  --bg-tertiary: #1C2444;
  --accent-gold: #FFB800;
  --accent-blue: #00A8FF;
  --success: #00C853;
  --danger: #FF3B30;
  /* ... بقیه از design-system-v2.md */
}
```

### 1.2 فونت‌های جدید

**نکته**: فقط از فونت‌های زیر استفاده کنید، **بدون Vazir**:

```css
@import url('https://cdn.jsdelivr.net/gh/rastikerdar/samim-font@v4.0.5/dist/font-face.css');
@import url('https://cdn.jsdelivr.net/gh/rastikerdar/yekan-font@v1.0.3/dist/font-face.css');
@import url('https://cdn.jsdelivr.net/gh/rastikerdar/sahel-font@v3.4.0/dist/font-face.css');

body {
  font-family: 'Samim', 'Tahoma', sans-serif;
}
```

### 1.3 کامپوننت‌های اصلی

باید تمام کامپوننت‌های زیر را با دیزاین جدید بازسازی کنید:

1. **GameControls**: هدر بازی با اطلاعات بازیکن
2. **NewsTicker**: تیکر اخبار (همیشه نمایان)
3. **AssetList**: لیست دارایی‌ها (88 مورد)
4. **MarketChart**: چارت با کندل‌استیک و اندیکاتورها
5. **TradingPanel**: پنل معاملات (spot & margin)
6. **Portfolio**: پورتفولیو و موقعیت‌ها
7. **CompanyModule**: مدیریت شرکت
8. **Achievements**: دستاوردها
9. **Tutorial**: آموزش

### 1.4 انیمیشن‌ها

از Framer Motion برای:
- Fade in/out
- Slide animations
- Scale effects
- Stagger animations برای لیست‌ها
- Pulse برای اعلان‌ها

---

## 📊 بخش 2: گسترش دارایی‌ها (32 → 88)

### 2.1 فایل اصلی

**فایل**: `src/constants/assets.ts`

باید 88 دارایی را طبق `assets-expanded.md` اضافه کنید:
- 25 سهام
- 18 کالا
- 20 ارز
- 15 رمزارز
- 10 شاخص

### 2.2 ساختار دارایی

```typescript
interface Asset {
  id: string;
  name: string;
  symbol: string;
  category: 'stock' | 'commodity' | 'currency' | 'crypto' | 'index';
  
  // قیمت
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  
  // تاریخچه
  priceHistory: PricePoint[];
  
  // ویژگی‌ها
  volatility: number;    // 0.5-3.0
  liquidity: number;     // 0.5-2.0
  
  // آنالیز (برای آنالیزور)
  technicalScore?: number;
  fundamentalScore?: number;
  sentimentScore?: number;
  
  // فاندامنتال (اختیاری)
  marketCap?: number;
  volume24h?: number;
  peRatio?: number;
}
```

### 2.3 قیمت‌گذاری اولیه

طبق `assets-expanded.md`:
- سهام: $50-$500
- کالاها: متغیر بر اساس نوع
- ارزها: 0.5-2.0 (نسبت به USD)
- رمزارزها: $1-$50000
- شاخص‌ها: $1000-$5000

---

## 🔍 بخش 3: آنالیزور مالی حرفه‌ای

### 3.1 کامپوننت جدید: FinancialAnalyzer

**فایل**: `src/components/analyzer/FinancialAnalyzer.tsx`

باید شامل:
1. Tab Navigation: [تکنیکال] [فاندامنتال] [سنتیمنت] [توصیه‌ها]
2. خلاصه تحلیل با امتیازها
3. توصیه خرید/فروش با دلایل
4. سطوح کلیدی (حمایت/مقاومت)
5. Risk Calculator
6. گزارش عملکرد

### 3.2 اندیکاتورهای تکنیکال

**اندیکاتورهای موجود** (قبلاً پیاده‌سازی شده):
- MA20, MA50
- RSI
- MACD
- Bollinger Bands

**اندیکاتورهای جدید** (باید اضافه شوند):
- Stochastic Oscillator
- ATR (Average True Range)
- OBV (On-Balance Volume)
- Fibonacci Retracement (اختیاری)
- Ichimoku Cloud (اختیاری)

### 3.3 سیستم امتیازدهی

```typescript
function calculateTradingSignal(asset: Asset): TradingSignal {
  const technicalScore = calculateTechnicalScore(asset);
  const fundamentalScore = calculateFundamentalScore(asset);
  const sentimentScore = calculateSentimentScore(asset);
  
  const totalScore = (technicalScore * 0.5) + 
                     (fundamentalScore * 0.3) + 
                     (sentimentScore * 0.2);
  
  let recommendation: Recommendation;
  if (totalScore > 60) recommendation = 'STRONG_BUY';
  else if (totalScore > 30) recommendation = 'BUY';
  else if (totalScore > -30) recommendation = 'HOLD';
  else if (totalScore > -60) recommendation = 'SELL';
  else recommendation = 'STRONG_SELL';
  
  return {
    asset: asset.id,
    recommendation,
    confidence: Math.abs(totalScore),
    scores: { technical: technicalScore, fundamental: fundamentalScore, sentiment: sentimentScore },
    reasons: generateReasons(asset, technicalScore, fundamentalScore, sentimentScore),
    targetPrice: calculateTargetPrice(asset),
    stopLoss: calculateStopLoss(asset),
    timeframe: 'میان‌مدت (5-10 روز)'
  };
}
```

### 3.4 Fear & Greed Index

```typescript
interface FearGreedIndex {
  value: number;  // 0-100
  label: 'Extreme Fear' | 'Fear' | 'Neutral' | 'Greed' | 'Extreme Greed';
  factors: {
    volatility: number;
    marketMomentum: number;
    volume: number;
    priceStrength: number;
  };
}

function calculateFearGreed(market: Market): FearGreedIndex {
  // منطق محاسبه بر اساس وضعیت کلی بازار
  // ...
}
```

---

## 🏢 بخش 4: بهبود مدیریت شرکت

### 4.1 چارت ارزش کمپانی

**کامپوننت جدید**: `CompanyValueChart.tsx`

```typescript
interface CompanyValueHistory {
  day: number;
  value: number;
  events: CompanyEvent[];
}
```

چارت باید:
- تاریخچه ارزش کمپانی را نمایش دهد
- رویدادهای مهم را علامت‌گذاری کند (IPO, Product Launch, etc.)
- با hover نمایش جزئیات

### 4.2 سیستم ارتقاء

هر بخش از کمپانی باید سیستم ارتقاء داشته باشد:

```typescript
interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  level: number;
  maxLevel: number;
  effects: {
    revenueBonus?: number;
    costReduction?: number;
    qualityIncrease?: number;
    // ...
  };
}
```

**مثال**: Supply Chain Level 2 → کاهش 10% هزینه تولید

### 4.3 شرکت‌های رقیب NPC

```typescript
interface NPCCompany {
  id: string;
  name: string;
  industry: string;
  marketShare: number;
  valuation: number;
  performance: 'WEAK' | 'AVERAGE' | 'STRONG';
}
```

- 5-10 شرکت رقیب
- رقابت برای market share
- تأثیر روی ارزش کمپانی بازیکن

### 4.4 M&A (ادغام و خرید)

```typescript
interface MAOpportunity {
  targetCompany: NPCCompany;
  price: number;
  benefits: string[];
  risks: string[];
  successChance: number;
}
```

---

## 💎 بخش 5: بهبود رمزارز

### 5.1 Roadmap تاثیرگذار

```typescript
interface CryptoRoadmap {
  milestones: Milestone[];
  progress: number;  // 0-100
}

interface Milestone {
  id: string;
  name: string;
  description: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'FAILED';
  deadline: number;  // روز
  effects: {
    priceImpact: number;     // ±%
    credibilityBonus: number;
    adoptionIncrease: number;
  };
  requirements: {
    funding?: number;
    developers?: number;
    marketing?: number;
  };
}
```

**مثال Milestones**:
1. Whitepaper Release (+5% credibility)
2. Testnet Launch (+10% adoption)
3. Mainnet Launch (+30% price)
4. Exchange Listing (+50% liquidity)
5. Partnership Announcement (+20% price)
6. DApp Ecosystem Launch (+40% adoption)

### 5.2 Smart Contracts

```typescript
interface SmartContract {
  id: string;
  name: string;
  type: 'TOKEN' | 'DEX' | 'LENDING' | 'NFT' | 'GOVERNANCE';
  status: 'DRAFT' | 'DEPLOYED' | 'AUDITED';
  effects: {
    utilityIncrease: number;
    securityScore: number;
    gasOptimization: number;
  };
  deploymentCost: number;
  auditCost: number;
}
```

### 5.3 Community & Governance

```typescript
interface Community {
  size: number;
  engagement: number;  // 0-100
  sentiment: number;   // -100 to 100
  votingPower: number;
}

interface GovernanceProposal {
  id: string;
  title: string;
  description: string;
  votesFor: number;
  votesAgainst: number;
  status: 'ACTIVE' | 'PASSED' | 'REJECTED';
  effects: Record<string, any>;
}
```

---

## 💹 بخش 6: بهبود معاملات

### 6.1 انواع سفارش‌های پیشرفته

```typescript
type OrderType = 
  | 'MARKET'           // بازار
  | 'LIMIT'            // محدود
  | 'STOP_LOSS'        // حد ضرر
  | 'TAKE_PROFIT'      // حد سود
  | 'TRAILING_STOP'    // استاپ متحرک
  | 'OCO'              // یکی لغو دیگری
  | 'ICEBERG'          // یخچال طبیعی
  | 'FILL_OR_KILL';    // کامل یا لغو

interface TrailingStopOrder extends Order {
  trailPercent: number;  // مثلاً 5%
  activationPrice: number;
}

interface OCOOrder {
  stopOrder: StopLossOrder;
  limitOrder: LimitOrder;
}
```

### 6.2 Order Book با Depth

```typescript
interface OrderBook {
  bids: OrderBookLevel[];  // خریدها
  asks: OrderBookLevel[];  // فروش‌ها
  spread: number;
}

interface OrderBookLevel {
  price: number;
  quantity: number;
  total: number;
}
```

نمایش بصری:
```
┌─── Order Book ───┐
│ Asks (فروش)     │
│ $101.5  │ 150   │
│ $101.2  │ 230   │
│ $101.0  │ 450   │
├─────────────────┤
│ Last: $100.8    │
├─────────────────┤
│ Bids (خرید)     │
│ $100.5  │ 380   │
│ $100.2  │ 520   │
│ $100.0  │ 670   │
└─────────────────┘
```

### 6.3 Funding Rate (برای Perpetual)

```typescript
interface PerpetualContract {
  fundingRate: number;      // نرخ تأمین مالی (% در 8 ساعت)
  nextFundingTime: number;  // زمان بعدی
  openInterest: number;     // بهره باز
}

// محاسبه هزینه/درآمد funding
function calculateFunding(position: Position, fundingRate: number): number {
  return position.size * position.entryPrice * fundingRate;
}
```

### 6.4 Copy Trading (اختیاری)

```typescript
interface Trader {
  id: string;
  name: string;
  roi: number;           // بازدهی
  winRate: number;       // نرخ برد
  followers: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

// بازیکن می‌تواند معاملات NPC traders را کپی کند
```

---

## 🎮 بخش 7: عمق و داستان بازی

### 7.1 سیستم مأموریت‌ها

```typescript
interface Mission {
  id: string;
  title: string;
  description: string;
  type: 'STORY' | 'SIDE' | 'DAILY' | 'WEEKLY';
  requirements: {
    capitalReached?: number;
    tradesCompleted?: number;
    assetsOwned?: number;
    companyValue?: number;
    cryptoCreated?: boolean;
    ipoCompleted?: boolean;
  };
  rewards: {
    cash?: number;
    experience?: number;
    unlocks?: string[];
    achievement?: string;
  };
  status: 'LOCKED' | 'AVAILABLE' | 'ACTIVE' | 'COMPLETED';
  nextMission?: string;
}
```

**مثال داستان اصلی**:
1. "اولین گام" → سرمایه $10K برسانید
2. "معامله‌گر حرفه‌ای" → 50 معامله سودده
3. "کارآفرین" → شرکت بسازید
4. "رونق تکنولوژی" → IPO انجام دهید
5. "غول کریپتو" → رمزارز موفق بسازید
6. "امپراطور مالی" → $100M برسانید

### 7.2 شخصیت‌های NPC

```typescript
interface NPCCharacter {
  id: string;
  name: string;
  role: 'MENTOR' | 'RIVAL' | 'PARTNER' | 'ADVISOR';
  personality: string;
  dialogue: Dialogue[];
  relationship: number;  // -100 to 100
  quests: Mission[];
}
```

**شخصیت‌های پیشنهادی**:
- **استاد احمدی**: مربی و مشاور
- **سارا موسوی**: رقیب سرسخت
- **دکتر کریمی**: مشاور فنی
- **آقای نوری**: سرمایه‌گذار فرشته

### 7.3 رویدادهای خاص

```typescript
interface SpecialEvent {
  id: string;
  name: string;
  description: string;
  trigger: EventTrigger;
  effects: EventEffects;
  choices?: EventChoice[];
  oneTime: boolean;
}

interface EventChoice {
  text: string;
  effects: EventEffects;
  requirements?: any;
}
```

**مثال‌ها**:
- **بحران مالی 2025**: تمام دارایی‌ها -30%، فرصت خرید
- **انقلاب AI**: سهام تکنولوژی +200%
- **کشف معدن طلا**: قیمت طلا -50%
- **جنگ تجاری**: ارزها نوسان شدید

### 7.4 سیستم شهرت

```typescript
interface Reputation {
  level: number;         // 1-100
  title: string;         // "تازه‌کار", "معامله‌گر", "سرمایه‌دار", ...
  globalRank: number;    // رتبه جهانی
  fame: number;          // شهرت (0-10000)
  influence: number;     // نفوذ (تأثیر روی بازار)
}
```

**عناوین**:
1. تازه‌کار (Novice)
2. معامله‌گر (Trader)
3. سرمایه‌دار (Investor)
4. کارآفرین (Entrepreneur)
5. تایکون (Tycoon)
6. افسانه (Legend)

---

## ⚖️ بخش 8: Balance بازی

### 8.1 تنظیم اقتصاد

**نرخ سود پیشنهادی**:
- معاملات اسپات: 0-100% (بر اساس مهارت)
- معاملات مارجین: ±500% (ریسک بالا)
- شرکت: +10-30% ماهانه (با مدیریت خوب)
- IPO: +50-200% (یک‌بار)
- رمزارز: ±1000% (خیلی پرریسک)

**هزینه‌ها**:
- کارمزد معاملات: 0.1-0.5%
- مالیات: 10-30% (بر اساس درآمد)
- هزینه‌های کمپانی: ثابت + متغیر
- Funding Rate: ±0.01% هر 8 ساعت

### 8.2 Adaptive Difficulty

```typescript
interface DifficultySettings {
  marketVolatility: number;    // نوسان بازار
  newsFrequency: number;        // فرکانس اخبار
  competitionLevel: number;     // سطح رقابت
  economicCrisisChance: number; // شانس بحران
}

function adjustDifficulty(player: Player): DifficultySettings {
  const capital = player.capital;
  
  if (capital < 50000) {
    return { volatility: 0.8, newsFrequency: 1, competition: 0.5, crisis: 0.01 };
  } else if (capital < 500000) {
    return { volatility: 1.0, newsFrequency: 1.2, competition: 0.8, crisis: 0.05 };
  } else {
    return { volatility: 1.5, newsFrequency: 1.5, competition: 1.2, crisis: 0.1 };
  }
}
```

### 8.3 Achievements چالش‌برانگیز

```typescript
interface Achievement {
  id: string;
  name: string;
  description: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'LEGENDARY';
  requirements: any;
  reward: {
    title?: string;
    bonus?: number;
    unlock?: string;
  };
  rarity: number;  // % بازیکنانی که به دست آورده‌اند
}
```

**مثال‌های Legendary**:
- "وارن بافت": $100M با فقط معاملات اسپات
- "الون ماسک": 10 شرکت موفق
- "ولف وال استریت": $10M در یک روز
- "هادلر الماس": یک دارایی را 365 روز hold کنید

---

## 📱 بخش 9: پیاده‌سازی

### 9.1 ساختار فایل‌ها

```
src/
├── components/
│   ├── analyzer/
│   │   ├── FinancialAnalyzer.tsx       ← جدید
│   │   ├── TechnicalAnalysis.tsx       ← جدید
│   │   ├── FundamentalAnalysis.tsx     ← جدید
│   │   ├── SentimentAnalysis.tsx       ← جدید
│   │   └── TradingSignals.tsx          ← جدید
│   ├── company/
│   │   ├── CompanyValueChart.tsx       ← جدید
│   │   ├── UpgradeSystem.tsx           ← جدید
│   │   ├── NPCCompanies.tsx            ← جدید
│   │   └── MAOpportunities.tsx         ← جدید
│   ├── crypto/
│   │   ├── RoadmapManager.tsx          ← جدید
│   │   ├── SmartContracts.tsx          ← جدید
│   │   └── CommunityGovernance.tsx     ← جدید
│   ├── trading/
│   │   ├── AdvancedOrders.tsx          ← جدید
│   │   ├── OrderBook.tsx               ← جدید
│   │   └── CopyTrading.tsx             ← اختیاری
│   ├── story/
│   │   ├── MissionSystem.tsx           ← جدید
│   │   ├── NPCDialogue.tsx             ← جدید
│   │   └── SpecialEvents.tsx           ← جدید
│   └── ... (بقیه کامپوننت‌ها)
├── lib/
│   ├── indicators.ts                   ← بهبود
│   ├── analyzer.ts                     ← جدید
│   ├── trading.ts                      ← بهبود
│   └── game-logic.ts                   ← بهبود
├── constants/
│   ├── assets.ts                       ← بهبود (88 دارایی)
│   ├── missions.ts                     ← جدید
│   ├── events.ts                       ← جدید
│   └── npcs.ts                         ← جدید
└── styles/
    └── design-system.css               ← جدید
```

### 9.2 اولویت‌ها

**فاز 1 (بالاترین اولویت)**:
1. ✅ پیاده‌سازی سیستم دیزاین جدید
2. ✅ افزودن 88 دارایی
3. ✅ آنالیزور مالی (حداقل تکنیکال + توصیه‌ها)
4. ✅ چارت ارزش کمپانی
5. ✅ انواع سفارش‌های پیشرفته

**فاز 2 (مهم)**:
6. ✅ نقشه راه رمزارز تاثیرگذار
7. ✅ سیستم ارتقاء کمپانی
8. ✅ Order Book
9. ✅ Fear & Greed Index
10. ✅ سیستم مأموریت‌ها

**فاز 3 (Nice to Have)**:
11. شخصیت‌های NPC
12. رویدادهای خاص
13. Copy Trading
14. Smart Contracts تفصیلی

---

## 🎨 یادآوری‌های مهم

### ✅ لازم:
- استفاده از سیستم دیزاین جدید (رنگ‌ها، فونت‌ها، spacing)
- فونت‌های جدید: Samim, Yekan, Sahel (بدون Vazir!)
- انیمیشن‌های روان با Framer Motion
- پاسخ‌های بصری فوری برای تمام اکشن‌ها
- 88 دارایی کامل با ویژگی‌های متفاوت
- آنالیزور با حداقل تکنیکال + توصیه‌ها

### ⚠️ نکات:
- کد تمیز و modular
- Performance optimization (مخصوصاً برای 88 دارایی)
- State management مناسب (Zustand فعلی OK است)
- Error handling و validation
- کامنت‌گذاری کدهای پیچیده

### 🎯 هدف نهایی:
یک بازی معاملاتی حرفه‌ای، زیبا، لذت‌بخش و چالش‌برانگیز که بازیکن ساعت‌ها را درگیر می‌کند!

---

موفق باشید! 🚀
