# سیستم دیزاین حرفه‌ای - Tycoon Simulator v2.0

## 🎨 فلسفه طراحی

### اصول کلیدی
1. **حرفه‌ای و قابل اعتماد**: ظاهر و احساس یک پلتفرم معاملاتی واقعی
2. **تمیز و مینیمال**: اطلاعات واضح بدون شلوغی و حواس‌پرتی
3. **معتادکننده**: انیمیشن‌ها، فیدبک‌های بصری و سیستم پاداش
4. **دسترسی‌پذیر**: رنگ‌های مناسب برای کوررنگی، کنتراست بالا
5. **روان و سریع**: انیمیشن‌های نرم، پاسخ‌های فوری

---

## 🌈 پالت رنگی (Color Psychology)

### رنگ‌های اصلی (Primary Colors)

```css
/* پس‌زمینه‌ها - تیره و حرفه‌ای */
--bg-primary: #0A0E27;        /* نیوی عمیق - پس‌زمینه اصلی */
--bg-secondary: #131832;      /* نیوی متوسط - کارت‌ها */
--bg-tertiary: #1C2444;       /* نیوی روشن - hover states */
--bg-elevated: #242B4D;       /* برای المان‌های بالاتر */

/* لهجه اصلی - طلایی (ثروت، موفقیت) */
--accent-gold: #FFB800;       /* طلایی اصلی */
--accent-gold-light: #FFC933; /* طلایی روشن */
--accent-gold-dark: #CC9300;  /* طلایی تیره */

/* لهجه ثانویه - آبی (اعتماد، ثبات) */
--accent-blue: #00A8FF;       /* آبی اصلی */
--accent-blue-light: #33BAFF; /* آبی روشن */
--accent-blue-dark: #0086CC;  /* آبی تیره */
```

### رنگ‌های عملکردی (Functional Colors)

```css
/* موفقیت - سبز ملایم (کاهش فشار عاطفی) */
--success: #00C853;           /* سبز اصلی */
--success-light: #5EFC82;     /* سبز روشن */
--success-dark: #00A843;      /* سبز تیره */
--success-bg: rgba(0, 200, 83, 0.1);  /* پس‌زمینه شفاف */

/* خطر - قرمز ملایم */
--danger: #FF3B30;            /* قرمز اصلی */
--danger-light: #FF6B5E;      /* قرمز روشن */
--danger-dark: #CC2F26;       /* قرمز تیره */
--danger-bg: rgba(255, 59, 48, 0.1);  /* پس‌زمینه شفاف */

/* هشدار - نارنجی */
--warning: #FF9500;
--warning-light: #FFB033;
--warning-dark: #CC7700;
--warning-bg: rgba(255, 149, 0, 0.1);

/* اطلاعات */
--info: #5AC8FA;
--info-light: #7ED4FB;
--info-dark: #48A0C8;
--info-bg: rgba(90, 200, 250, 0.1);
```

### رنگ‌های متن (Text Colors)

```css
--text-primary: #FFFFFF;      /* متن اصلی */
--text-secondary: #A0AEC0;    /* متن ثانویه */
--text-tertiary: #718096;     /* متن کم‌رنگ */
--text-disabled: #4A5568;     /* غیرفعال */
```

### رنگ‌های مرزها (Border Colors)

```css
--border-primary: rgba(255, 255, 255, 0.1);
--border-secondary: rgba(255, 255, 255, 0.05);
--border-focus: var(--accent-gold);
```

---

## 🔤 تایپوگرافی (Typography)

### فونت‌های فارسی (بدون Vazir)

```css
/* فونت اصلی - Samim (مدرن و خوانا) */
--font-primary-fa: 'Samim', 'Tahoma', sans-serif;

/* فونت عددی/داده - Yekan (واضح برای اعداد) */
--font-numbers-fa: 'Yekan', 'Tahoma', monospace;

/* فونت تیتر - Sahel (حرفه‌ای و بولد) */
--font-heading-fa: 'Sahel', 'Tahoma', sans-serif;
```

### فونت‌های انگلیسی

```css
/* فونت اصلی */
--font-primary-en: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;

/* فونت عددی */
--font-numbers-en: 'Roboto Mono', 'Courier New', monospace;

/* فونت تیتر */
--font-heading-en: 'Poppins', sans-serif;
```

### مقیاس تایپوگرافی

```css
--text-xs: 0.75rem;    /* 12px */
--text-sm: 0.875rem;   /* 14px */
--text-base: 1rem;     /* 16px */
--text-lg: 1.125rem;   /* 18px */
--text-xl: 1.25rem;    /* 20px */
--text-2xl: 1.5rem;    /* 24px */
--text-3xl: 1.875rem;  /* 30px */
--text-4xl: 2.25rem;   /* 36px */
--text-5xl: 3rem;      /* 48px */
```

### وزن فونت

```css
--font-light: 300;
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
--font-bold: 700;
--font-extrabold: 800;
```

---

## 📏 فاصله‌گذاری (Spacing)

```css
--space-0: 0;
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-20: 5rem;     /* 80px */
```

---

## 🎭 سایه‌ها و افکت‌ها (Shadows & Effects)

```css
/* سایه‌ها */
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
--shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);

/* سایه طلایی (برای برجسته‌سازی) */
--shadow-gold: 0 0 20px rgba(255, 184, 0, 0.3);
--shadow-gold-lg: 0 0 40px rgba(255, 184, 0, 0.5);

/* گلس‌مورفیسم */
--glass-bg: rgba(255, 255, 255, 0.05);
--glass-border: rgba(255, 255, 255, 0.1);
--glass-blur: blur(10px);
```

---

## 🎬 انیمیشن‌ها (Animations)

```css
/* مدت‌زمان */
--duration-fast: 150ms;
--duration-normal: 250ms;
--duration-slow: 350ms;
--duration-slower: 500ms;

/* Easing Functions */
--ease-in: cubic-bezier(0.4, 0, 1, 1);
--ease-out: cubic-bezier(0, 0, 0.2, 1);
--ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
--ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
```

### انیمیشن‌های کلیدی

```css
/* Fade in */
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* Slide up */
@keyframes slideUp {
  from { 
    opacity: 0;
    transform: translateY(20px);
  }
  to { 
    opacity: 1;
    transform: translateY(0);
  }
}

/* Scale in */
@keyframes scaleIn {
  from { 
    opacity: 0;
    transform: scale(0.9);
  }
  to { 
    opacity: 1;
    transform: scale(1);
  }
}

/* Pulse (برای اعلان‌ها) */
@keyframes pulse {
  0%, 100% { 
    opacity: 1;
    transform: scale(1);
  }
  50% { 
    opacity: 0.8;
    transform: scale(1.05);
  }
}

/* Shimmer (لودینگ) */
@keyframes shimmer {
  0% { background-position: -1000px 0; }
  100% { background-position: 1000px 0; }
}
```

---

## 🧩 کامپوننت‌ها (Components)

### دکمه‌ها (Buttons)

```css
/* دکمه اصلی - طلایی */
.btn-primary {
  background: linear-gradient(135deg, var(--accent-gold), var(--accent-gold-light));
  color: var(--bg-primary);
  padding: var(--space-3) var(--space-6);
  border-radius: 8px;
  font-weight: var(--font-semibold);
  transition: all var(--duration-normal) var(--ease-out);
  box-shadow: var(--shadow-md);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-gold-lg);
}

/* دکمه ثانویه */
.btn-secondary {
  background: var(--bg-tertiary);
  color: var(--text-primary);
  border: 1px solid var(--border-primary);
}

/* دکمه موفقیت */
.btn-success {
  background: linear-gradient(135deg, var(--success), var(--success-light));
  color: white;
}

/* دکمه خطر */
.btn-danger {
  background: linear-gradient(135deg, var(--danger), var(--danger-light));
  color: white;
}
```

### کارت‌ها (Cards)

```css
.card {
  background: var(--bg-secondary);
  border: 1px solid var(--border-primary);
  border-radius: 12px;
  padding: var(--space-6);
  box-shadow: var(--shadow-lg);
  transition: all var(--duration-normal) var(--ease-out);
}

.card:hover {
  border-color: var(--accent-gold);
  box-shadow: var(--shadow-gold);
  transform: translateY(-2px);
}

/* کارت گلس */
.card-glass {
  background: var(--glass-bg);
  backdrop-filter: var(--glass-blur);
  border: 1px solid var(--glass-border);
}
```

### اینپوت‌ها (Inputs)

```css
.input {
  background: var(--bg-tertiary);
  border: 1px solid var(--border-primary);
  border-radius: 8px;
  padding: var(--space-3) var(--space-4);
  color: var(--text-primary);
  font-family: var(--font-numbers-fa);
  transition: all var(--duration-normal) var(--ease-out);
}

.input:focus {
  outline: none;
  border-color: var(--accent-gold);
  box-shadow: 0 0 0 3px rgba(255, 184, 0, 0.1);
}
```

### بج‌ها (Badges)

```css
.badge {
  display: inline-flex;
  align-items: center;
  padding: var(--space-1) var(--space-3);
  border-radius: 9999px;
  font-size: var(--text-xs);
  font-weight: var(--font-semibold);
}

.badge-success {
  background: var(--success-bg);
  color: var(--success);
  border: 1px solid var(--success);
}

.badge-danger {
  background: var(--danger-bg);
  color: var(--danger);
  border: 1px solid var(--danger);
}
```

---

## 📊 چارت‌ها (Charts)

### رنگ‌های چارت

```css
/* کندل‌استیک */
--candle-up: var(--success);
--candle-down: var(--danger);

/* خطوط */
--line-price: var(--accent-blue);
--line-ma20: #FFA726;   /* نارنجی */
--line-ma50: #AB47BC;   /* بنفش */

/* اندیکاتورها */
--indicator-rsi: #00E676;
--indicator-macd: #00B0FF;
--indicator-signal: #FF6D00;
--indicator-bb-upper: #7C4DFF;
--indicator-bb-lower: #7C4DFF;
```

---

## 🎮 اصول طراحی بازی (Game Design Principles)

### 1. پاداش‌های دوپامین
- 🎯 فیدبک بصری فوری برای هر عملیات موفق
- ✨ انیمیشن‌های جشن برای دستاوردها
- 💰 نمایش واضح سود/زیان با افکت‌های بصری

### 2. سیستم پیشرفت
- 📈 نوار پیشرفت برای اهداف
- 🏆 Unlocks تدریجی برای ویژگی‌های جدید
- 📊 نمایش آمار و رشد کاربر

### 3. تعامل اجتماعی
- 👥 جدول رتبه‌بندی جهانی
- 🤝 سیستم مقایسه با دیگران
- 💬 اخبار و رویدادهای مشترک

### 4. چالش و مهارت
- ⚡ سطوح سختی متفاوت
- 🎯 اهداف کوتاه‌مدت و بلندمدت
- 🏅 Achievements پیچیده و چالش‌برانگیز

### 5. پاداش‌های متغیر
- 🎲 رویدادهای تصادفی در بازار
- 🎁 بونوس‌های غیرمنتظره
- 📰 اخبار با تاثیرات متفاوت

---

## 🎨 اصول UI/UX

### 1. کاهش بار شناختی
- اطلاعات مهم در مرکز توجه
- استفاده از heatmap و رنگ برای راهنمایی
- گروه‌بندی منطقی اطلاعات

### 2. فیدبک فوری
- لودینگ states برای تمام عملیات
- توست نوتیفیکیشن‌های زیبا
- انیمیشن برای تغییرات وضعیت

### 3. سادگی و قدرت
- رابط ساده برای تازه‌واردان
- دسترسی آسان به ویژگی‌های پیشرفته
- شخصی‌سازی layout

### 4. دسترسی‌پذیری
- کنتراست بالا برای خوانایی
- پشتیبانی از کوررنگی
- سایزهای متن قابل تنظیم

---

## 🚀 Micro-Interactions

### Hover States
- تغییر رنگ border
- افزایش box-shadow
- حرکت جزئی (translateY)

### Click Feedback
- انیمیشن scale کوچک
- ripple effect
- صدای کلیک (اختیاری)

### State Changes
- Fade transitions بین states
- Color transitions برای تغییر وضعیت
- Loading skeletons زیبا

---

## 📱 Responsive Design

### Breakpoints

```css
--breakpoint-sm: 640px;   /* موبایل */
--breakpoint-md: 768px;   /* تبلت */
--breakpoint-lg: 1024px;  /* لپتاپ */
--breakpoint-xl: 1280px;  /* دسکتاپ */
--breakpoint-2xl: 1536px; /* دسکتاپ بزرگ */
```

---

## 🎵 صداها (اختیاری)

### صداهای محیطی
- 🔔 کلیک دکمه: تیک نرم
- 💰 سود: صدای سکه
- 📉 ضرر: صدای هشدار ملایم
- 🎉 دستاورد: صدای جشن
- 📰 خبر مهم: صدای زنگ

---

## 📝 نکات پیاده‌سازی

1. **استفاده از CSS Variables**: تمام متغیرها در `:root` تعریف شوند
2. **Dark Mode Native**: طراحی از ابتدا برای حالت تاریک
3. **Performance**: استفاده از `transform` و `opacity` برای انیمیشن‌ها
4. **Accessibility**: ARIA labels برای screen readers
5. **Consistency**: استفاده مداوم از spacing و colors در تمام کامپوننت‌ها

---

این سیستم دیزاین پایه‌ای حرفه‌ای برای یک پلتفرم معاملاتی معتادکننده و زیباست که هم احساس اعتماد و هم لذت استفاده را القا می‌کند.
