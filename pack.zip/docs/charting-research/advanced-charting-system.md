# بلوپرینت جامع پیاده‌سازی چارت‌های کندل و تحلیل تکنیکال برای وب و موبایل

## ۱) مقدمه و اهداف

تجربه کاربر در پلتفرم‌های مالیِ مدرن با سه عامل اصلی تعریف می‌شود: دقت تحلیل، سرعت درک، و اعتماد به سیگنال‌ها. نمودارهای کندل به‌عنوان استاندارد طلاییِ نمایش داده‌های مالی، بستر بصریِ تصمیم‌گیری را فراهم می‌کنند. این گزارش، نقشه‌راهِ جامع و عملیاتی برای انتخاب، طراحی و پیاده‌سازی چارت‌های کندل و تحلیل تکنیکال در وب و موبایل ارائه می‌کند؛ از مقایسه کتابخانه‌های برتر تا معماری real-time و هشدارها، از همگام‌سازی چند بازه زمانی تا تجسم عمق بازار و پاسخ به نیازمندی‌های دسترس‌پذیری.

در چشم‌انداز فعلی، TradingView با ارائه کتابخانه‌های Lightweight و Advanced Charts به‌همراه اکوسیستم غنیِ drawing tools و اندیکاتورها، مرجع صنعت است؛ و در سوی دیگر، Highcharts Stock با ماژول‌های دسترس‌پذیری و سازگاری موبایل، استانداردهای کیفیت محصول را برای سازمان‌ها تعیین می‌کند.[^1][^2] این گزارش با اتکا به مستندات رسمی و منابع تخصصی، تصویری دقیق از گزینه‌ها و ملاحظات فنی ارائه می‌دهد.

اهداف اصلی این مطالعه عبارت‌اند از:
- گزینش بهینه کتابخانه چارت مالی بر اساس معیارهای عملکرد، قابلیت‌ها، دسترس‌پذیری و هزینه.
- تعریف بهترین شیوه‌های طراحی و پیاده‌سازی کندل (Candlestick) شامل فرمت داده OHLC، تم‌ها و رنگ‌بندی.
- تکمیل و بهینه‌سازی مجموعه اندیکاتورها و منطق سیگنال‌دهی با اتکا به کتابخانه‌های معتبر.
- طراحی معماری Real-time Data و هشدارها با پشتیبانی از WebSocket.
- همگام‌سازی چند بازه زمانی (Multiple Timeframes) و یکپارچه‌سازی drawing tools.
- ارائه راهکارهای موبایل و دسترس‌پذیری برای تجربه کاربر فراگیر.
- برنامه اجرایی گام‌به‌گام از وضعیت فعلی تا نسخه نهایی.

نکته مهم: در چند حوزه، شکاف اطلاعاتی وجود دارد که باید در فازهای بعد پوشش داده شود؛ از جمله محدودیت‌های دقیق مجوز برخی محصولات، نبود بنچمارک عددی یکپارچه برای حجم داده بسیار بزرگ، و سیاست‌های نهایی درباره منابع داده و SLA. این شکاف‌ها در بخش‌های مربوطه explicit ذکر شده‌اند.

## ۲) ارزیابی کتابخانه‌های چارت مالی

انتخاب کتابخانه مناسب، تعادلی میان عملکرد، قابلیت‌ها، پیچیدگی توسعه، دسترس‌پذیری و هزینه است. در حوزه مالی، معیارهایی چون پشتیبانی بومی از کندل، مدیریت timeseries، تم‌های تیره/روشن، هم‌راستاسازی محور زمان، ابزارهای رسم، و به‌روزرسانی real-time حیاتی‌اند. مستندات منابع مرجع نیز باید کامل، پایدار و قابل اتکا باشد.[^3][^4][^5][^6][^7][^8]

برای قضاوت سریع، جدول ۱ معیارهای کلیدی را برای گزینه‌های اصلی مقایسه می‌کند.

### جدول ۱: مقایسه کتابخانه‌های چارت مالی بر اساس معیارهای کلیدی
جدول زیر دید یکپارچه از گزینه‌ها ارائه می‌دهد. هدف از این مقایسه، تعیین گزینه بهینه برای نمودارهای کندل با قابلیت‌های real-time، drawing tools و دسترس‌پذیری است.

| کتابخانه | فناوری رندر | پشتیبانی بومی کندل | Drawing Tools | Real-time | دسترس‌پذیری | موبایل | لایسنس/قیمت‌گذاری | منبع |
|---|---|---|---|---|---|---|---|---|
| TradingView Lightweight Charts | Canvas | بله | راهنما، تم، افزونه‌ها؛ drawing حرفه‌ای در Advanced | بله (به‌روزرسانی لحظه‌ای) | تلاش برای رعایت استانداردها | بله | رایگان و متن‌باز (Apache 2.0) | [^1][^6][^7][^8] |
| TradingView Advanced Charts | Canvas | بله | ۸۰+ ابزار رسم، ۱۰۰+ اندیکاتور | بله | پیشرفته | بله | نیازمند بررسی مجوز | [^2][^29] |
| Highcharts Stock | SVG | بله (سری مالی) | Annotations و اندیکاتورها | بله (ماژول‌ها و API) | ماژول Accessibility | بله (Multi-Touch) | تجاری | [^3][^14][^19] |
| Chart.js + financial plugin | Canvas | بله (افزونه مالی) | از طریق پلاگین‌ها | بله (streaming plugin) | مستندات دسترس‌پذیری Canvas | بله | رایگان/متن‌باز | [^4][^15][^20][^27][^28] |
| ApexCharts (ApexStock) | SVG | بله | annotations و annotations سفارشی | بله (appendData/updateSeries) | راهنمای عمومی | بله | رایگان/متن‌باز + گزینه‌های تجاری | [^5][^21][^22] |

یافته‌های کلیدی:
- برای performance بالا و بسته‌های سبک، Lightweight Charts گزینه‌ای ممتاز است؛ به‌ویژه در سناریوهای real-time و موبایل.[^1][^8]
- برای دسترس‌پذیری سازمانی و قابلیت‌های موبایلِ شناخته‌شده، Highcharts Stock با ماژول Accessibility و پشتیبانی Multi-Touch برتری دارد.[^3][^19]
- اگر اکوسیستم React و سادگی توسعه اولویت باشد، Chart.js با افزونه مالی و پلاگین‌های streaming/zoom، مسیر توسعه سریع‌تری فراهم می‌کند؛ مشروط به مدیریت دسترس‌پذیری Canvas.[^4][^15][^20][^28]
- برای تیم‌هایی که به دنبال راه‌اندازی سریع با قابلیت‌های کندل و annotations در React هستند، ApexCharts (ApexStock) انتخابی عملی است.[^5][^21][^22]

### ۲.۱) TradingView Lightweight Charts

Lightweight Charts یک کتابخانه رایگان و متن‌باز با پکیج بسیار کم‌حجم (در حدود ۳۵KB) است که بر پایه Canvas ساخته شده و برای به‌روزرسانی‌های لحظه‌ای بهینه شده است. این کتابخانه انواع نمودار مالی شامل کندل، میله، خطی و area را ارائه می‌دهد و با تم‌های Dark/Light و قابلیت‌های Tooltip، Legend و Price Line انعطاف‌پذیری بالایی دارد. مستندات رسمی و دموهای آماده، مسیر یکپارچه‌سازی را کوتاه می‌کنند.[^6][^7][^8] از منظر طراحی، مثال‌های رسمیِ تم‌سازی، واترمارک، و مقایسه سری‌ها در دسترس‌اند که برای سفارشی‌سازی سریع مفیدند.[^9][^10][^11][^12][^13]

- نقاط قوت: عملکرد بسیار خوب در داده‌های حجیم و به‌روزرسانی لحظه‌ای؛ سازگاری عالی با موبایل؛ API تم و Tooltip کاربرپسند؛ اکوسیستم غنی از افزونه‌ها (Bands، Stacked Area و...).[^1][^8]
- محدودیت‌ها: برای drawing tools پیشرفته، به Advanced Charts یا پیاده‌سازی سفارشی نیاز است؛ دسترس‌پذیری به‌اندازه ماژول‌های تخصصی در برخی رقبا نیست (هرچند تلاش‌هایی صورت گرفته).[^1][^2]

### ۲.۲) Highcharts Stock

Highcharts Stock مجموعه‌ای بالغ بر پایه SVG است که سری‌های مالی (کندل، خط، حجم) و حدود ۴۰ اندیکاتور تکنیکال را به‌صورت سری آماده ارائه می‌کند. این محصول با ماژول Accessibility، مسیر دسترس‌پذیری را هموار می‌سازد و از واکنش‌گرایی هوشمند و ژست‌های چندلمسی در موبایل پشتیبانی می‌کند.[^3][^14][^19] انعطاف‌پذیری در annotations و سازگاری با فریمورک‌های مختلف، آن را برای تیم‌های محصولی که SLA و انطباق‌های سازمانی مهم‌اند، جذاب می‌کند.

- نقاط قوت: دسترس‌پذیری پیشرفته؛ تجربه موبایل استاندارد؛ مجموعه اندیکاتورهای آماده؛ اکوسیستم مستندات کامل.[^3][^14][^19]
- محدودیت‌ها: هزینه و لایسنس تجاری؛ حجم و پیچیدگی بیشتر نسبت به Lightweight؛ نیاز به سفارشی‌سازی برای برخی قابلیت‌های real-time.

### ۲.۳) Chart.js + financial plugin

افزونه chartjs-chart-financial، ماهیت مالی را به Chart.js اضافه می‌کند و با پشتیبانی از کندل و OHLC، آداپتورهای زمان (Luxon، Moment، date-fns)، و پلاگین‌های zoom/crosshair/streaming، مسیر توسعه را در اکوسیستم React تسهیل می‌کند.[^4][^15][^20][^27][^28] این گزینه برای MVPها و تیم‌هایی که به سرعت نیاز به نمودارهای مالی دارند، بسیار کارآمد است. نقطه‌چین: دسترس‌پذیری در Canvas نیازمند لایه‌های کمکی و طراحیِ دقیق است.[^20]

- نقاط قوت: سادگی و سرعت توسعه؛ پشتیبانی timeseries با آداپتورهای تاریخ؛ قابلیت real-time با streaming plugin.[^15][^27]
- محدودیت‌ها: نیاز به مدیریت دسترس‌پذیری؛ عملکرد در داده‌های بسیار حجیم نسبت به Lightweight کمتر بهینه است.[^20]

### ۲.۴) ApexCharts (ApexStock)

ApexCharts با ارائه کندل و امکانات به‌روزرسانی real-time (appendData، updateSeries)، در React محبوب است. مستندات رسمی فرمت‌های داده OHLC و مثال‌های کاربردی را ارائه کرده‌اند و امکان annotations و شخصی‌سازی رنگ را دارند.[^5][^21][^22] این گزینه برای داشبوردهای مالی با نیازهای متعادل انتخابی قابل اتکاست.

- نقاط قوت: سادگی در React؛ روش‌های به‌روزرسانی real-time؛ مستندات روشن.[^5][^21]
- محدودیت‌ها: برای drawing tools بسیار پیشرفته یا performance در big data ممکن است نیاز به راهکارهای مکمل باشد.

### ۲.۵) جمع‌بندی و توصیه انتخاب

- سناریوی Performance-first (داده‌های حجیم، موبایل، real-time): TradingView Lightweight Charts به‌عنوان گزینه اصلی پیشنهاد می‌شود. در صورت نیاز به drawing tools گسترده و اندیکاتورهای آماده، Advanced Charts مکمل مناسبی است.[^1][^2]
- سناریوی Accessibility-first (استانداردهای سازمانی، موبایل لمسی، SLA): Highcharts Stock به‌دلیل ماژول Accessibility و پشتیبانی Multi-Touch گزینه برتر است.[^3][^19]
- سناریوی توسعه سریع در React (MVP، POC): Chart.js + financial plugin یا ApexCharts بسته به ترجیح تیم برای Canvas/SVG و امکانات annotations توصیه می‌شوند.[^4][^5][^21][^22]
- توجه به شکاف‌های اطلاعاتی: محدودیت‌های دقیق مجوز Advanced Charts (جزئیات قرارداد) و بنچمارک عددیِ یکپارچه در داده‌های میلیون‌نقطه‌ای باید در فاز ارزیابی تکمیلی بررسی شود.[^2][^29]

## ۳) پیاده‌سازی نمودارهای کندل و بهترین شیوه‌ها

کندل‌استیک‌ها نمایش بصریِ چهار مقدار OHLC در هر بازه زمانی هستند: قیمت باز (Open)، بالا (High)، پایین (Low) و بسته (Close). درک مفهومی این نمودارها و الگوهای مرتبط، پیش‌نیاز طراحی مؤثر است.[^32] در سطح پیاده‌سازی، فرمت داده و رنگ‌بندی بدنه/فتیله، مدیریت timeseries، و سفارشی‌سازی تم‌ها و legends تعیین‌کننده‌اند.

### ۳.۱) فرمت داده و ورودی

- فرمت OHLC: می‌تواند آرایه دوبعدی جفتِ [timestamp, [O,H,L,C]]، آرایه تکی [timestamp, O, H, L, C]، یا فرمت شیء { x: date/timestamp, y: [O,H,L,C] } باشد.[^5]
- آداپتورهای زمان: برای مدیریت timezone و i18n، Chart.js از آداپتورهای Luxon، Moment و date-fns پشتیبانی می‌کند؛ انتخاب آداپتور باید با نیازهای محلی‌سازی و عملکرد مطابقت داشته باشد.[^15][^16][^17][^18]

### جدول ۲: فرمت‌های داده کندل در ApexCharts
این جدول، ساختارهای مجاز ورودی را خلاصه می‌کند و مثال‌های نمونه را برای پیاده‌سازی سریع نشان می‌دهد.

| فرمت | ساختار | مثال نمونه | نکته |
|---|---|---|---|
| جفتِ دوبعدی | [[timestamp, [O,H,L,C]], ...] | [[1538856000000, [6593.34, 6600, 6582.63, 6600]], ...] | سازگار با ورودیِ آرایه‌ای APIهای مالی |
| آرایه تکی | [timestamp, O, H, L, C] | [1538856000000, 6593.34, 6600, 6582.63, 6600] | ساده برای تبدیل از CSV/JSON |
| شیء xy | { x: date/timestamp, y: [O,H,L,C] } | { x: newDate(2016,01,01), y: [51.98, 56.29, 51.59, 53.85] } | انعطاف در timezone با timestamp |

منبع: مستندات رسمی ApexCharts.[^5]

### ۳.۲) رنگ‌بندی و تم‌ها

- بدنه شمع: در ApexCharts، رنگ پیش‌فرض برای شمع‌های صعودی سبز و نزولی قرمز است؛ قابل تغییر با plotOptions.candlestick.colors.[^5]
- فتیله: فتیله به‌طور پیش‌فرض از رنگ بدنه تبعیت می‌کند؛ می‌توان آن را با wick.useFillColor و colors جایگزین تنظیم کرد.[^5]
- سفارشی‌سازی تم‌ها: در Lightweight Charts، نمونه‌های رسمی تم‌های Dark/Light و مثال‌هایی برای Price Format، Tooltips و Watermark ارائه شده‌اند که برای سازگاری با برند و حالت‌های مختلف دیده‌سازی مفیدند.[^12][^9][^10][^13]

### ۳.۳) مدیریت Timezone و i18n

انتخاب آداپتور زمان، مستقیماً بر localization، daylight saving و عملکرد تأثیر می‌گذارد. در Chart.js، آداپتور Luxon به‌دلیل پشتیبانیِ نیرومند از i18n و timezone توصیه می‌شود؛ Moment.js و date-fns نیز گزینه‌های جایگزین‌اند. تنظیم صحیح locale و منطقه زمانی، از واگرایی محور زمان در سینک چند نمودار جلوگیری می‌کند.[^15][^16][^17][^18]

## ۴) اندیکاتورهای تکنیکال و سیگنال‌دهی

اندیکاتورها ستون فقرات تصمیم‌گیری داده‌محور هستند. در این بخش، دامنه اندیکاتورهای پوشش داده شده، منطق سیگنال‌دهی ترکیبی، و کتابخانه‌های محاسبه معرفی می‌شوند.

### ۴.۱) اندیکاتورهای پوشش داده شده

- Overlay: میانگین‌های متحرک ساده (SMA) و نمایی (EMA)، باندهای بولینگر.
- Oscillators: شاخص قدرت نسبی (RSI)، میانگین متحرک همگرایی واگرایی (MACD)، استوکاستیک.
- سایر: ADX، ATR، CCI، MFI، PSAR، OBV، VWAP و... در کتابخانه‌های جامع.[^30][^14]

### ۴.۲) منطق سیگنال‌دهی ترکیبی

ترکیب اندیکاتورها با وزن‌دهی منطقی، راهکاری برای افزایش اطمینان سیگنال است. برای نمونه:
- RSI زیر ۳۰: سیگنال خرید با وزن ۲۵؛ بالای ۷۰: فروش با وزن ۲۵؛ در بازه ۳۰-۷۰: خنثی با وزن ۱۰.
- تقاطع SMA20/SMA50 و موقعیت قیمت نسبت به آن‌ها: وزن ۲۰.
- MACD بالای خط سیگنال و هیستوگرام مثبت: خرید وزن ۲۰؛ عکس آن: فروش وزن ۲۰.
- بولینگر: قیمت زیر باند پایین خرید وزن ۱۵؛ بالای باند بالا فروش وزن ۱۵؛ در محدوده: خنثی.
- نوسان بالا: احتیاط با وزن ۱۰ (توصیه نگهداری).

این منطق را می‌توان با تعریف buyScore، sellScore و holdScore و انتخاب سیگنال نهایی با بیشترین وزن پیاده‌سازی کرد. کتابخانه technicalindicators، امکان محاسبهِ مرحله‌ای (nextValue) و دریافت بردار نتیجه (getResult) را فراهم می‌کند و برای ساخت پایپ‌لاین سیگنال‌دهی مناسب است.[^30]

### جدول ۳: ماتریس سیگنال‌ها (اندیکاتور -> شرط -> وزن -> سیگنال)
این ماتریس برای سیاست‌گذاری سیگنال‌ها و بازنگری وزن‌ها در طول زمان مفید است.

| اندیکاتور | شرط | وزن | سیگنال |
|---|---|---|---|
| RSI | < 30 | 25 | خرید |
| RSI | > 70 | 25 | فروش |
| RSI | 30–70 | 10 | نگهداری |
| SMA20/SMA50 | قیمت > SMA20 و SMA20 > SMA50 | 20 | خرید |
| SMA20/SMA50 | قیمت < SMA20 و SMA20 < SMA50 | 20 | فروش |
| MACD | MACD > Signal و Histogram > 0 | 20 | خرید |
| MACD | MACD < Signal و Histogram < 0 | 20 | فروش |
| Bollinger | قیمت < Lower Band | 15 | خرید |
| Bollinger | قیمت > Upper Band | 15 | فروش |
| نوسان | volatility > 2.0 | 10 | نگهداری |

توضیح: این جدول نمونه‌ای از سیاست پیشنهادی است و باید با داده‌های تاریخی و آزمون‌های عملکرد کالیبره شود. Highcharts Stock مجموعه اندیکاتورهای آماده را به‌صورت سری ارائه می‌کند و برای نمایش روی نمودار مفید است.[^14]

### ۴.۳) کتابخانه‌های محاسبه اندیکاتور

- technicalindicators: پوشش گسترده اندیکاتورها و الگوهای کندل، روش‌های nextValue و getResult، و تنظیم دقت محاسبات؛ مناسب برای مرورگر و Node.[^30]
- HiStock (Highcharts): سری اندیکاتورهای آماده برای نمایش سریع روی نمودار.[^14]
- Syncfusion: پشتیبانی از ۱۰ اندیکاتور مالی در کامپوننت Stock Chart.[^31]

## ۵) سیستم‌های چند بازه زمانی (Multiple Timeframes)

سناریوی مرسوم در تحلیل مالی، مشاهده هم‌زمان چند نمودار با بازه‌های زمانی متفاوت (مثلاً ۱ دقیقه، ۵ دقیقه، ۱ ساعت، ۱ روز) و همگام‌سازی محور زمان، crosshair و zoom است. این نیاز در Lightweight Charts و دیگر کتابخانه‌ها با الگوهای همگام‌سازی قابل پیاده‌سازی است.[^24][^25][^26]

### ۵.۱) الگوی همگام‌سازی زمان و crosshair

- اتصال محور زمان: نگاشت دقیق timestamp و مدیریت timezone برای هم‌ترازیِ نقاط در نمودارهای مختلف ضروری است.
- اشتراک‌گذاری وضعیت zoom/pan: انتشار رویدادهای zoom و pan بین نمودها برای تجربه یکپارچه.
- اشتراک‌گذاری crosshair: هم‌نمایی خط عمودی/مکان نما، و نمایش tooltip یکسان برای مقایسه دقیق.

راهنمای همگام‌سازی در AG Grid Charts، الگوی مفیدی برای تنظیم sync و تسهیل پیاده‌سازی ارائه می‌کند.[^26] در Lightweight Charts، پرسش و پاسخ‌های تخصصی راهکارهای عملی برای همگام‌سازی چند canvas ارائه کرده‌اند.[^24]

### جدول ۴: مقایسه روش‌های همگام‌سازی

| روش | کتابخانه | قابلیت همگام‌سازی | منبع |
|---|---|---|---|
| الگوی اشتراک وضعیت (Zoom/Pan/Crosshair) | Lightweight Charts | قابل پیاده‌سازی با event dispatch و timestamp alignment | [^24] |
| الگوی تنظیمات sync | AG Grid Charts | گزینه‌های آماده برای همگام‌سازی محور، zoom و nodes | [^26] |
| تکنیک‌های linked charts | SciChart | راهنمای جامع لینک کردن zoom/pan/crosshair | [^25] |

### ۵.۲) همگام‌سازی رویدادها و Tooltip

تعریف یک Event Bus ساده برای انتشار رویدادهای مشترک (mouse move، crosshair move، zoom/pan) بین چند نمودار، راهکاری سبک و قابل‌کنترل است. مدیریت timezone و daylight saving با آداپتورهای تاریخ (Luxon/Moment/date-fns) از واگرایی محور زمان جلوگیری می‌کند.[^15][^16][^17][^18] در Lightweight Charts، مثال‌های Tooltip و Watermark برای سفارشی‌سازی behavior مفیدند.[^10][^13]

## ۶) ابزارهای رسم (Drawing Tools)

ابزارهای رسم چون خطوط روند، فیبوناچی، و نواحی حمایت/مقاومت، زبان تحلیلِ کاربر حرفه‌ای هستند. در انتخاب کتابخانه، باید به پوشش native و امکان توسعه سفارشی توجه کرد.

### ۶.۱) مقایسه Drawing Tools

- Lightweight Charts: ابزارهای رسم به‌صورت افزونه و مثال در Advanced Charts در دسترس‌اند؛ تم‌ها، price line و tooltipها امکان شخصی‌سازی گسترده می‌دهند.[^1][^2]
- ApexStock: trend lines، rectangles، circles و annotations متنی را ارائه می‌کند و برای الگوهای کلاسیک و مستندسازی تحلیل کافی است.[^22]
- Highcharts Stock: annotations و مجموعه اندیکاتورها به‌همراه تم‌ها و واکنش‌گرایی، مسیر پوشش نیازهای drawing را هموار می‌کنند.[^3]
- LightningChart Trader: فهرست جامعی از ابزارها شامل trend lines، Fibonacci fan، Gann fan و... ارائه می‌دهد و برای تحلیل پیشرفته مناسب است.[^23]

### جدول ۵: ماتریس Drawing Tools

| کتابخانه | Trendline | Fibonacci | Rectangles/Circles | Annotations | پوشش native | منبع |
|---|---|---|---|---|---|---|
| Lightweight/Advanced | بله (Advanced) | بله (Advanced) | بله (Advanced) | بله | در Advanced | [^1][^2] |
| ApexStock | بله | پوشش پایه | بله | بله (متنی) | بله | [^22] |
| Highcharts Stock | بله | از طریق annotations | بله | بله | بله | [^3] |
| LightningChart Trader | بله | بله (Fan و...) | بله | بله | بله | [^23] |

توصیه: برای نیازهای پیشرفته، LightningChart Trader پوشش جامع‌تری دارد؛ برای Lightweight، استفاده از Advanced Charts توصیه می‌شود؛ برای سادگی، ApexStock کفایت می‌کند.

## ۷) جریان داده Real-time و WebSocket

طراحی پایپ‌لاین Real-time، ترکیبی از اتصال پایدار WebSocket، مدیریت backpressure، بافرهای حلقه‌ای و به‌روزرسانی کم‌هزینه UI است. کاهش layout thrashing و استفاده از رندر Canvas یا WebGL برای داده‌های پُرحجم حیاتی است.[^34][^35][^36]

### ۷.۱) معماری پایپ‌لاین

- اتصال و اشتراک: مدیریت اتصال (retry، heartbeat)، و اشتراک نمادهای مورد نیاز.
- نگاشت داده: تبدیل پیام‌های ورودی به فرمت OHLC و انتشار به لایه نمودار.
- بهینه‌سازی رندر: کاهش reflow، batch کردن به‌روزرسانی‌ها، استفاده از Canvas (یا WebGL برای داده‌های بسیار بزرگ).

### جدول ۶: مسیر جریان داده (Data Flow Pipeline)

| مرحله | شرح | ملاحظات |
|---|---|---|
| اتصال | WebSocket به endpoint provider | مدیریت reconnect و heartbeat |
| اشتراک | انتخاب نماد/کانال | جلوگیری از over-subscription |
| نگاشت | تبدیل پیام به OHLC | حفظ ترتیب زمانی |
| بافر | حلقه‌ای با ظرفیت محدود | مدیریت backpressure |
| رندر | به‌روزرسانی series | batching و throttling |

راهنمای عمومی پروژه‌های real-time و بهترین‌شیوه‌های مقیاس‌پذیری در منابع تخصصی پوشش داده شده‌اند.[^34][^35][^36]

### ۷.۲) بهینه‌سازی رندر

مقایسه Canvas و SVG نشان می‌دهد در نرخ‌های بالای به‌روزرسانی و داده‌های حجیم، Canvas به‌دلیل سربار کمترِ رندر نسبت به DOM، عملکرد بهتری دارد؛ در مقابل، SVG برای تعامل‌های پیچیده و گرافیکِ برداریِ دقیق، انعطاف‌پذیرتر است. برای داده‌های بسیار حجیم، WebGL با استفاده از GPU مزیت محسوسی ایجاد می‌کند. توصیه عملی: برای چارت‌های کندلِ real-time با صدها هزار نقطه، Canvas یا WebGL را ترجیح دهید و به‌روزرسانی‌ها را batching کنید.[^33][^35]

## ۸) سیستم هشدارها و اعلان‌ها

هشدارهای قیمت و سیگنال، قلب تجربه اقدام‌محور کاربر هستند. باید میان هشدارهای سمت کلاینت و سمت سرور توازن برقرار کرد.

### ۸.۱) سناریوهای هشدار

- هشدار قیمت: عبور از آستانه مشخص (Bid/Ask/Last).
- هشدار سیگنال: ترکیبی از اندیکاتورها (RSI، MACD، بولینگر) با وزن‌های تعریف‌شده.
- هشدار تجمعی: شرایط چندگانه و ترکیبی.

معماری: کلاینت (بررسی محلیِ داده‌های دریافت‌شده) و سرور (پایش مداومِ شرایط و ارسال اعلان). سرویس‌های سازمانی مانند Barchart Alerts، امکان تعریف شرایط پیچیده و تحویل فوری اعلان‌ها را فراهم می‌کنند و برای SLA مناسب‌اند.[^37] راهنمایی‌های عملی برای هشدارهای real-time نیز در منابع تخصصی ارائه شده است.[^38][^39]

### جدول ۷: ماتریس هشدارها

| نوع هشدار | شرط | منبع داده | کانال اعلان | SLA |
|---|---|---|---|---|
| قیمت | Last ≥ آستانه | WebSocket | مرورگر (Toast/Push) | فوری |
| سیگنال | buyScore > sellScore | محاسبه محلی | مرورگر/ایمیل | < ۱ ثانیه |
| تجمعی | ترکیب شرایط | سرور | Push/وب‌سرویس | بسته به سرویس |

## ۹) نمودارهای مقایسه‌ای و عملکرد نسبی

مقایسه چند سری زمانی و تبدیل به درصد (Relative Performance) برای تحلیل نسبی ضروری است. مثال‌های Lightweight Charts الگوی مقایسه چند سری را نشان می‌دهند و تم‌های سفارشیِ سازگار با برند، خوانایی را افزایش می‌دهند.[^11][^12] در سطح موتور رندر، تفاوت Canvas و SVG و نقش WebGL در داده‌های بسیار بزرگ باید در طراحی لحاظ شود.[^33]

### ۹.۱) پیاده‌سازی نسبی

- تبدیل هر سری به بازده درصدی نسبت به نقطه شروع.
- اعمال تم یکسان و رنگ‌بندی سازگار برای خوانایی.
- مدیریت legend و tooltip برای توضيح بازده‌ها.

## ۱۰) تجسم عمق بازار (Order Book Visualization)

عمق بازار (DOM/Depth) نمای تجمعیِ سفارش‌های خرید/فروش را در سطوح قیمت مختلف نشان می‌دهد و برای درک نقدینگی و جریان سفارشات حیاتی است. الگوهای مختلف شامل depth chart (منحنی تجمعی)، histogram و heatmap حجم هستند.

### ۱۰.۱) الگوهای نمایش

- Depth Chart: منحنی‌های تجمعیِ Bid/Ask و نمایش ناحیه میان آن‌ها (spread).[^40]
- Histogram: میله‌های حجم در هر سطح قیمت با رنگ‌بندی برای خرید/فروش.
- Heatmap: نمایش تراکم حجم با رنگ‌ها برای درک سریع نواحی نقدشونده.

کتابخانه‌هایی مانند SciChart و Highcharts مثال‌های عملی برای پیاده‌سازی depth chart ارائه کرده‌اند؛ پروژه‌های متن‌باز مبتنی بر D3 نیز مسیر رایگان برای نمونه‌سازی فراهم می‌کنند.[^41][^40][^42]

### جدول ۸: خلاصه انواع DOM

| نوع | توضیح | مزایا | محدودیت | ابزار/کتابخانه |
|---|---|---|---|---|
| Depth Chart | منحنی تجمعی | نمایش spread و نقدشوندگی | نیاز به داده تمیز | Highcharts، SciChart[^40][^41] |
| Histogram | میله‌های حجم | خوانایی سطح قیمت | شلوغی در داده حجیم | SciChart، D3[^41][^42] |
| Heatmap | رنگ‌دهی تراکم | دید سریع نواحی گرم | تفسیر رنگ برای همه ساده نیست | SciChart، D3[^41][^42] |

## ۱۱) بهینه‌سازی موبایل

تجربه موبایل باید به‌اندازه دسکتاپ دقیق و سریع باشد. واکنش‌گراییِ هوشمند، ژست‌های چندلمسی، و رندر بهینه سه ستون اصلی‌اند.

### ۱۱.۱) واکنش‌گرایی و ژست‌ها

- Intelligent Responsiveness: نه‌تنها اندازه، بلکه چیدمان برچسب‌ها، legend و annotations باید به‌صورت هوشمند تطبیق یابد.[^3]
- Multi-Touch: ژست‌های pinch-zoom و pan برای بررسی داده‌ها باید native و روان باشند.[^3]
- بهینه‌سازی رندر: استفاده از Canvas برای داده‌های حجیم و به‌روزرسانی لحظه‌ای؛ در صورت نیاز، WebGL برای big data.[^33]

## ۱۲) دسترس‌پذیری (Accessibility)

دسترس‌پذیری در نمودارهای مالی، از الزامات قانونی و اخلاقی است. ماژول Accessibility در Highcharts، API و راهنمایی‌هایی برای سازگاری با فناوری‌های کمکی، ناوبری با صفحه‌کلید و توضیحات ارائه می‌کند.[^19] در Chart.js (Canvas)، ایجاد عناصر قابل دسترسی (ARIA، متن جایگزین، جداول داده پشتیبان) بر عهده توسعه‌دهنده است.[^20] راهنمای عمومیِ ساخت چارت‌های تعاملیِ قابل دسترس، و ماژول دسترس‌پذیری در amCharts، منابع مکملِ مفیدی هستند.[^43][^44]

### ۱۲.۱) الزامات کلیدی

- Screen Reader: توصیف عناصر اصلی نمودار، محورها، سری‌ها، و سیگنال‌ها.
- Keyboard Navigation: پیمایش با TAB و کلیدهای جهت‌دار؛ فعال/غیرفعال کردن zoom و crosshair.
- وضوح رنگ و کنتراست: رنگ‌بندی مطابق استاندارد؛ عدم اتکا صرف به رنگ برای انتقال معنا.
- جداول داده: ارائه جدولِ پشتیبان برای نمودار، برای خواندن توسط screen reader.

## ۱۳) طرح پیاده‌سازی گام‌به‌گام (Implementation Plan)

این بخش، برنامه اجراییِ مرحله‌به‌مرحله از وضعیت فعلی تا نسخه نهایی را خلاصه می‌کند؛ شامل تحلیل وضعیت، انتخاب کتابخانه، پیاده‌سازی کندل و اندیکاتورها، real-time و MTF، هشدارها، موبایل و Accessibility، و تست/بنچمارک.

### ۱۳.۱) تحلیل وضعیت فعلی

- بررسی مؤلفه‌های موجود: FinancialAnalyzer (نمایش اندیکاتورها و سیگنال‌ها)، CompanyValueChart (نمودار خطی مبتنی بر Recharts)، و ماژول محاسبات اندیکاتورها (RSI، MACD، بولینگر، SMA/EMA) در indicators.
- شناسایی شکاف‌ها: نبود چارت کندل، drawing tools حرفه‌ای، real-time WebSocket، همگام‌سازی چند بازه زمانی، و سیستم هشدارها.

### ۱۳.۲) انتخاب کتابخانه و معماری

بر اساس معیارها، Lightweight Charts برای عملکرد و real-time انتخاب اصلی است؛ در صورت نیاز به drawing tools گسترده، Advanced Charts تکمیل می‌شود. برای دسترس‌پذیری سازمانی و موبایل، Highcharts Stock گزینه جایگزین است. در MVP، Chart.js + financial plugin یا ApexCharts برای توسعه سریع در React قابل استفاده‌اند.[^1][^2][^3][^4][^5]

### ۱۳.۳) Roadmap اجرایی

- گام ۱: پیاده‌سازی کندل و اندیکاتورها
  - انتخاب آداپتور زمان (Luxon/Moment/date-fns) و تعریف فرمت OHLC.[^5][^15][^16][^17][^18]
  - یکپارچه‌سازی اندیکاتورها با technicalindicators و نمایش در پنل‌ها.[^30]
- گام ۲: پایپ‌لاین Real-time
  - اتصال WebSocket، بافر حلقه‌ای، و به‌روزرسانی batch؛ الگوی آپدیت در ApexCharts (appendData/updateSeries) و Lightweight (real-time demo).[^5][^36]
- گام ۳: Multiple Timeframes و Drawing Tools
  - همگام‌سازی محور زمان، crosshair و zoom بین نمودها؛ تعریف Event Bus و مدیریت timezone؛ پیاده‌سازی trendline/fibonacci (Advanced یا ApexStock).[^24][^26][^22]
- گام ۴: هشدارها و اعلان‌ها
  - طراحی شرایط، کلاینت/سرور، و کانال‌های اعلان؛ ادغام سرویس سازمانی در صورت نیاز (Barchart).[^37][^38][^39]
- گام ۵: موبایل و Accessibility
  - واکنش‌گراییِ هوشمند، چندلمسی، ARIA و Keyboard Navigation؛ ممیزی دسترس‌پذیری.[^3][^19][^20][^43][^44]
- گام ۶: تست و بنچمارک
  - سناریوهای عملکرد در داده‌های حجیم، رندر Canvas/SVG/WebGL، و مصرف حافظه؛ بهره‌گیری از راهنماهای مقایسه‌ای.[^33][^35]

### جدول ۹: گانت پروژه (فازها، مدت، وابستگی‌ها، مسئولیت‌ها)

| فاز | مدت تخمینی | وابستگی‌ها | مسئول |
|---|---|---|---|
| ۱. کندل و اندیکاتورها | ۳–۴ هفته | فرمت داده، آداپتور زمان | تیم Front-end |
| ۲. Real-time | ۳ هفته | WebSocket provider | تیم Front-end/Back-end |
| ۳. MTF + Drawing | ۳ هفته | Event Bus، کتابخانه | تیم Front-end |
| ۴. هشدارها | ۲–۳ هفته | شرایط، کانال‌ها | تیم Back-end/Front-end |
| ۵. موبایل + Accessibility | ۳ هفته | UI/UX، ممیزی | تیم QA/Front-end |
| ۶. تست/بنچمارک | ۲ هفته | ابزارهای observability | تیم QA/Performance |

نکته درباره شکاف‌های اطلاعاتی: قیمت‌گذاری دقیق و مجوز Advanced Charts، بنچمارک عددیِ یکپارچه در داده‌های میلیون‌نقطه‌ای، سیاست‌های نهایی منابع داده و SLA، پوشش کامل الگوهای کندل، و استراتژی نهایی رسم و سینک drawings در چند TF باید در فازهای مذاکره و ارزیابی تکمیلی تعیین شوند.[^2][^29]

---

## منابع

[^1]: Lightweight Charts™ library - TradingView. https://www.tradingview.com/lightweight-charts/
[^2]: Key features - Advanced Charts Documentation. https://charting-library-docs.xstaging.tv/wrt813/v25/getting_started/Key-Features/
[^3]: Highcharts Stock Financial Javascript Library. https://www.highcharts.com/products/stock/
[^4]: chartjs-chart-financial - GitHub. https://github.com/chartjs/chartjs-chart-financial
[^5]: Candlestick Chart Guide & Documentation - ApexCharts.js. https://apexcharts.com/docs/chart-types/candlestick/
[^6]: TradingView Lightweight Charts - GitHub. https://github.com/tradingview/lightweight-charts
[^7]: TradingView Lightweight Charts Documentation. https://tradingview.github.io/lightweight-charts/
[^8]: Lightweight Charts - Real-time updates demo. https://tradingview.github.io/lightweight-charts/tutorials/demos/realtime-updates
[^9]: Lightweight Charts - Customization Intro. https://tradingview.github.io/lightweight-charts/tutorials/customization/intro
[^10]: Lightweight Charts - Tooltips. https://tradingview.github.io/lightweight-charts/tutorials/how_to/tooltips
[^11]: Lightweight Charts - Compare multiple series. https://tradingview.github.io/lightweight-charts/tutorials/demos/compare-multiple-series
[^12]: Lightweight Charts - Customization Themes. https://tradingview.github.io/lightweight-charts/tutorials/customization/intro
[^13]: Lightweight Charts - Watermark. https://tradingview.github.io/lightweight-charts/tutorials/how_to/watermark
[^14]: Technical indicator series - Highcharts Stock. https://highcharts.com/docs/stock/technical-indicator-series
[^15]: chartjs-adapter-luxon - GitHub. https://github.com/chartjs/chartjs-adapter-luxon
[^16]: Moment.js. https://momentjs.com/
[^17]: date-fns. https://date-fns.org/
[^18]: Lightweight Charts - Series Types: Candlestick. https://tradingview.github.io/lightweight-charts/docs/series-types#candlestick
[^19]: Accessibility module - Highcharts. https://highcharts.com/docs/accessibility/accessibility-module
[^20]: Accessibility - Chart.js. https://www.chartjs.org/docs/latest/general/accessibility.html
[^21]: React Candlestick Charts Examples - ApexCharts. https://apexcharts.com/react-chart-demos/candlestick-charts/
[^22]: ApexStock.js. https://apexcharts.com/apexstock/
[^23]: List of available drawing tools | LightningChart® JS Trader. https://lightningchart.com/js-charts/trader/docs/drawing-tools/available-drawing-tools/
[^24]: How to sync multiple lightweight-chart canvas? - Stack Overflow. https://stackoverflow.com/questions/73922838/how-to-sync-multiple-lightweight-chart-canvas
[^25]: How to Link JavaScript Charts and Synchronise zooming, panning, crosshairs - SciChart. https://www.scichart.com/blog/how-to-link-javascript-charts-and-synchronise-zooming-panning-crosshairs/
[^26]: JavaScript Charts: Synchronized Charts - AG Grid. https://www.ag-grid.com/charts/javascript/sync/
[^27]: chartjs-plugin-streaming - GitHub. https://github.com/nagix/chartjs-plugin-streaming
[^28]: chartjs-plugin-zoom - GitHub. https://github.com/chartjs/chartjs-plugin-zoom
[^29]: Free Charting Library by TradingView. https://www.tradingview.com/free-charting-libraries/
[^30]: anandanand84/technicalindicators - GitHub. https://github.com/anandanand84/technicalindicators
[^31]: JavaScript Technical Indicators | Syncfusion. https://www.syncfusion.com/javascript-ui-controls/js-charts/technical-indicators
[^32]: Introduction to candlestick charts and patterns - TradingView. https://www.tradingview.com/support/solutions/43000745269-introduction-to-candlestick-charts-and-patterns/
[^33]: Comparing Canvas vs. WebGL for JavaScript Chart Performance. https://digitaladblog.com/2025/05/21/comparing-canvas-vs-webgl-for-javascript-chart-performance/
[^34]: Scaling realtime web apps with JavaScript and WebSockets - Ably. https://ably.com/topic/websockets-javascript
[^35]: Public comparison of JavaScript chart libraries performance - GitHub. https://github.com/Arction/javascript-charts-performance-comparison
[^36]: Real-time data streaming using WebSockets - Intrinio. https://docs.intrinio.com/tutorial/websocket
[^37]: Market Data Alerts API - Barchart Solutions. https://www.barchart.com/solutions/services/digital/alerts
[^38]: Creating realtime alerts for stock quotes - Stack Overflow. https://stackoverflow.com/questions/61536617/creating-realtime-alerts-for-stock-quotes
[^39]: Real-Time Notification System with Node.js and WebSockets - Codefinity. https://codefinity.com/blog/Real-Time-Notification-System-with-Node.js-and-WebSockets
[^40]: Depth chart: A visual guide to market liquidity and order flow - Highcharts. https://www.highcharts.com/blog/tutorials/depth-chart-a-visual-guide-to-market-liquidity-and-order-flow/
[^41]: JavaScript Market Depth Chart - SciChart.js. https://www.scichart.com/demo/javascript/depth-chart
[^42]: melonproject/orderbook-visualisation - jsDelivr. https://www.jsdelivr.com/package/npm/@melonproject/orderbook-visualisation
[^43]: How to make interactive charts accessible - Deque. https://www.deque.com/blog/how-to-make-interactive-charts-accessible/
[^44]: Accessibility in amCharts 5. https://www.amcharts.com/accessibility/accessible-charts/