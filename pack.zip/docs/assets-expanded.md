# لیست گسترده دارایی‌ها (85+ مورد)

## 📈 سهام (Stocks) - 25 مورد

### فناوری (Technology)
1. **AAPL** - اپل (Apple Inc.)
2. **MSFT** - مایکروسافت (Microsoft)
3. **GOOGL** - گوگل (Alphabet)
4. **META** - متا (Meta/Facebook)
5. **NVDA** - انویدیا (NVIDIA)
6. **AMD** - AMD
7. **INTC** - اینتل (Intel)
8. **TSLA** - تسلا (Tesla)

### بانکداری و مالی (Banking & Finance)
9. **JPM** - جی‌پی‌مورگان (JPMorgan)
10. **BAC** - بانک آمریکا (Bank of America)
11. **WFC** - ولز فارگو (Wells Fargo)
12. **GS** - گلدمن ساکس (Goldman Sachs)
13. **MS** - مورگان استنلی (Morgan Stanley)

### دارویی و بهداشت (Pharmaceutical & Healthcare)
14. **PFE** - فایزر (Pfizer)
15. **JNJ** - جانسون اند جانسون (Johnson & Johnson)
16. **MRNA** - مدرنا (Moderna)
17. **ABBV** - ابی‌وی (AbbVie)

### انرژی (Energy)
18. **XOM** - اکسون‌موبیل (ExxonMobil)
19. **CVX** - شورون (Chevron)
20. **COP** - کونوکوفیلیپس (ConocoPhillips)

### خرده‌فروشی (Retail)
21. **AMZN** - آمازون (Amazon)
22. **WMT** - والمارت (Walmart)
23. **COST** - کاستکو (Costco)

### صنعتی و خودرو (Industrial & Auto)
24. **GE** - جنرال الکتریک (General Electric)
25. **F** - فورد (Ford Motor)

---

## 🪙 کالاها (Commodities) - 18 مورد

### فلزات گرانبها (Precious Metals)
26. **GOLD** - طلا (Gold)
27. **SILVER** - نقره (Silver)
28. **PLAT** - پلاتین (Platinum)
29. **PALL** - پالادیوم (Palladium)

### انرژی (Energy)
30. **OIL** - نفت خام (Crude Oil)
31. **BRENT** - نفت برنت (Brent Oil)
32. **NATGAS** - گاز طبیعی (Natural Gas)
33. **COAL** - زغال سنگ (Coal)
34. **URANIUM** - اورانیوم (Uranium)

### فلزات صنعتی (Industrial Metals)
35. **COPPER** - مس (Copper)
36. **ALUM** - آلومینیوم (Aluminum)
37. **ZINC** - روی (Zinc)
38. **NICKEL** - نیکل (Nickel)

### محصولات کشاورزی (Agricultural)
39. **WHEAT** - گندم (Wheat)
40. **CORN** - ذرت (Corn)
41. **SOYBEAN** - سویا (Soybean)
42. **COFFEE** - قهوه (Coffee)
43. **SUGAR** - شکر (Sugar)

---

## 💱 ارزها (Currencies/Forex) - 20 مورد

### ارزهای اصلی (Major Currencies)
44. **USD** - دلار آمریکا (US Dollar)
45. **EUR** - یورو (Euro)
46. **GBP** - پوند بریتانیا (British Pound)
47. **JPY** - ین ژاپن (Japanese Yen)
48. **CHF** - فرانک سوئیس (Swiss Franc)
49. **CAD** - دلار کانادا (Canadian Dollar)
50. **AUD** - دلار استرالیا (Australian Dollar)
51. **NZD** - دلار نیوزیلند (New Zealand Dollar)

### ارزهای نوظهور (Emerging Markets)
52. **CNY** - یوان چین (Chinese Yuan)
53. **INR** - روپیه هند (Indian Rupee)
54. **BRL** - رئال برزیل (Brazilian Real)
55. **RUB** - روبل روسیه (Russian Ruble)
56. **KRW** - وون کره جنوبی (South Korean Won)
57. **MXN** - پزوی مکزیک (Mexican Peso)
58. **ZAR** - راند آفریقای جنوبی (South African Rand)
59. **TRY** - لیر ترکیه (Turkish Lira)
60. **IDR** - روپیه اندونزی (Indonesian Rupiah)
61. **THB** - بات تایلند (Thai Baht)
62. **SGD** - دلار سنگاپور (Singapore Dollar)
63. **HKD** - دلار هنگ‌کنگ (Hong Kong Dollar)

---

## 🪙 رمزارزها (Cryptocurrencies) - 15 مورد

### Top Tier
64. **BTC** - بیت‌کوین (Bitcoin)
65. **ETH** - اتریوم (Ethereum)
66. **BNB** - بایننس کوین (Binance Coin)
67. **XRP** - ریپل (Ripple)
68. **ADA** - کاردانو (Cardano)
69. **SOL** - سولانا (Solana)
70. **DOGE** - دوج‌کوین (Dogecoin)
71. **MATIC** - پالیگان (Polygon)

### DeFi & Layer 2
72. **AVAX** - آوالانچ (Avalanche)
73. **DOT** - پولکادات (Polkadot)
74. **UNI** - یونی‌سواپ (Uniswap)
75. **LINK** - چین‌لینک (Chainlink)

### Stablecoins
76. **USDT** - تتر (Tether)
77. **USDC** - USD Coin
78. **DAI** - دای (DAI)

---

## 📊 شاخص‌ها (Indices) - 10 مورد

### شاخص‌های آمریکا
79. **SPX** - اس‌اند‌پی ۵۰۰ (S&P 500)
80. **DJI** - داو جونز (Dow Jones)
81. **IXIC** - نزدک (NASDAQ)
82. **RUT** - راسل ۲۰۰۰ (Russell 2000)

### شاخص‌های اروپا
83. **FTSE** - FTSE 100 (لندن)
84. **DAX** - DAX (آلمان)
85. **CAC** - CAC 40 (فرانسه)

### شاخص‌های آسیا
86. **N225** - نیکی ۲۲۵ (Nikkei 225 - ژاپن)
87. **HSI** - هنگ‌سنگ (Hang Seng - هنگ‌کنگ)
88. **SSEC** - شانگهای (Shanghai Composite)

---

## 📝 دسته‌بندی نهایی

| دسته | تعداد |
|------|-------|
| سهام | 25 |
| کالاها | 18 |
| ارزها | 20 |
| رمزارزها | 15 |
| شاخص‌ها | 10 |
| **جمع** | **88 دارایی** |

---

## 🎯 ویژگی‌های هر دارایی

هر دارایی باید شامل موارد زیر باشد:

```typescript
interface Asset {
  id: string;
  name: string;          // نام فارسی
  symbol: string;        // نماد
  category: AssetCategory;
  
  // قیمت
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  
  // تاریخچه
  priceHistory: PricePoint[];
  
  // ویژگی‌های خاص
  volatility: number;    // نوسان (0.5-2.0)
  liquidity: number;     // نقدینگی (0.5-2.0)
  
  // اطلاعات تکمیلی (برای آنالیزور)
  marketCap?: number;    // ارزش بازار
  volume24h?: number;    // حجم ۲۴ ساعته
  peRatio?: number;      // P/E Ratio (فقط سهام)
  sentiment?: number;    // سنتیمنت بازار (-1 تا 1)
}
```

---

## 💡 منطق قیمت‌گذاری اولیه

### سهام
- قیمت پایه: $50 - $500
- نوسان: 0.8 - 1.5

### کالاها
- فلزات گرانبها: $500 - $2000
- انرژی: $50 - $150
- کشاورزی: $200 - $800
- نوسان: 1.0 - 2.0

### ارزها
- قیمت پایه: 0.5 - 2.0 (نسبت به USD)
- نوسان: 0.5 - 1.2

### رمزارزها
- Top tier: $1000 - $50000
- Mid tier: $50 - $500
- Stablecoins: $1
- نوسان: 1.5 - 3.0

### شاخص‌ها
- قیمت پایه: $1000 - $5000
- نوسان: 0.7 - 1.0

---

این لیست گسترده، تنوع کافی برای یک تجربه واقعی‌تر و جذاب‌تر به بازی می‌دهد.
