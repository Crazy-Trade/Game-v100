# طراحی آنالیزور/تحلیلگر مالی حرفه‌ای

## 🎯 هدف

ارائه یک ابزار تحلیل جامع که به بازیکن در تصمیم‌گیری‌های معاملاتی کمک کند، با ترکیبی از تحلیل تکنیکال، فاندامنتال و روانشناسی بازار.

---

## 📊 بخش 1: تحلیل تکنیکال (Technical Analysis)

### 1.1 اندیکاتورهای موجود

#### Moving Averages (میانگین‌های متحرک)
- **MA20**: میانگین متحرک ۲۰ دوره
- **MA50**: میانگین متحرک ۵۰ دوره
- **سیگنال**: 
  - Golden Cross (MA20 > MA50): صعودی
  - Death Cross (MA20 < MA50): نزولی

#### RSI (Relative Strength Index)
- **محدوده**: 0-100
- **Overbought**: RSI > 70 (اشباع خرید)
- **Oversold**: RSI < 30 (اشباع فروش)
- **Neutral**: 30 < RSI < 70

#### MACD (Moving Average Convergence Divergence)
- **خطوط**: MACD Line, Signal Line, Histogram
- **سیگنال**:
  - MACD > Signal: صعودی
  - MACD < Signal: نزولی
  - Histogram تغییر جهت: تغییر روند

#### Bollinger Bands
- **باندهای بالا و پایین**: ±2 انحراف معیار
- **سیگنال**:
  - قیمت در باند بالا: احتمال بازگشت
  - قیمت در باند پایین: احتمال صعود
  - فشردگی باندها: آماده انفجار

### 1.2 اندیکاتورهای جدید

#### Stochastic Oscillator
- **فرمول**: %K, %D
- **محدوده**: 0-100
- **Overbought**: > 80
- **Oversold**: < 20

#### ATR (Average True Range)
- **کاربرد**: اندازه‌گیری نوسان
- **استفاده**: تعیین Stop Loss

#### OBV (On-Balance Volume)
- **کاربرد**: تأیید روند با حجم
- **سیگنال**: واگرایی با قیمت = تغییر روند

#### Fibonacci Retracement
- **سطوح**: 23.6%, 38.2%, 50%, 61.8%, 78.6%
- **کاربرد**: تعیین سطوح حمایت و مقاومت

#### Ichimoku Cloud
- **خطوط**: Tenkan-sen, Kijun-sen, Senkou Span A/B
- **سیگنال**: قیمت بالای ابر = صعودی

---

## 📈 بخش 2: تحلیل فاندامنتال (Fundamental Analysis)

### 2.1 متریک‌های سهام

#### نسبت قیمت به درآمد (P/E Ratio)
```typescript
PE_Ratio = Price / EarningsPerShare
```
- **Undervalued**: P/E < میانگین صنعت
- **Overvalued**: P/E > میانگین صنعت

#### ارزش بازار (Market Cap)
```typescript
MarketCap = Price × TotalShares
```
- **Large Cap**: > $10B
- **Mid Cap**: $2B - $10B
- **Small Cap**: < $2B

#### نسبت قیمت به دفتری (P/B Ratio)
```typescript
PB_Ratio = Price / BookValuePerShare
```

#### نسبت بدهی به سرمایه (Debt/Equity)
```typescript
DE_Ratio = TotalDebt / TotalEquity
```

### 2.2 متریک‌های کالاها

#### Supply & Demand
- تحلیل عرضه و تقاضای جهانی
- ذخایر استراتژیک
- تولید و مصرف

#### Seasonal Patterns
- الگوهای فصلی قیمت
- تأثیر فصل‌ها روی کشاورزی

### 2.3 متریک‌های رمزارزها

#### Network Activity
- تعداد تراکنش‌ها
- آدرس‌های فعال
- Hash Rate (برای POW)

#### Token Economics
- Total Supply
- Circulating Supply
- Inflation Rate
- Burn Rate

---

## 🧠 بخش 3: سنتیمنت بازار (Market Sentiment)

### 3.1 Fear & Greed Index

```typescript
interface FearGreedIndex {
  value: number;      // 0-100
  label: string;      // Extreme Fear, Fear, Neutral, Greed, Extreme Greed
  factors: {
    volatility: number;
    marketMomentum: number;
    socialMedia: number;
    surveys: number;
    dominance: number;
    trends: number;
  };
}
```

**محاسبه**:
- **0-25**: Extreme Fear (فرصت خرید)
- **25-45**: Fear
- **45-55**: Neutral
- **55-75**: Greed
- **75-100**: Extreme Greed (فرصت فروش)

### 3.2 Social Sentiment
- تحلیل اخبار اخیر
- تأثیر رویدادهای مهم
- روند جستجوهای گوگل (شبیه‌سازی)

### 3.3 Whale Activity
- فعالیت سرمایه‌گذاران بزرگ (NPC)
- تغییرات بزرگ در Ownership

---

## 🎯 بخش 4: توصیه‌های خرید/فروش (Trading Signals)

### 4.1 سیستم امتیازدهی

```typescript
interface TradingSignal {
  asset: string;
  recommendation: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  confidence: number;  // 0-100
  scores: {
    technical: number;      // امتیاز تکنیکال (-100 تا 100)
    fundamental: number;    // امتیاز فاندامنتال (-100 تا 100)
    sentiment: number;      // امتیاز سنتیمنت (-100 تا 100)
  };
  reasons: string[];        // دلایل
  targetPrice?: number;     // قیمت هدف
  stopLoss?: number;        // حد ضرر
  timeframe: string;        // بازه زمانی
}
```

### 4.2 منطق امتیازدهی تکنیکال

```typescript
function calculateTechnicalScore(asset: Asset): number {
  let score = 0;
  
  // Moving Averages (30 امتیاز)
  if (asset.price > asset.ma20) score += 15;
  if (asset.price > asset.ma50) score += 15;
  if (asset.ma20 > asset.ma50) score += 10; // Golden Cross
  
  // RSI (25 امتیاز)
  if (asset.rsi < 30) score += 25;  // Oversold
  else if (asset.rsi > 70) score -= 25;  // Overbought
  else score += (50 - asset.rsi) * 0.5;
  
  // MACD (25 امتیاز)
  if (asset.macd > asset.macdSignal) score += 25;
  else score -= 25;
  
  // Bollinger Bands (20 امتیاز)
  if (asset.price < asset.bbLower) score += 20;
  else if (asset.price > asset.bbUpper) score -= 20;
  
  return score; // -100 تا 100
}
```

### 4.3 توصیه‌ها با دلایل

**مثال خروجی**:
```
📊 تحلیل AAPL (اپل)

🟢 توصیه: خرید قوی
اطمینان: 85%

دلایل:
✅ قیمت بالای MA20 و MA50 (روند صعودی)
✅ Golden Cross تشکیل شده (MA20 > MA50)
✅ RSI در ناحیه Oversold (28) - فرصت خرید
✅ MACD صعودی و Histogram در حال افزایش
✅ حجم معاملات بالاتر از میانگین
⚠️ قیمت نزدیک باند بالایی Bollinger

قیمت هدف: $185
حد ضرر پیشنهادی: $168
بازه زمانی: میان‌مدت (5-10 روز)
```

---

## 🎨 بخش 5: رابط کاربری (UI Design)

### 5.1 صفحه آنالیزور

```
┌─────────────────────────────────────────────────────┐
│  🔍 آنالیزور مالی حرفه‌ای                          │
├─────────────────────────────────────────────────────┤
│                                                      │
│  ┌──────────────────┐  ┌──────────────────┐        │
│  │  دارایی انتخابی  │  │  بازه زمانی     │        │
│  │  AAPL (اپل)      │  │  ۳۰ روز          │        │
│  └──────────────────┘  └──────────────────┘        │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │  📊 خلاصه تحلیل                            │   │
│  │                                              │   │
│  │  توصیه: 🟢 خرید قوی                         │   │
│  │  اطمینان: ████████░░ 85%                   │   │
│  │                                              │   │
│  │  امتیازها:                                  │   │
│  │  تکنیکال:     +75  ████████████████░░       │   │
│  │  فاندامنتال:  +60  ██████████████░░         │   │
│  │  سنتیمنت:     +85  █████████████████░       │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
│  ┌──── Tab Menu ────────────────────────────────┐  │
│  │ [تکنیکال] [فاندامنتال] [سنتیمنت] [توصیه‌ها] │  │
│  └──────────────────────────────────────────────┘  │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │  📈 تحلیل تکنیکال                           │   │
│  │                                              │   │
│  │  اندیکاتورها:                               │   │
│  │  • RSI: 28 (Oversold) ✅                    │   │
│  │  • MACD: صعودی ✅                            │   │
│  │  • MA20/50: Golden Cross ✅                 │   │
│  │  • BB: نزدیک باند بالا ⚠️                   │   │
│  │  • Stochastic: 25 (Oversold) ✅             │   │
│  │                                              │   │
│  │  سطوح کلیدی:                                │   │
│  │  مقاومت: $185 | $190 | $195                │   │
│  │  حمایت:  $168 | $162 | $155                │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │  💡 توصیه‌ها و استراتژی                    │   │
│  │                                              │   │
│  │  استراتژی پیشنهادی: خرید تدریجی            │   │
│  │                                              │   │
│  │  Entry Points:                               │   │
│  │  1️⃣ $172 (40% موقعیت)                       │   │
│  │  2️⃣ $168 (30% موقعیت)                       │   │
│  │  3️⃣ $165 (30% موقعیت)                       │   │
│  │                                              │   │
│  │  🎯 Target: $185 (+7.6%)                    │   │
│  │  🛡️ Stop Loss: $160 (-6.9%)                 │   │
│  │  ⚖️ Risk/Reward: 1:1.1                       │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │  ⚠️ هشدارهای مهم                            │   │
│  │  • نوسان بالا - از اهرم بالا احتراز کنید    │   │
│  │  • اخبار مهم فردا - احتمال حرکت شدید       │   │
│  └─────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
```

### 5.2 کامپوننت‌های بصری

#### Gauge Chart (سنجه) برای اطمینان
```
    ╭───────────╮
    │     85%   │
  ╭─┴───────────┴─╮
  │ ████████████░ │
  ╰───────────────╯
```

#### Heat Map برای دارایی‌ها
```
┌─────────────────────────────┐
│  🔥 نقشه حرارتی بازار       │
├─────────────────────────────┤
│  [BTC +5.2%] [ETH +3.1%]   │
│  [AAPL +2.4%] [TSLA -1.2%] │
│  [GOLD +0.8%] [OIL -2.5%]  │
└─────────────────────────────┘
```

---

## 🧮 بخش 6: ریسک‌سنجی و مدیریت سرمایه

### 6.1 Risk Calculator

```typescript
interface RiskAnalysis {
  positionSize: number;      // حجم موقعیت (% از سرمایه)
  riskAmount: number;        // مبلغ در معرض خطر
  riskPercent: number;       // درصد ریسک
  potentialProfit: number;   // سود احتمالی
  riskReward: number;        // نسبت ریسک به ریوارد
  maxDrawdown: number;       // حداکثر افت احتمالی
  recommendation: string;
}
```

### 6.2 Position Sizing

**فرمول Kelly Criterion (ساده‌شده)**:
```typescript
function calculatePositionSize(
  winRate: number,
  avgWin: number,
  avgLoss: number,
  capital: number
): number {
  const kellyPercent = (winRate - ((1 - winRate) / (avgWin / avgLoss))) * 100;
  const safeKelly = kellyPercent * 0.25; // Quarter Kelly for safety
  return Math.min(Math.max(safeKelly, 0), 20); // Max 20% position
}
```

### 6.3 Portfolio Risk

```typescript
interface PortfolioRisk {
  totalExposure: number;     // کل اکسپوژر
  diversification: number;   // امتیاز تنوع (0-100)
  correlation: number;       // همبستگی دارایی‌ها
  beta: number;              // بتا پورتفولیو
  var95: number;             // Value at Risk 95%
  sharpeRatio: number;       // نسبت شارپ
  warnings: string[];
}
```

---

## 📊 بخش 7: گزارش عملکرد

### 7.1 متریک‌های عملکرد

```typescript
interface PerformanceMetrics {
  totalReturn: number;           // بازدهی کل (%)
  annualizedReturn: number;      // بازدهی سالانه (%)
  
  profitableTrades: number;      // تعداد معاملات سودده
  losingTrades: number;          // تعداد معاملات زیان‌ده
  winRate: number;               // نرخ برد (%)
  
  avgProfit: number;             // میانگین سود
  avgLoss: number;               // میانگین ضرر
  profitFactor: number;          // ضریب سود
  
  maxDrawdown: number;           // حداکثر افت (%)
  maxDrawdownDuration: number;   // مدت حداکثر افت (روز)
  
  sharpeRatio: number;           // نسبت شارپ
  sortinoRatio: number;          // نسبت سورتینو
  
  bestTrade: Trade;              // بهترین معامله
  worstTrade: Trade;             // بدترین معامله
  
  assetBreakdown: AssetPerformance[];  // عملکرد هر دارایی
}
```

### 7.2 نمودارهای گزارش

1. **Equity Curve**: نمودار رشد سرمایه در زمان
2. **Drawdown Chart**: نمودار افت‌های سرمایه
3. **Win/Loss Distribution**: توزیع سود و زیان
4. **Asset Allocation**: تخصیص دارایی‌ها
5. **Monthly Returns Heatmap**: نقشه حرارتی بازدهی ماهانه

---

## 🤖 بخش 8: پیش‌بینی ساده (ML Lite)

### 8.1 Linear Regression ساده

```typescript
function predictNextPrice(priceHistory: number[]): {
  predicted: number;
  confidence: number;
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
} {
  // محاسبه خط روند با Least Squares
  const n = priceHistory.length;
  const x = Array.from({length: n}, (_, i) => i);
  const y = priceHistory;
  
  const sumX = x.reduce((a, b) => a + b, 0);
  const sumY = y.reduce((a, b) => a + b, 0);
  const sumXY = x.reduce((sum, xi, i) => sum + xi * y[i], 0);
  const sumX2 = x.reduce((sum, xi) => sum + xi * xi, 0);
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  const predicted = slope * n + intercept;
  const trend = slope > 0.5 ? 'BULLISH' : slope < -0.5 ? 'BEARISH' : 'NEUTRAL';
  
  // محاسبه R² برای اطمینان
  const yMean = sumY / n;
  const ssTotal = y.reduce((sum, yi) => sum + Math.pow(yi - yMean, 2), 0);
  const ssResidual = y.reduce((sum, yi, i) => {
    const predicted = slope * i + intercept;
    return sum + Math.pow(yi - predicted, 2);
  }, 0);
  const r2 = 1 - (ssResidual / ssTotal);
  
  return {
    predicted,
    confidence: Math.round(Math.max(0, Math.min(100, r2 * 100))),
    trend
  };
}
```

### 8.2 Pattern Recognition

شناسایی الگوهای ساده:
- **Head & Shoulders**: سر و شانه
- **Double Top/Bottom**: سقف/کف دوقلو
- **Triangle**: مثلث
- **Flag**: پرچم

---

## 🎯 اولویت‌های پیاده‌سازی

### مرحله 1 (الزامی)
- [x] اندیکاتورهای موجود (MA, RSI, MACD, BB)
- [ ] سیستم امتیازدهی تکنیکال
- [ ] توصیه‌های خرید/فروش با دلایل
- [ ] UI/UX آنالیزور

### مرحله 2 (مهم)
- [ ] اندیکاتورهای جدید (Stochastic, ATR, OBV)
- [ ] Fear & Greed Index
- [ ] Risk Calculator
- [ ] گزارش عملکرد پورتفولیو

### مرحله 3 (اختیاری)
- [ ] تحلیل فاندامنتال کامل
- [ ] پیش‌بینی ML
- [ ] Pattern Recognition
- [ ] Social Sentiment

---

این طراحی جامع، آنالیزوری حرفه‌ای و کاربردی برای بازیکنان ایجاد می‌کند که تصمیم‌گیری را آسان‌تر و بازی را عمیق‌تر می‌کند.
