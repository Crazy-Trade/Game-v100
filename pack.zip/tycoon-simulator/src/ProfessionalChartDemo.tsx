// Test Chart Component - Professional Candlestick Chart Usage Example
import React, { useState, useEffect } from 'react';
import { CandlestickChart, ChartHeader, TechnicalIndicatorsPanel, VolumeAndOrderBookPanel, DrawingToolsPanel } from './components/charts';
import { useGameStoreV3 } from './store/gameStoreV3';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Button } from './components/ui/button';
import { 
  BarChart3, 
  TrendingUp, 
  Settings, 
  Maximize2,
  RefreshCw,
  Download
} from 'lucide-react';
import type { Asset, DrawingTool } from './types';

const ProfessionalChartDemo: React.FC = () => {
  const { assets, updateAssetPrice } = useGameStoreV3();
  const [selectedAssetId, setSelectedAssetId] = useState<string>('');
  const [activeIndicators, setActiveIndicators] = useState<string[]>(['sma', 'ema', 'rsi']);
  const [drawingTools, setDrawingTools] = useState<DrawingTool[]>([]);
  const [activeDrawingTool, setActiveDrawingTool] = useState<string | null>(null);
  const [chartSettings, setChartSettings] = useState({});

  // Select first available asset on mount
  useEffect(() => {
    if (assets.length > 0 && !selectedAssetId) {
      setSelectedAssetId(assets[0].id);
    }
  }, [assets, selectedAssetId]);

  const selectedAsset = assets.find(asset => asset.id === selectedAssetId);

  const handlePriceUpdate = (price: number) => {
    if (selectedAsset) {
      // Update asset price in store
      // updateAssetPrice(selectedAssetId, price);
      console.log('Price updated:', price);
    }
  };

  const handleIndicatorToggle = (indicatorId: string) => {
    setActiveIndicators(prev => 
      prev.includes(indicatorId) 
        ? prev.filter(id => id !== indicatorId)
        : [...prev, indicatorId]
    );
  };

  const handleIndicatorChange = (indicatorId: string, settings: any) => {
    console.log('Indicator settings changed:', indicatorId, settings);
  };

  const handleDrawingToolSelect = (toolId: string | null) => {
    setActiveDrawingTool(toolId);
  };

  const handleClearDrawingTools = () => {
    setDrawingTools([]);
  };

  const handleUndoDrawing = () => {
    if (drawingTools.length > 0) {
      setDrawingTools(prev => prev.slice(0, -1));
    }
  };

  const handleRedoDrawing = () => {
    // Implementation for redo functionality
    console.log('Redo drawing');
  };

  if (!selectedAsset) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Card className="p-8">
          <CardContent className="text-center">
            <BarChart3 className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-semibold mb-2">نمودار حرفه‌ای</h2>
            <p className="text-muted-foreground mb-4">
              بازی Tycoon Simulator 3.0 - نمودار شمعی مشابه TradingView
            </p>
            <div className="text-sm text-muted-foreground">
              {assets.length === 0 
                ? 'در حال بارگذاری دارایی‌ها...' 
                : 'دارایی انتخاب نشده است'
              }
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center space-x-2">
              <BarChart3 className="w-8 h-8 text-primary" />
              <span>نمودار حرفه‌ای</span>
            </h1>
            <p className="text-muted-foreground">
              نمودار شمعی پیشرفته با امکانات TradingView
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant="outline" className="gap-1">
              <TrendingUp className="w-3 h-3" />
              Real-time Data
            </Badge>
            <Button variant="outline" size="sm">
              <RefreshCw className="w-4 h-4" />
              به‌روزرسانی
            </Button>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4" />
              خروجی
            </Button>
          </div>
        </div>

        {/* Asset Selector */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium">انتخاب دارایی:</span>
              <div className="flex space-x-2 overflow-x-auto">
                {assets.slice(0, 8).map((asset) => (
                  <Button
                    key={asset.id}
                    variant={selectedAssetId === asset.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedAssetId(asset.id)}
                    className="whitespace-nowrap"
                  >
                    {asset.symbol}
                    <span className="ml-1 text-xs">
                      ${asset.currentPrice.toFixed(2)}
                    </span>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Chart Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Technical Indicators */}
          <div className="lg:col-span-1 space-y-4">
            <TechnicalIndicatorsPanel
              activeIndicators={activeIndicators}
              onToggleIndicator={handleIndicatorToggle}
              onIndicatorChange={handleIndicatorChange}
              className="w-full"
            />
            
            <DrawingToolsPanel
              activeTool={activeDrawingTool}
              onToolSelect={handleDrawingToolSelect}
              onToolSettingsChange={setChartSettings}
              onClearTools={handleClearDrawingTools}
              onUndo={handleUndoDrawing}
              onRedo={handleRedoDrawing}
              canUndo={drawingTools.length > 0}
              canRedo={false}
              tools={drawingTools}
              className="w-full"
            />
          </div>

          {/* Main Chart Area */}
          <div className="lg:col-span-3 space-y-4">
            {/* Chart Header */}
            <ChartHeader
              asset={selectedAsset}
              onWatchlistToggle={(assetId) => console.log('Toggle watchlist:', assetId)}
              onAlertToggle={(assetId) => console.log('Toggle alert:', assetId)}
              onExport={(assetId) => console.log('Export:', assetId)}
              onShare={(assetId) => console.log('Share:', assetId)}
              isWatchlisted={false}
              hasAlerts={false}
            />

            {/* Main Chart */}
            <CandlestickChart
              assetId={selectedAssetId}
              height={600}
              showControls={true}
              showTechnicalIndicators={true}
              showDrawingTools={true}
              onPriceUpdate={handlePriceUpdate}
            />

            {/* Bottom Tabs - Volume and Order Book */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <VolumeAndOrderBookPanel
                priceHistory={selectedAsset.priceHistory}
                currentPrice={selectedAsset.currentPrice}
                className="w-full"
              />
              
              <Card>
                <CardContent className="p-4">
                  <div className="text-center text-muted-foreground">
                    <Settings className="w-12 h-12 mx-auto mb-2" />
                    <h3 className="font-medium">تنظیمات پیشرفته</h3>
                    <p className="text-sm">
                      ابزارهای تحلیل و تنظیمات پیشرفته نمودار
                    </p>
                    <div className="mt-4 space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>بازه زمانی:</span>
                        <Badge variant="secondary">1d</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>نمودار:</span>
                        <Badge variant="secondary">شمعی</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>حجم:</span>
                        <Badge variant="secondary">فعال</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Features Summary */}
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">ویژگی‌های نمودار حرفه‌ای</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <h4 className="font-medium text-green-600">نمودارهای حرفه‌ای</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• نمودارهای شمعی، خطی، منطقه‌ای</li>
                  <li>• Heikin Ashi و Renko charts</li>
                  <li>• چندین تایم فریم (1m تا 1M)</li>
                  <li>• به‌روزرسانی real-time</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-blue-600">شاخص‌های تکنیکال</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Moving Averages (SMA, EMA)</li>
                  <li>• Bollinger Bands</li>
                  <li>• RSI, MACD, ATR</li>
                  <li>• شاخص‌های سفارشی</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-purple-600">ابزارهای ترسیم</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• خطوط روند و افقی/عمودی</li>
                  <li>• اشکال هندسی</li>
                  <li>• فیبوناچی و کانال‌ها</li>
                  <li>• یادداشت‌های متنی</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-orange-600">داده بازار</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• ۸۸ دارایی با داده واقعی</li>
                  <li>• حجم معاملات و اسپرد</li>
                  <li>• دفتر سفارشات (Order Book)</li>
                  <li>• آمار بازار پیشرفته</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-red-600">رابط کاربری</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• رابط مشابه TradingView</li>
                  <li>• پشتیبانی از کیبورد شورت‌کات‌ها</li>
                  <li>• حالت تمام صفحه</li>
                  <li>• تم تاریک/روشن</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-indigo-600">امکانات پیشرفته</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• ذخیره و بارگذاری تنظیمات</li>
                  <li>• خروجی نمودار (PNG/SVG)</li>
                  <li>• هشدارهای قیمتی</li>
                  <li>• مقایسه چند دارایی</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProfessionalChartDemo;