import { motion } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { Users, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { useNotification } from '../ui/NotificationProvider';
import { useState } from 'react';

export default function HRManagement() {
  const company = useGameStore(state => state.company);
  const updateCompany = useGameStore(state => state.updateCompany);
  const notify = useNotification();
  const [salaryAdjustment, setSalaryAdjustment] = useState(0);

  if (!company) return null;

  const hr = company.hr || {
    salaryLevel: 70,
    trainingBudget: 5000,
    morale: 70,
    productivity: 75,
    strikeRisk: 10,
  };

  const handleSalaryChange = () => {
    const newSalaryLevel = Math.max(30, Math.min(100, hr.salaryLevel + salaryAdjustment));
    const moraleChange = salaryAdjustment > 0 ? 5 : -5;
    const newMorale = Math.max(0, Math.min(100, hr.morale + moraleChange));
    const newStrikeRisk = newMorale < 40 ? 80 : newMorale < 60 ? 40 : 10;

    updateCompany({
      ...company,
      hr: {
        ...hr,
        salaryLevel: newSalaryLevel,
        morale: newMorale,
        strikeRisk: newStrikeRisk,
        productivity: Math.min(100, newMorale + 10),
      },
    });

    notify.success(`سطح حقوق به ${newSalaryLevel}% تغییر یافت`);
    setSalaryAdjustment(0);
  };

  const handleTraining = () => {
    if (company.cash < 20000) {
      notify.error('موجودی کافی نیست!');
      return;
    }

    updateCompany({
      ...company,
      cash: company.cash - 20000,
      hr: {
        ...hr,
        trainingBudget: hr.trainingBudget + 20000,
        productivity: Math.min(100, hr.productivity + 5),
        morale: Math.min(100, hr.morale + 3),
      },
    });

    notify.success('برنامه آموزشی با موفقیت اجرا شد!');
  };

  const handleHireEmployees = () => {
    if (company.cash < 50000) {
      notify.error('موجودی کافی نیست!');
      return;
    }

    updateCompany({
      ...company,
      cash: company.cash - 50000,
      employees: company.employees + 10,
      productionLevel: Math.min(100, company.productionLevel + 5),
    });

    notify.success('10 کارمند جدید استخدام شدند!');
  };

  return (
    <div className="bg-slate-800 rounded-lg p-6 space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Users className="w-6 h-6 text-cyan-500" />
        <h4 className="text-lg font-bold text-white">منابع انسانی (HR)</h4>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-900 rounded-lg p-4">
          <p className="text-sm text-slate-400">تعداد کارکنان</p>
          <p className="text-2xl font-bold text-white">{company.employees}</p>
        </div>
        <div className="bg-slate-900 rounded-lg p-4">
          <p className="text-sm text-slate-400">روحیه</p>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex-1 bg-slate-700 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${
                  hr.morale >= 70 ? 'bg-green-500' : hr.morale >= 40 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${hr.morale}%` }}
              />
            </div>
            <span className="text-white font-bold text-sm">{hr.morale}%</span>
          </div>
        </div>
        <div className="bg-slate-900 rounded-lg p-4">
          <p className="text-sm text-slate-400">بهره‌وری</p>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex-1 bg-slate-700 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full"
                style={{ width: `${hr.productivity}%` }}
              />
            </div>
            <span className="text-white font-bold text-sm">{hr.productivity}%</span>
          </div>
        </div>
        <div className="bg-slate-900 rounded-lg p-4">
          <p className="text-sm text-slate-400">ریسک اعتصاب</p>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex-1 bg-slate-700 rounded-full h-2">
              <div
                className="bg-red-500 h-2 rounded-full"
                style={{ width: `${hr.strikeRisk}%` }}
              />
            </div>
            <span className="text-white font-bold text-sm">{hr.strikeRisk}%</span>
          </div>
        </div>
      </div>

      {/* Salary Adjustment */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h5 className="text-sm font-medium text-slate-400">سطح حقوق</h5>
          <span className="text-white font-bold">{hr.salaryLevel}%</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSalaryAdjustment(salaryAdjustment - 10)}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
          >
            -10%
          </button>
          <div className="flex-1 text-center">
            <span className={`text-xl font-bold ${salaryAdjustment >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {salaryAdjustment >= 0 ? '+' : ''}{salaryAdjustment}%
            </span>
          </div>
          <button
            onClick={() => setSalaryAdjustment(salaryAdjustment + 10)}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
          >
            +10%
          </button>
        </div>
        {salaryAdjustment !== 0 && (
          <button
            onClick={handleSalaryChange}
            className="w-full mt-3 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium transition-colors"
          >
            اعمال تغییرات
          </button>
        )}
      </div>

      {/* Actions */}
      <div className="grid grid-cols-2 gap-3">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleTraining}
          className="py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
        >
          <TrendingUp className="w-5 h-5 mx-auto mb-1" />
          <span className="text-sm">برنامه آموزشی</span>
          <p className="text-xs opacity-75">$20,000</p>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleHireEmployees}
          className="py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors"
        >
          <Users className="w-5 h-5 mx-auto mb-1" />
          <span className="text-sm">استخدام 10 نفر</span>
          <p className="text-xs opacity-75">$50,000</p>
        </motion.button>
      </div>

      {/* Warning */}
      {hr.morale < 40 && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
          <TrendingDown className="w-5 h-5 text-red-500" />
          <p className="text-sm text-red-400">هشدار: روحیه پایین - احتمال اعتصاب کارکنان!</p>
        </div>
      )}
    </div>
  );
}
