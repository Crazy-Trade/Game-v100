import React, { useState } from 'react';
import {
  Rocket,
  CheckCircle2,
  Clock,
  XCircle,
  Lock,
  TrendingUp,
  Calendar,
  Target,
  Zap,
  DollarSign
} from 'lucide-react';
import type { Milestone, MilestoneStatus } from '../../types';

interface CryptoRoadmapProps {
  milestones: Milestone[];
  currentDay: number;
  onStartMilestone: (milestoneId: string) => void;
}

// رنگ‌ها و آیکون‌های وضعیت
const statusConfig: Record<MilestoneStatus, { color: string; icon: React.ReactNode; label: string }> = {
  LOCKED: {
    color: 'bg-muted/20 text-muted border-muted/30',
    icon: <Lock size={20} />,
    label: 'قفل شده'
  },
  ACTIVE: {
    color: 'bg-blue/20 text-blue border-blue/40',
    icon: <Clock size={20} />,
    label: 'در حال انجام'
  },
  COMPLETED: {
    color: 'bg-success/20 text-success border-success/40',
    icon: <CheckCircle2 size={20} />,
    label: 'تکمیل شده'
  },
  FAILED: {
    color: 'bg-danger/20 text-danger border-danger/40',
    icon: <XCircle size={20} />,
    label: 'شکست خورده'
  }
};

export const CryptoRoadmap: React.FC<CryptoRoadmapProps> = ({ 
  milestones, 
  currentDay, 
  onStartMilestone 
}) => {
  const [selectedMilestone, setSelectedMilestone] = useState<string | null>(null);

  // محاسبه آمار کلی
  const totalMilestones = milestones.length;
  const completedMilestones = milestones.filter(m => m.status === 'COMPLETED').length;
  const activeMilestones = milestones.filter(m => m.status === 'ACTIVE').length;
  const failedMilestones = milestones.filter(m => m.status === 'FAILED').length;
  const overallProgress = (completedMilestones / totalMilestones) * 100;

  const selected = milestones.find(m => m.id === selectedMilestone);

  return (
    <div className="glass-card p-6 space-y-6">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold gradient-text flex items-center gap-2">
          <Rocket size={24} />
          نقشه راه رمزارز
        </h3>
        <div className="text-right">
          <div className="text-xs text-muted">پیشرفت کلی</div>
          <div className="text-lg font-bold text-gold">{overallProgress.toFixed(0)}%</div>
        </div>
      </div>

      {/* آمار سریع */}
      <div className="grid grid-cols-4 gap-3">
        <div className="glass-card p-3 text-center">
          <div className="text-2xl font-bold text-gold mb-1">{totalMilestones}</div>
          <div className="text-xs text-muted">کل</div>
        </div>
        <div className="glass-card p-3 text-center">
          <div className="text-2xl font-bold text-success mb-1">{completedMilestones}</div>
          <div className="text-xs text-muted">تکمیل شده</div>
        </div>
        <div className="glass-card p-3 text-center">
          <div className="text-2xl font-bold text-blue mb-1">{activeMilestones}</div>
          <div className="text-xs text-muted">در حال انجام</div>
        </div>
        <div className="glass-card p-3 text-center">
          <div className="text-2xl font-bold text-danger mb-1">{failedMilestones}</div>
          <div className="text-xs text-muted">شکست خورده</div>
        </div>
      </div>

      {/* نوار پیشرفت کلی */}
      <div>
        <div className="h-3 bg-navy/50 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-gold via-blue to-success transition-all duration-500"
            style={{ width: `${overallProgress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* لیست milestone‌ها */}
        <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar">
          {milestones.map((milestone, index) => {
            const config = statusConfig[milestone.status];
            const isSelected = selectedMilestone === milestone.id;
            const daysRemaining = milestone.deadline - currentDay;

            return (
              <div
                key={milestone.id}
                onClick={() => setSelectedMilestone(milestone.id)}
                className={`p-4 rounded-lg border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-br from-gold/20 to-blue/20 border-gold'
                    : `${config.color} hover:scale-[1.02]`
                }`}
              >
                {/* شماره و وضعیت */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      milestone.status === 'COMPLETED' ? 'bg-success/30 text-success' : 'bg-gold/30 text-gold'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex items-center gap-1.5">
                      {config.icon}
                      <span className="text-xs">{config.label}</span>
                    </div>
                  </div>
                  
                  {/* پیشرفت */}
                  {milestone.status === 'ACTIVE' && (
                    <div className="text-sm font-bold text-blue">
                      {milestone.progress}%
                    </div>
                  )}
                </div>

                {/* عنوان */}
                <h4 className="font-bold text-white mb-1">{milestone.name}</h4>
                
                {/* ددلاین */}
                {milestone.status !== 'COMPLETED' && (
                  <div className="flex items-center gap-1.5 text-xs text-muted">
                    <Calendar size={12} />
                    {milestone.status === 'ACTIVE' ? (
                      <span className={daysRemaining < 5 ? 'text-danger' : ''}>
                        {daysRemaining} روز باقی‌مانده
                      </span>
                    ) : (
                      <span>ددلاین: روز {milestone.deadline}</span>
                    )}
                  </div>
                )}

                {/* نوار پیشرفت */}
                {milestone.status === 'ACTIVE' && (
                  <div className="mt-2 h-1.5 bg-navy/50 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue transition-all"
                      style={{ width: `${milestone.progress}%` }}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* جزئیات milestone انتخاب شده */}
        <div>
          {selected ? (
            <div className={`glass-card p-5 space-y-4 border ${statusConfig[selected.status].color}`}>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-bold text-white mb-2">{selected.name}</h3>
                  <p className="text-sm text-muted">{selected.description}</p>
                </div>
                {statusConfig[selected.status].icon}
              </div>

              {/* نیازمندی‌ها */}
              {selected.status === 'LOCKED' && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-bold text-gold">
                    <Target size={16} />
                    نیازمندی‌ها
                  </div>
                  <div className="space-y-1.5 text-sm">
                    {selected.requirements.funding && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted flex items-center gap-1.5">
                          <DollarSign size={14} />
                          بودجه
                        </span>
                        <span className="font-bold">${selected.requirements.funding.toLocaleString()}</span>
                      </div>
                    )}
                    {selected.requirements.developers && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted">توسعه‌دهندگان</span>
                        <span className="font-bold">{selected.requirements.developers}</span>
                      </div>
                    )}
                    {selected.requirements.marketing && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted">بودجه بازاریابی</span>
                        <span className="font-bold">${selected.requirements.marketing.toLocaleString()}</span>
                      </div>
                    )}
                    {selected.requirements.techLevel && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted">سطح فناوری</span>
                        <span className="font-bold">{selected.requirements.techLevel}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* پیشرفت */}
              {selected.status === 'ACTIVE' && (
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-muted">پیشرفت</span>
                    <span className="font-bold text-blue">{selected.progress}%</span>
                  </div>
                  <div className="h-3 bg-navy/50 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue to-success transition-all"
                      style={{ width: `${selected.progress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* تأثیرات */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-bold text-gold">
                  <Zap size={16} />
                  تأثیرات
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted">تأثیر قیمت</span>
                    <span className={`font-bold flex items-center gap-1 ${
                      selected.effects.priceImpact >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      <TrendingUp size={14} />
                      {selected.effects.priceImpact >= 0 ? '+' : ''}{selected.effects.priceImpact}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted">پاداش اعتبار</span>
                    <span className="font-bold text-gold">+{selected.effects.credibilityBonus}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted">افزایش پذیرش</span>
                    <span className="font-bold text-blue">+{selected.effects.adoptionIncrease}%</span>
                  </div>
                  {selected.effects.liquidityBonus && (
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted">پاداش نقدینگی</span>
                      <span className="font-bold text-success">+{selected.effects.liquidityBonus}%</span>
                    </div>
                  )}
                </div>
              </div>

              {/* دکمه شروع */}
              {selected.status === 'LOCKED' && (
                <button
                  onClick={() => onStartMilestone(selected.id)}
                  className="w-full py-3 bg-gradient-to-r from-gold to-blue rounded-lg font-bold text-navy hover:scale-105 transition-transform flex items-center justify-center gap-2"
                >
                  <Rocket size={18} />
                  شروع Milestone
                </button>
              )}

              {/* اطلاعات زمانی */}
              <div className="pt-3 border-t border-gold/20 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-xs text-muted mb-1">ددلاین</div>
                  <div className="font-bold">روز {selected.deadline}</div>
                </div>
                {selected.startDay && (
                  <div>
                    <div className="text-xs text-muted mb-1">شروع</div>
                    <div className="font-bold">روز {selected.startDay}</div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="glass-card p-8 text-center text-muted h-full flex items-center justify-center">
              <div>
                <Rocket size={48} className="mx-auto mb-3 opacity-50" />
                <p>یک milestone را انتخاب کنید</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
