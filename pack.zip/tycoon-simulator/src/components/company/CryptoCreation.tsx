import { useState } from 'react';
import { useGameStore } from '../../store/gameStore';
import { Bitcoin, FileText, Rocket, TrendingUp, Code, Zap, CheckCircle, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { CryptoRoadmap } from './CryptoRoadmap';

export default function CryptoCreation() {
  const company = useGameStore(state => state.company);
  const crypto = useGameStore(state => state.crypto);
  const player = useGameStore(state => state.player);
  const game = useGameStore(state => state.game);
  const startCrypto = useGameStore(state => state.startCrypto);
  const advanceCryptoPhase = useGameStore(state => state.advanceCryptoPhase);
  const launchICO = useGameStore(state => state.launchICO);
  const listCrypto = useGameStore(state => state.listCrypto);
  const startMilestone = useGameStore(state => state.startMilestone);
  
  const [tokenName, setTokenName] = useState('');
  const [tokenSymbol, setTokenSymbol] = useState('');
  const [utility, setUtility] = useState('');

  if (!company || !company.isUnlocked) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-8 text-center">
        <Bitcoin className="w-16 h-16 mx-auto text-slate-600 mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">شرکت فعال نیست</h3>
        <p className="text-slate-400">ابتدا باید شرکت خود را فعال کنید</p>
      </div>
    );
  }

  const canStartCrypto = company.techLevel >= 5 && !crypto;

  // اگر هنوز پروژه رمزارز شروع نشده
  if (!crypto) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Bitcoin className="w-8 h-8 text-amber-500" />
          <h3 className="text-2xl font-bold text-white">ساخت رمزارز</h3>
        </div>

        <div className="bg-slate-800 rounded-lg p-6">
          <h4 className="text-lg font-bold text-white mb-4">الزامات ساخت رمزارز</h4>
          <div className="flex items-center gap-3">
            {company.techLevel >= 5 ? (
              <CheckCircle className="w-5 h-5 text-green-400" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400" />
            )}
            <div>
              <p className="text-sm text-slate-400">سطح فناوری</p>
              <p className="text-white font-bold">سطح {company.techLevel} / 5</p>
            </div>
          </div>
        </div>

        {canStartCrypto ? (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-bold mb-2">نام توکن</label>
              <input
                type="text"
                value={tokenName}
                onChange={(e) => setTokenName(e.target.value)}
                placeholder="مثال: MiniMax Coin"
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-white font-bold mb-2">نماد توکن</label>
              <input
                type="text"
                value={tokenSymbol}
                onChange={(e) => setTokenSymbol(e.target.value.toUpperCase())}
                placeholder="مثال: MMX"
                maxLength={5}
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-white font-bold mb-2">کاربرد توکن</label>
              <textarea
                value={utility}
                onChange={(e) => setUtility(e.target.value)}
                placeholder="توضیح دهید که این توکن چه کاربردی دارد..."
                rows={4}
                className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white focus:border-amber-500 focus:outline-none resize-none"
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                if (tokenName && tokenSymbol && utility) {
                  startCrypto(tokenName, tokenSymbol, utility);
                }
              }}
              disabled={!tokenName || !tokenSymbol || !utility}
              className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              شروع پروژه رمزارز
            </motion.button>
          </div>
        ) : (
          <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 text-center">
            <AlertCircle className="w-8 h-8 mx-auto text-red-400 mb-2" />
            <p className="text-red-400">
              برای ساخت رمزارز به سطح فناوری 5 نیاز دارید
            </p>
          </div>
        )}
      </div>
    );
  }

  // مراحل مختلف ساخت رمزارز
  const phases = [
    {
      id: 'research',
      title: 'تحقیق و طراحی',
      description: 'تحقیق بازار و طراحی معماری توکن',
      icon: FileText,
      duration: 30,
      cost: 500000,
      color: 'text-blue-400',
    },
    {
      id: 'development',
      title: 'توسعه و قراردادهای هوشمند',
      description: 'نوشتن کد قراردادهای هوشمند و تست امنیتی',
      icon: Code,
      duration: 45,
      cost: 1000000,
      color: 'text-purple-400',
    },
    {
      id: 'ico',
      title: 'ICO و جذب سرمایه',
      description: 'فروش اولیه توکن به سرمایه‌گذاران',
      icon: Rocket,
      duration: 14,
      cost: 2000000,
      color: 'text-orange-400',
    },
    {
      id: 'listed',
      title: 'لیست در صرافی',
      description: 'توکن شما در صرافی‌های رمزارز معامله می‌شود',
      icon: TrendingUp,
      duration: 0,
      cost: 0,
      color: 'text-green-400',
    },
  ];

  const currentPhaseIndex = phases.findIndex(p => p.id === crypto.phase);
  const currentPhase = phases[currentPhaseIndex];
  const PhaseIcon = currentPhase.icon;

  const canAdvance = crypto.daysInPhase >= currentPhase.duration;

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bitcoin className="w-8 h-8 text-amber-500" />
          <div>
            <h3 className="text-2xl font-bold text-white">{crypto.tokenName}</h3>
            <p className="text-slate-400">${crypto.tokenSymbol}</p>
          </div>
        </div>
        {crypto.listed && (
          <div className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            <span className="font-bold">لیست شده</span>
          </div>
        )}
      </div>

      {/* نقشه راه */}
      <div className="bg-slate-800 rounded-lg p-6">
        <h4 className="text-lg font-bold text-white mb-6">نقشه راه توسعه</h4>
        <div className="space-y-4">
          {phases.map((phase, idx) => {
            const isCompleted = idx < currentPhaseIndex;
            const isCurrent = idx === currentPhaseIndex;
            const Icon = phase.icon;
            
            return (
              <div
                key={phase.id}
                className={`flex items-center gap-4 p-4 rounded-lg border-2 transition-colors ${
                  isCompleted
                    ? 'border-green-500 bg-green-500/10'
                    : isCurrent
                    ? 'border-amber-500 bg-amber-500/10'
                    : 'border-slate-700 bg-slate-800/50'
                }`}
              >
                <Icon className={`w-8 h-8 ${phase.color}`} />
                <div className="flex-1">
                  <h5 className="text-white font-bold">{phase.title}</h5>
                  <p className="text-slate-400 text-sm">{phase.description}</p>
                  {phase.duration > 0 && (
                    <p className="text-slate-500 text-xs mt-1">
                      مدت: {phase.duration} روز | هزینه: ${(phase.cost / 1000).toFixed(0)}K
                    </p>
                  )}
                </div>
                {isCompleted && (
                  <CheckCircle className="w-6 h-6 text-green-400" />
                )}
                {isCurrent && (
                  <div className="text-right">
                    <p className="text-white font-bold text-sm">
                      {crypto.daysInPhase} / {phase.duration} روز
                    </p>
                    <div className="w-24 h-2 bg-slate-700 rounded-full overflow-hidden mt-1">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-orange-500"
                        style={{ width: `${(crypto.daysInPhase / phase.duration) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* اطلاعات توکن */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-slate-400 text-sm mb-1">قیمت توکن</p>
          <p className="text-2xl font-bold text-white">${crypto.tokenPrice.toFixed(4)}</p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-slate-400 text-sm mb-1">ارزش بازار</p>
          <p className="text-2xl font-bold text-white">
            ${(crypto.marketCap / 1000000).toFixed(2)}M
          </p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-slate-400 text-sm mb-1">پیشرفت</p>
          <p className="text-2xl font-bold text-amber-400">{crypto.roadmapProgress}%</p>
        </div>
      </div>

      {/* کاربرد توکن */}
      <div className="bg-slate-800 rounded-lg p-6">
        <h4 className="text-lg font-bold text-white mb-2">کاربرد توکن</h4>
        <p className="text-slate-300 leading-relaxed">{crypto.utility}</p>
      </div>

      {/* نقشه راه رمزارز */}
      {crypto.milestones && crypto.milestones.length > 0 && (
        <CryptoRoadmap 
          milestones={crypto.milestones} 
          currentDay={game.currentDay} 
          onStartMilestone={startMilestone} 
        />
      )}

      {/* دکمه‌های عملیات */}
      {!crypto.listed && canAdvance && (
        <div className="space-y-3">
          {crypto.phase === 'ico' ? (
            <>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => launchICO()}
                disabled={company.cash < 2000000}
                className="w-full py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-lg hover:from-purple-600 hover:to-pink-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Rocket className="w-5 h-5" />
                <span>راه‌اندازی ICO (هزینه: $2M)</span>
              </motion.button>
              
              {crypto.daysInPhase >= 14 && (
                <motion.button
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  onClick={() => listCrypto()}
                  disabled={company.cash < 5000000}
                  className="w-full py-4 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:from-green-600 hover:to-emerald-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <TrendingUp className="w-5 h-5" />
                  <span>لیست در صرافی (هزینه: $5M)</span>
                </motion.button>
              )}
            </>
          ) : (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => advanceCryptoPhase()}
              disabled={company.cash < currentPhase.cost}
              className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Zap className="w-5 h-5" />
              <span>انتقال به مرحله بعدی (هزینه: ${(currentPhase.cost / 1000).toFixed(0)}K)</span>
            </motion.button>
          )}
        </div>
      )}

      {crypto.listed && (
        <div className="bg-green-500/10 border border-green-500 rounded-lg p-4 text-center">
          <CheckCircle className="w-8 h-8 mx-auto text-green-400 mb-2" />
          <p className="text-green-400 font-bold">
            توکن شما با موفقیت در صرافی‌ها لیست شد!
          </p>
          <p className="text-slate-400 text-sm mt-1">
            اکنون می‌توانید درآمد از معاملات توکن خود کسب کنید
          </p>
        </div>
      )}
    </div>
  );
}
