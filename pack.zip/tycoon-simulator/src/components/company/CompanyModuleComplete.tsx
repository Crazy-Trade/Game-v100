import { motion } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { Building2, TrendingUp, Users, Zap, Package, DollarSign, Briefcase } from 'lucide-react';
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import SupplyChainManagement from './SupplyChainManagement';
import RnDDepartment from './RnDDepartment';
import HRManagement from './HRManagement';

export default function CompanyModuleComplete() {
  const player = useGameStore(state => state.player);
  const company = useGameStore(state => state.company);
  const unlockCompany = useGameStore(state => state.unlockCompany);
  const updateCompany = useGameStore(state => state.updateCompany);

  const [companyName, setCompanyName] = useState('');
  const [showUnlockDialog, setShowUnlockDialog] = useState(false);

  const canUnlock = player.totalValue >= 50000000;

  const handleUnlock = () => {
    if (companyName.trim() && canUnlock) {
      unlockCompany(companyName);
      setShowUnlockDialog(false);
    }
  };

  if (!company) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-8">
        <div className="text-center">
          <Building2 className="w-16 h-16 text-slate-700 mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-white mb-2">ماژول شرکت</h3>
          <p className="text-slate-400 mb-6">
            برای باز کردن ماژول مدیریت شرکت به $50,000,000 نیاز دارید
          </p>
          <div className="mb-6">
            <p className="text-sm text-slate-500 mb-2">پیشرفت شما</p>
            <div className="w-full bg-slate-800 rounded-full h-4 mb-2">
              <div
                className="bg-gradient-to-r from-amber-600 to-amber-500 h-4 rounded-full transition-all"
                style={{ width: `${Math.min((player.totalValue / 50000000) * 100, 100)}%` }}
              />
            </div>
            <p className="text-white font-bold">
              ${player.totalValue.toFixed(2)} / $50,000,000.00
            </p>
            <p className="text-slate-400 text-sm mt-1">
              {((player.totalValue / 50000000) * 100).toFixed(2)}% از هدف
            </p>
          </div>
          {canUnlock && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowUnlockDialog(true)}
              className="px-8 py-3 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-lg font-bold shadow-lg shadow-amber-500/30"
            >
              باز کردن ماژول شرکت
            </motion.button>
          )}
        </div>

        {showUnlockDialog && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-slate-800 rounded-xl p-8 max-w-md w-full border border-slate-700"
            >
              <h3 className="text-2xl font-bold text-white mb-4">نام شرکت خود را وارد کنید</h3>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="نام شرکت..."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white mb-6 focus:outline-none focus:border-amber-500"
                autoFocus
              />
              <div className="flex gap-3">
                <button
                  onClick={handleUnlock}
                  disabled={!companyName.trim()}
                  className="flex-1 py-3 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-lg font-bold disabled:opacity-50"
                >
                  ایجاد شرکت
                </button>
                <button
                  onClick={() => setShowUnlockDialog(false)}
                  className="flex-1 py-3 bg-slate-700 text-white rounded-lg font-medium"
                >
                  انصراف
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-white flex items-center gap-2">
            <Building2 className="w-8 h-8 text-amber-500" />
            {company.companyName}
          </h3>
          <p className="text-slate-400 text-sm mt-1">
            ارزش شرکت: ${company.companyValue.toLocaleString()}
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-slate-400">موجودی نقدی شرکت</p>
          <p className="text-2xl font-bold text-green-400">${company.cash.toLocaleString()}</p>
        </div>
      </div>

      {/* Company Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-green-500" />
            <p className="text-slate-400 text-sm">درآمد</p>
          </div>
          <p className="text-white font-bold text-xl">
            ${company.revenue.toLocaleString()}
          </p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-blue-500" />
            <p className="text-slate-400 text-sm">سود</p>
          </div>
          <p className="text-white font-bold text-xl">
            ${company.profit.toLocaleString()}
          </p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-5 h-5 text-purple-500" />
            <p className="text-slate-400 text-sm">کارکنان</p>
          </div>
          <p className="text-white font-bold text-xl">{company.employees}</p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Package className="w-5 h-5 text-amber-500" />
            <p className="text-slate-400 text-sm">تولید</p>
          </div>
          <p className="text-white font-bold text-xl">{company.productionLevel}%</p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-red-500" />
            <p className="text-slate-400 text-sm">روحیه</p>
          </div>
          <p className="text-white font-bold text-xl">{company.morale}%</p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Briefcase className="w-5 h-5 text-cyan-500" />
            <p className="text-slate-400 text-sm">سطح فناوری</p>
          </div>
          <p className="text-white font-bold text-xl">سطح {company.techLevel}</p>
        </div>
      </div>

      {/* Management Tabs */}
      <Tabs defaultValue="supply" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-slate-800 border border-slate-700">
          <TabsTrigger value="supply">زنجیره تامین</TabsTrigger>
          <TabsTrigger value="rnd">R&D</TabsTrigger>
          <TabsTrigger value="hr">منابع انسانی</TabsTrigger>
        </TabsList>
        
        <TabsContent value="supply" className="mt-4">
          <SupplyChainManagement />
        </TabsContent>
        
        <TabsContent value="rnd" className="mt-4">
          <RnDDepartment />
        </TabsContent>
        
        <TabsContent value="hr" className="mt-4">
          <HRManagement />
        </TabsContent>
      </Tabs>

      {/* Future Features Note */}
      <div className="bg-slate-800/50 rounded-lg p-6 border border-slate-700">
        <p className="text-slate-400 text-sm text-center">
          امکانات بیشتر مانند بازاریابی، IPO و ساخت رمزارز در نسخه‌های بعدی اضافه خواهد شد.
        </p>
      </div>
    </div>
  );
}
