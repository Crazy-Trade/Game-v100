import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Zap } from 'lucide-react';
import type { CompanyValueHistory } from '../../types';

interface CompanyValueChartProps {
  valueHistory: CompanyValueHistory[];
  currentValue: number;
}

export const CompanyValueChart: React.FC<CompanyValueChartProps> = ({ valueHistory, currentValue }) => {
  if (valueHistory.length === 0) {
    return (
      <div className="glass-card p-6">
        <h3 className="text-xl font-bold mb-4 gradient-text">نمودار ارزش شرکت</h3>
        <div className="text-center text-muted py-8">
          هنوز داده‌ای برای نمایش وجود ندارد
        </div>
      </div>
    );
  }

  // آماده‌سازی داده برای چارت
  const chartData = valueHistory.map(item => ({
    day: item.day,
    value: item.value,
    change: item.change,
    events: item.events
  }));

  // محاسبه آمار
  const totalChange = currentValue - valueHistory[0].value;
  const totalChangePercent = ((currentValue - valueHistory[0].value) / valueHistory[0].value) * 100;
  const maxValue = Math.max(...valueHistory.map(h => h.value));
  const minValue = Math.min(...valueHistory.map(h => h.value));

  // رویدادهای مهم (نقاط قرمز/سبز)
  const eventPoints = valueHistory.filter(h => h.events.length > 0);

  return (
    <div className="glass-card p-6 space-y-4">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold gradient-text">نمودار ارزش شرکت</h3>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-sm text-muted">ارزش فعلی</div>
            <div className="text-xl font-bold">${currentValue.toLocaleString()}</div>
          </div>
          <div className={`flex items-center gap-1 px-3 py-1.5 rounded-lg ${
            totalChange >= 0 ? 'bg-success/10 text-success' : 'bg-danger/10 text-danger'
          }`}>
            {totalChange >= 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            <span className="font-bold">
              {totalChangePercent >= 0 ? '+' : ''}{totalChangePercent.toFixed(2)}%
            </span>
          </div>
        </div>
      </div>

      {/* چارت */}
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="rgba(255, 184, 0, 0.1)" 
              vertical={false}
            />
            <XAxis 
              dataKey="day" 
              stroke="#666"
              tick={{ fill: '#999', fontSize: 12 }}
              tickFormatter={(value) => `روز ${value}`}
            />
            <YAxis 
              stroke="#666"
              tick={{ fill: '#999', fontSize: 12 }}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
              domain={[minValue * 0.95, maxValue * 1.05]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(10, 14, 39, 0.95)',
                border: '1px solid rgba(255, 184, 0, 0.3)',
                borderRadius: '8px',
                padding: '12px',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.4)'
              }}
              labelStyle={{ color: '#FFB800', fontWeight: 'bold', marginBottom: '8px' }}
              itemStyle={{ color: '#fff' }}
              formatter={(value: number, name: string, props: any) => {
                const change = props.payload.change;
                const events = props.payload.events;
                return [
                  <div key="value" className="space-y-2">
                    <div className="flex justify-between gap-4">
                      <span className="text-muted">ارزش:</span>
                      <span className="font-bold">${value.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between gap-4">
                      <span className="text-muted">تغییر:</span>
                      <span className={change >= 0 ? 'text-success' : 'text-danger'}>
                        {change >= 0 ? '+' : ''}{change.toFixed(2)}%
                      </span>
                    </div>
                    {events && events.length > 0 && (
                      <div className="border-t border-gold/20 pt-2 mt-2">
                        <div className="text-xs text-gold mb-1 flex items-center gap-1">
                          <Zap size={12} />
                          رویدادها:
                        </div>
                        {events.map((event: string, i: number) => (
                          <div key={i} className="text-xs text-muted">• {event}</div>
                        ))}
                      </div>
                    )}
                  </div>,
                  ''
                ];
              }}
              labelFormatter={(label) => `روز ${label}`}
            />
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="#FFB800"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 6, fill: '#FFB800', stroke: '#fff', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* آمار خلاصه */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gold/20">
        <div className="text-center">
          <div className="text-sm text-muted mb-1">بیشترین ارزش</div>
          <div className="text-lg font-bold text-success">${maxValue.toLocaleString()}</div>
        </div>
        <div className="text-center">
          <div className="text-sm text-muted mb-1">کمترین ارزش</div>
          <div className="text-lg font-bold text-danger">${minValue.toLocaleString()}</div>
        </div>
        <div className="text-center">
          <div className="text-sm text-muted mb-1">تعداد رویدادها</div>
          <div className="text-lg font-bold text-gold">{eventPoints.length}</div>
        </div>
      </div>

      {/* لیست رویدادهای اخیر */}
      {eventPoints.length > 0 && (
        <div className="border-t border-gold/20 pt-4">
          <h4 className="text-sm font-bold text-gold mb-3 flex items-center gap-2">
            <Zap size={16} />
            رویدادهای مهم اخیر
          </h4>
          <div className="space-y-2 max-h-32 overflow-y-auto custom-scrollbar">
            {eventPoints.slice(-5).reverse().map((point, index) => (
              <div key={index} className="flex items-start gap-3 text-sm">
                <div className={`w-2 h-2 rounded-full mt-1.5 ${
                  point.change >= 0 ? 'bg-success' : 'bg-danger'
                }`} />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-muted">روز {point.day}</span>
                    <span className={`font-bold ${
                      point.change >= 0 ? 'text-success' : 'text-danger'
                    }`}>
                      {point.change >= 0 ? '+' : ''}{point.change.toFixed(2)}%
                    </span>
                  </div>
                  {point.events.map((event, i) => (
                    <div key={i} className="text-xs text-muted">• {event}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
