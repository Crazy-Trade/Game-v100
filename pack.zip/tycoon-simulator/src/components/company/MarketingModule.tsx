import { useState } from 'react';
import { useGameStore } from '../../store/gameStore';
import { Megaphone, Tv, MapPin, Smartphone, TrendingUp, Zap, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

type CampaignType = 'digital' | 'tv' | 'billboard' | 'social';

interface CampaignTemplate {
  type: CampaignType;
  name: string;
  description: string;
  icon: React.ElementType;
  baseCost: number;
  duration: number;
  impactRange: [number, number];
  color: string;
}

export default function MarketingModule() {
  const company = useGameStore(state => state.company);
  const campaigns = useGameStore(state => state.campaigns);
  const game = useGameStore(state => state.game);
  const launchCampaign = useGameStore(state => state.launchCampaign);
  const upgradeBrand = useGameStore(state => state.upgradeBrand);
  
  const [selectedCampaign, setSelectedCampaign] = useState<CampaignType | null>(null);
  const [budget, setBudget] = useState(50000);

  if (!company || !company.isUnlocked) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-8 text-center">
        <Megaphone className="w-16 h-16 mx-auto text-slate-600 mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">شرکت فعال نیست</h3>
        <p className="text-slate-400">ابتدا باید شرکت خود را فعال کنید</p>
      </div>
    );
  }

  const campaignTemplates: CampaignTemplate[] = [
    {
      type: 'digital',
      name: 'تبلیغات دیجیتال',
      description: 'تبلیغات در موتورهای جستجو، شبکه‌های اجتماعی و سایت‌ها',
      icon: Smartphone,
      baseCost: 50000,
      duration: 15,
      impactRange: [5, 15],
      color: 'from-blue-500 to-cyan-500',
    },
    {
      type: 'social',
      name: 'بازاریابی شبکه‌های اجتماعی',
      description: 'کمپین‌های ویروسی و همکاری با اینفلوئنسرها',
      icon: TrendingUp,
      baseCost: 75000,
      duration: 20,
      impactRange: [10, 25],
      color: 'from-pink-500 to-rose-500',
    },
    {
      type: 'tv',
      name: 'تبلیغات تلویزیونی',
      description: 'پخش آگهی در شبکه‌های تلویزیونی با بیننده بالا',
      icon: Tv,
      baseCost: 150000,
      duration: 30,
      impactRange: [20, 40],
      color: 'from-purple-500 to-indigo-500',
    },
    {
      type: 'billboard',
      name: 'بیلبوردهای شهری',
      description: 'نصب بیلبوردهای تبلیغاتی در مکان‌های پرتردد شهر',
      icon: MapPin,
      baseCost: 100000,
      duration: 45,
      impactRange: [15, 30],
      color: 'from-orange-500 to-amber-500',
    },
  ];

  const activeCampaigns = campaigns.filter(c => 
    game.currentDay - c.startDay < c.duration
  );

  const calculateImpact = (template: CampaignTemplate, budget: number): number => {
    const baseImpact = template.impactRange[0];
    const maxImpact = template.impactRange[1];
    const budgetMultiplier = budget / template.baseCost;
    return Math.min(baseImpact + (maxImpact - baseImpact) * (budgetMultiplier - 1) / 4, maxImpact);
  };

  const selectedTemplate = campaignTemplates.find(c => c.type === selectedCampaign);

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Megaphone className="w-8 h-8 text-amber-500" />
        <h3 className="text-2xl font-bold text-white">بازاریابی و برندینگ</h3>
      </div>

      {/* ارزش برند */}
      <div className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 rounded-xl p-6 border border-purple-500/30">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-xl font-bold text-white mb-1">ارزش برند</h4>
            <p className="text-purple-300">تاثیر بر فروش و اعتماد مشتریان</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold text-white">{company.brandEquity}</p>
            <p className="text-purple-300 text-sm">از 100</p>
          </div>
        </div>
        
        <div className="h-3 bg-slate-800 rounded-full overflow-hidden mb-4">
          <div
            className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-500"
            style={{ width: `${company.brandEquity}%` }}
          />
        </div>

        <button
          onClick={() => upgradeBrand()}
          disabled={company.cash < 200000 || company.brandEquity >= 100}
          className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-lg hover:from-purple-600 hover:to-pink-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          <Zap className="w-5 h-5" />
          <span>ارتقا برند (هزینه: $200K)</span>
        </button>
      </div>

      {/* کمپین‌های فعال */}
      {activeCampaigns.length > 0 && (
        <div className="bg-slate-800 rounded-lg p-6">
          <h4 className="text-lg font-bold text-white mb-4">کمپین‌های در حال اجرا</h4>
          <div className="space-y-3">
            {activeCampaigns.map((campaign) => {
              const template = campaignTemplates.find(t => t.type === campaign.type);
              if (!template) return null;
              
              const Icon = template.icon;
              const daysRemaining = campaign.duration - (game.currentDay - campaign.startDay);
              const progress = ((game.currentDay - campaign.startDay) / campaign.duration) * 100;
              
              return (
                <div key={campaign.id} className="bg-slate-700 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Icon className="w-6 h-6 text-amber-400" />
                    <div className="flex-1">
                      <h5 className="text-white font-bold">{template.name}</h5>
                      <p className="text-slate-400 text-sm">
                        {daysRemaining} روز باقی‌مانده | تاثیر: +{campaign.impact.toFixed(1)}%
                      </p>
                    </div>
                  </div>
                  <div className="h-2 bg-slate-600 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${template.color} transition-all duration-500`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* لانچ کمپین جدید */}
      <div className="space-y-4">
        <h4 className="text-lg font-bold text-white">راه‌اندازی کمپین جدید</h4>
        
        <div className="grid grid-cols-2 gap-4">
          {campaignTemplates.map((template) => {
            const Icon = template.icon;
            const isSelected = selectedCampaign === template.type;
            
            return (
              <motion.button
                key={template.type}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedCampaign(template.type)}
                className={`p-4 rounded-lg border-2 transition-colors text-right ${
                  isSelected
                    ? 'border-amber-500 bg-amber-500/10'
                    : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                }`}
              >
                <Icon className="w-8 h-8 text-amber-400 mb-2" />
                <h5 className="text-white font-bold mb-1">{template.name}</h5>
                <p className="text-slate-400 text-xs mb-2">{template.description}</p>
                <div className="space-y-1">
                  <p className="text-slate-300 text-xs">• هزینه پایه: ${(template.baseCost / 1000).toFixed(0)}K</p>
                  <p className="text-slate-300 text-xs">• مدت: {template.duration} روز</p>
                  <p className="text-slate-300 text-xs">
                    • تاثیر: {template.impactRange[0]}-{template.impactRange[1]}%
                  </p>
                </div>
              </motion.button>
            );
          })}
        </div>

        {selectedTemplate && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-800 rounded-lg p-6 space-y-4"
          >
            <div>
              <label className="block text-white font-bold mb-2">بودجه کمپین</label>
              <input
                type="range"
                min={selectedTemplate.baseCost}
                max={selectedTemplate.baseCost * 5}
                step={10000}
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                className="w-full"
              />
              <div className="flex justify-between text-sm mt-2">
                <span className="text-slate-400">
                  ${(selectedTemplate.baseCost / 1000).toFixed(0)}K
                </span>
                <span className="text-white font-bold">${(budget / 1000).toFixed(0)}K</span>
                <span className="text-slate-400">
                  ${(selectedTemplate.baseCost * 5 / 1000).toFixed(0)}K
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-slate-700 rounded-lg p-3 text-center">
                <p className="text-slate-400 text-xs mb-1">مدت</p>
                <p className="text-white font-bold">{selectedTemplate.duration} روز</p>
              </div>
              <div className="bg-slate-700 rounded-lg p-3 text-center">
                <p className="text-slate-400 text-xs mb-1">تاثیر پیش‌بینی</p>
                <p className="text-green-400 font-bold">
                  +{calculateImpact(selectedTemplate, budget).toFixed(1)}%
                </p>
              </div>
              <div className="bg-slate-700 rounded-lg p-3 text-center">
                <p className="text-slate-400 text-xs mb-1">ROI تخمینی</p>
                <p className="text-amber-400 font-bold">
                  {((calculateImpact(selectedTemplate, budget) * 2) / (budget / 10000)).toFixed(1)}x
                </p>
              </div>
            </div>

            {company.cash < budget && (
              <div className="bg-red-500/10 border border-red-500 rounded-lg p-3 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <p className="text-red-400 text-sm">موجودی شرکت کافی نیست</p>
              </div>
            )}

            <button
              onClick={() => {
                if (company.cash >= budget) {
                  launchCampaign(selectedTemplate.type, budget);
                  setSelectedCampaign(null);
                  setBudget(50000);
                }
              }}
              disabled={company.cash < budget}
              className={`w-full py-4 bg-gradient-to-r ${selectedTemplate.color} text-white font-bold rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2`}
            >
              <Zap className="w-5 h-5" />
              <span>راه‌اندازی کمپین</span>
            </button>
          </motion.div>
        )}
      </div>

      {/* نکات */}
      <div className="bg-blue-500/10 border border-blue-500 rounded-lg p-4">
        <h5 className="text-blue-400 font-bold mb-2 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          نکات بازاریابی
        </h5>
        <ul className="text-blue-300 text-sm space-y-1">
          <li>• کمپین‌های متعدد به صورت همزمان تاثیر بیشتری دارند</li>
          <li>• ارزش برند بالاتر باعث افزایش قیمت محصولات می‌شود</li>
          <li>• بودجه بالاتر = تاثیر بیشتر اما ROI کمتر</li>
          <li>• کمپین‌های طولانی‌تر برای برندسازی بهترند</li>
        </ul>
      </div>
    </div>
  );
}
