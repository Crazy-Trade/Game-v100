import { motion } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { Zap, Lock, CheckCircle } from 'lucide-react';
import { useNotification } from '../ui/NotificationProvider';

interface TechNode {
  id: string;
  name: string;
  description: string;
  cost: number;
  researchTime: number;
  unlocked: boolean;
  prerequisites: string[];
  benefits: string;
}

const techTree: TechNode[] = [
  {
    id: 'efficiency_1',
    name: 'بهینه‌سازی فرآیند',
    description: 'افزایش 5% کارایی تولید',
    cost: 100000,
    researchTime: 3,
    unlocked: false,
    prerequisites: [],
    benefits: '+5% کارایی',
  },
  {
    id: 'automation_1',
    name: 'اتوماسیون سطح 1',
    description: 'کاهش 10% هزینه نیروی کار',
    cost: 250000,
    researchTime: 5,
    unlocked: false,
    prerequisites: ['efficiency_1'],
    benefits: '-10% هزینه',
  },
  {
    id: 'quality_1',
    name: 'مدیریت کیفیت',
    description: 'افزایش 15% کیفیت محصول',
    cost: 200000,
    researchTime: 4,
    unlocked: false,
    prerequisites: ['efficiency_1'],
    benefits: '+15% کیفیت',
  },
  {
    id: 'new_product',
    name: 'خط تولید جدید',
    description: 'قابلیت تولید محصول جدید',
    cost: 500000,
    researchTime: 10,
    unlocked: false,
    prerequisites: ['automation_1', 'quality_1'],
    benefits: 'محصول جدید',
  },
  {
    id: 'ai_optimization',
    name: 'بهینه‌سازی با AI',
    description: 'کاهش 20% هزینه کلی تولید',
    cost: 1000000,
    researchTime: 15,
    unlocked: false,
    prerequisites: ['new_product'],
    benefits: '-20% هزینه کل',
  },
];

export default function RnDDepartment() {
  const company = useGameStore(state => state.company);
  const updateCompany = useGameStore(state => state.updateCompany);
  const player = useGameStore(state => state.player);
  const notify = useNotification();

  if (!company) return null;

  const unlockedTechs = company.techTree || [];

  const canResearch = (tech: TechNode) => {
    if (unlockedTechs.includes(tech.id)) return false;
    if (player.cash < tech.cost) return false;
    return tech.prerequisites.every(prereq => unlockedTechs.includes(prereq));
  };

  const handleResearch = (tech: TechNode) => {
    if (!canResearch(tech)) {
      notify.error('شرایط تحقیق فراهم نیست!');
      return;
    }

    updateCompany({
      ...company,
      techTree: [...unlockedTechs, tech.id],
      techLevel: company.techLevel + 1,
      researchPoints: company.researchPoints + 10,
    });

    // Deduct cost from player cash
    const gameStore = useGameStore.getState();
    gameStore.player.cash -= tech.cost;

    notify.success(`تحقیق ${tech.name} با موفقیت انجام شد!`);
  };

  return (
    <div className="bg-slate-800 rounded-lg p-6 space-y-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Zap className="w-6 h-6 text-purple-500" />
          <h4 className="text-lg font-bold text-white">تحقیق و توسعه (R&D)</h4>
        </div>
        <div className="text-right">
          <p className="text-sm text-slate-400">سطح فناوری</p>
          <p className="text-2xl font-bold text-white">{company.techLevel}</p>
        </div>
      </div>

      {/* Tech Tree */}
      <div className="space-y-3">
        {techTree.map((tech) => {
          const isUnlocked = unlockedTechs.includes(tech.id);
          const isAvailable = canResearch(tech);
          const hasPrerequisites = tech.prerequisites.every(prereq => unlockedTechs.includes(prereq));

          return (
            <motion.div
              key={tech.id}
              whileHover={{ scale: isAvailable ? 1.02 : 1 }}
              className={`p-4 rounded-lg border-2 transition-all ${
                isUnlocked
                  ? 'border-green-500 bg-green-500/10'
                  : isAvailable
                  ? 'border-amber-500 bg-amber-500/5 hover:bg-amber-500/10 cursor-pointer'
                  : 'border-slate-700 bg-slate-900 opacity-60'
              }`}
              onClick={() => isAvailable && handleResearch(tech)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    {isUnlocked ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : !hasPrerequisites ? (
                      <Lock className="w-5 h-5 text-slate-600" />
                    ) : (
                      <Zap className="w-5 h-5 text-amber-500" />
                    )}
                    <h5 className="font-bold text-white">{tech.name}</h5>
                  </div>
                  <p className="text-sm text-slate-400 mb-2">{tech.description}</p>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-blue-400">هزینه: ${tech.cost.toLocaleString()}</span>
                    <span className="text-purple-400">زمان: {tech.researchTime} روز</span>
                    <span className="text-green-400">{tech.benefits}</span>
                  </div>
                  
                  {tech.prerequisites.length > 0 && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-xs text-slate-500">نیازمندی:</span>
                      {tech.prerequisites.map(prereq => {
                        const prereqTech = techTree.find(t => t.id === prereq);
                        const isPrereqUnlocked = unlockedTechs.includes(prereq);
                        return (
                          <span
                            key={prereq}
                            className={`text-xs px-2 py-1 rounded ${
                              isPrereqUnlocked
                                ? 'bg-green-500/20 text-green-400'
                                : 'bg-slate-700 text-slate-500'
                            }`}
                          >
                            {prereqTech?.name}
                          </span>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Research Points */}
      <div className="bg-slate-900 rounded-lg p-4">
        <p className="text-sm text-slate-400 mb-2">امتیازات تحقیق</p>
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-slate-700 rounded-full h-3">
            <div
              className="bg-purple-500 h-3 rounded-full"
              style={{ width: `${Math.min((company.researchPoints / 100) * 100, 100)}%` }}
            />
          </div>
          <span className="text-white font-bold">{company.researchPoints}/100</span>
        </div>
      </div>
    </div>
  );
}
