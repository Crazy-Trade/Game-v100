import React, { useState } from 'react';
import { 
  Package, 
  Beaker, 
  Users, 
  Megaphone, 
  Scale,
  ArrowUp,
  Lock,
  CheckCircle2,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import type { Upgrade, UpgradeModule } from '../../types';

interface UpgradeSystemProps {
  upgrades: Upgrade[];
  cash: number;
  onPurchase: (upgradeId: string) => void;
}

// آیکون‌های ماژول‌ها
const moduleIcons: Record<UpgradeModule, React.ReactNode> = {
  supply_chain: <Package size={20} />,
  rd: <Beaker size={20} />,
  hr: <Users size={20} />,
  marketing: <Megaphone size={20} />,
  lobbying: <Scale size={20} />
};

// عنوان‌های فارسی
const moduleNames: Record<UpgradeModule, string> = {
  supply_chain: 'زنجیره تأمین',
  rd: 'تحقیق و توسعه',
  hr: 'منابع انسانی',
  marketing: 'بازاریابی',
  lobbying: 'لابی و روابط عمومی'
};

// رنگ‌های ماژول‌ها
const moduleColors: Record<UpgradeModule, string> = {
  supply_chain: 'from-blue-500/20 to-blue-600/20 border-blue-500/30',
  rd: 'from-purple-500/20 to-purple-600/20 border-purple-500/30',
  hr: 'from-green-500/20 to-green-600/20 border-green-500/30',
  marketing: 'from-pink-500/20 to-pink-600/20 border-pink-500/30',
  lobbying: 'from-gold/20 to-orange-500/20 border-gold/30'
};

export const UpgradeSystem: React.FC<UpgradeSystemProps> = ({ upgrades, cash, onPurchase }) => {
  const [selectedModule, setSelectedModule] = useState<UpgradeModule>('supply_chain');

  // گروه‌بندی ارتقاها بر اساس ماژول
  const upgradesByModule = upgrades.reduce((acc, upgrade) => {
    if (!acc[upgrade.module]) {
      acc[upgrade.module] = [];
    }
    acc[upgrade.module].push(upgrade);
    return acc;
  }, {} as Record<UpgradeModule, Upgrade[]>);

  const selectedUpgrades = upgradesByModule[selectedModule] || [];

  // فرمت کردن افکت‌ها
  const formatEffects = (effects: Upgrade['effects']) => {
    const effectsList: string[] = [];
    if (effects.costReduction) effectsList.push(`کاهش ${effects.costReduction}% هزینه`);
    if (effects.revenueIncrease) effectsList.push(`افزایش ${effects.revenueIncrease}% درآمد`);
    if (effects.qualityBonus) effectsList.push(`افزایش ${effects.qualityBonus}% کیفیت`);
    if (effects.speedBonus) effectsList.push(`افزایش ${effects.speedBonus}% سرعت`);
    if (effects.brandBonus) effectsList.push(`+${effects.brandBonus} برند`);
    if (effects.techBonus) effectsList.push(`+${effects.techBonus}% سرعت تحقیق`);
    if (effects.moraleBonus) effectsList.push(`+${effects.moraleBonus} روحیه`);
    if (effects.influenceBonus) effectsList.push(`+${effects.influenceBonus} نفوذ`);
    return effectsList;
  };

  return (
    <div className="glass-card p-6 space-y-6">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold gradient-text flex items-center gap-2">
          <ArrowUp size={24} />
          سیستم ارتقاء شرکت
        </h3>
        <div className="text-right">
          <div className="text-xs text-muted">بودجه موجود</div>
          <div className="text-lg font-bold text-gold">${cash.toLocaleString()}</div>
        </div>
      </div>

      {/* تب‌های ماژول‌ها */}
      <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
        {(Object.keys(moduleNames) as UpgradeModule[]).map((module) => {
          const moduleUpgrades = upgradesByModule[module] || [];
          const completedCount = moduleUpgrades.filter(u => u.level === u.maxLevel).length;
          const totalCount = moduleUpgrades.length;
          
          return (
            <button
              key={module}
              onClick={() => setSelectedModule(module)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border transition-all whitespace-nowrap ${
                selectedModule === module
                  ? `bg-gradient-to-br ${moduleColors[module]} border-current`
                  : 'border-gold/20 hover:border-gold/40'
              }`}
            >
              {moduleIcons[module]}
              <div className="text-right">
                <div className="text-sm font-bold">{moduleNames[module]}</div>
                <div className="text-xs text-muted">
                  {completedCount}/{totalCount}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* لیست ارتقاها */}
      <div className="space-y-3 max-h-96 overflow-y-auto custom-scrollbar">
        {selectedUpgrades.length === 0 ? (
          <div className="text-center py-8 text-muted">
            هنوز ارتقایی برای این بخش وجود ندارد
          </div>
        ) : (
          selectedUpgrades.map((upgrade) => {
            const isMaxLevel = upgrade.level === upgrade.maxLevel;
            const canAfford = cash >= upgrade.cost;
            const effectsList = formatEffects(upgrade.effects);

            return (
              <div
                key={upgrade.id}
                className={`p-4 rounded-lg border transition-all ${
                  isMaxLevel
                    ? 'bg-success/10 border-success/30'
                    : 'bg-gradient-to-br from-navy/50 to-navy/30 border-gold/20 hover:border-gold/40'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-bold text-white">{upgrade.name}</h4>
                      {isMaxLevel && <CheckCircle2 className="text-success" size={18} />}
                    </div>
                    <p className="text-sm text-muted">{upgrade.description}</p>
                  </div>
                  
                  {!isMaxLevel && (
                    <button
                      onClick={() => onPurchase(upgrade.id)}
                      disabled={!canAfford}
                      className={`px-4 py-2 rounded-lg font-bold transition-all flex items-center gap-2 whitespace-nowrap mr-3 ${
                        canAfford
                          ? 'bg-gold text-navy hover:bg-gold/90'
                          : 'bg-muted/20 text-muted cursor-not-allowed'
                      }`}
                    >
                      <DollarSign size={16} />
                      ${upgrade.cost.toLocaleString()}
                    </button>
                  )}
                </div>

                {/* سطح و پیشرفت */}
                <div className="mb-3">
                  <div className="flex items-center justify-between text-xs text-muted mb-1">
                    <span>سطح {upgrade.level} از {upgrade.maxLevel}</span>
                    <span>{((upgrade.level / upgrade.maxLevel) * 100).toFixed(0)}%</span>
                  </div>
                  <div className="h-2 bg-navy/50 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all ${
                        isMaxLevel ? 'bg-success' : 'bg-gradient-to-r from-gold to-blue'
                      }`}
                      style={{ width: `${(upgrade.level / upgrade.maxLevel) * 100}%` }}
                    />
                  </div>
                </div>

                {/* افکت‌ها */}
                <div className="flex flex-wrap gap-2">
                  {effectsList.map((effect, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-1 px-2 py-1 rounded bg-gold/10 text-gold text-xs"
                    >
                      <TrendingUp size={12} />
                      {effect}
                    </div>
                  ))}
                </div>

                {/* قفل */}
                {!isMaxLevel && !canAfford && (
                  <div className="flex items-center gap-2 mt-3 text-xs text-danger">
                    <Lock size={14} />
                    بودجه کافی نیست
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* خلاصه پیشرفت کلی */}
      <div className="pt-4 border-t border-gold/20">
        <div className="grid grid-cols-5 gap-3">
          {(Object.keys(moduleNames) as UpgradeModule[]).map((module) => {
            const moduleUpgrades = upgradesByModule[module] || [];
            const completedCount = moduleUpgrades.filter(u => u.level === u.maxLevel).length;
            const totalCount = moduleUpgrades.length;
            const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

            return (
              <div key={module} className="text-center">
                <div className="mb-2">{moduleIcons[module]}</div>
                <div className="text-xs text-muted mb-1">{moduleNames[module]}</div>
                <div className="text-sm font-bold text-gold">{progress.toFixed(0)}%</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
