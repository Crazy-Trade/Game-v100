import { useState } from 'react';
import { useGameStore } from '../../store/gameStore';
import { Handshake, Building, DollarSign, Clock, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

interface NPCCompany {
  id: string;
  name: string;
  industry: string;
  size: 'small' | 'medium' | 'large';
  relationship: number; // 0-100
  contractValue: number;
  requirements: {
    brandEquity: number;
    revenue: number;
    techLevel: number;
  };
}

interface Contract {
  id: string;
  companyId: string;
  companyName: string;
  value: number;
  duration: number;
  startDay: number;
  revenue: number;
  completed: boolean;
}

export default function LobbyingModule() {
  const company = useGameStore(state => state.company);
  const game = useGameStore(state => state.game);
  const npcCompanies = useGameStore(state => state.npcCompanies);
  const contracts = useGameStore(state => state.contracts);
  const improveRelationship = useGameStore(state => state.improveRelationship);
  const signContract = useGameStore(state => state.signContract);
  
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);
  const [lobbyAmount, setLobbyAmount] = useState(50000);

  if (!company || !company.isUnlocked) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-8 text-center">
        <Handshake className="w-16 h-16 mx-auto text-slate-600 mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">شرکت فعال نیست</h3>
        <p className="text-slate-400">ابتدا باید شرکت خود را فعال کنید</p>
      </div>
    );
  }

  const activeContracts = contracts.filter(c => !c.completed);
  const completedContracts = contracts.filter(c => c.completed);

  const selectedNPC = npcCompanies.find(c => c.id === selectedCompany);

  const canSignContract = (npc: NPCCompany): boolean => {
    return (
      company.brandEquity >= npc.requirements.brandEquity &&
      company.revenue >= npc.requirements.revenue &&
      company.techLevel >= npc.requirements.techLevel &&
      npc.relationship >= 70
    );
  };

  const getSizeIcon = (size: string) => {
    switch (size) {
      case 'small': return '🏢';
      case 'medium': return '🏬';
      case 'large': return '🏭';
      default: return '🏢';
    }
  };

  const getRelationshipColor = (relationship: number) => {
    if (relationship >= 80) return 'text-green-400';
    if (relationship >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getRelationshipLabel = (relationship: number) => {
    if (relationship >= 80) return 'عالی';
    if (relationship >= 50) return 'خوب';
    if (relationship >= 30) return 'متوسط';
    return 'ضعیف';
  };

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Handshake className="w-8 h-8 text-amber-500" />
        <h3 className="text-2xl font-bold text-white">لابی‌گری و قراردادهای تجاری</h3>
      </div>

      {/* قراردادهای فعال */}
      {activeContracts.length > 0 && (
        <div className="bg-slate-800 rounded-lg p-6">
          <h4 className="text-lg font-bold text-white mb-4">قراردادهای فعال</h4>
          <div className="space-y-3">
            {activeContracts.map((contract) => {
              const daysRemaining = contract.duration - (game.currentDay - contract.startDay);
              const progress = ((game.currentDay - contract.startDay) / contract.duration) * 100;
              const totalRevenue = contract.revenue * (game.currentDay - contract.startDay);
              
              return (
                <div key={contract.id} className="bg-slate-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h5 className="text-white font-bold">{contract.companyName}</h5>
                      <p className="text-slate-400 text-sm">
                        درآمد روزانه: ${contract.revenue.toLocaleString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-bold">${totalRevenue.toLocaleString()}</p>
                      <p className="text-slate-400 text-xs">{daysRemaining} روز باقی</p>
                    </div>
                  </div>
                  <div className="h-2 bg-slate-600 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-500"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* شرکت‌های NPC */}
      <div className="space-y-4">
        <h4 className="text-lg font-bold text-white">شرکت‌های شریک بالقوه</h4>
        
        <div className="grid grid-cols-1 gap-4">
          {npcCompanies.map((npc) => {
            const canSign = canSignContract(npc);
            const hasActiveContract = activeContracts.some(c => c.companyId === npc.id);
            
            return (
              <div
                key={npc.id}
                className={`bg-slate-800 rounded-lg p-5 border-2 transition-colors ${
                  selectedCompany === npc.id
                    ? 'border-amber-500'
                    : 'border-slate-700 hover:border-slate-600'
                }`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{getSizeIcon(npc.size)}</span>
                    <div>
                      <h5 className="text-white font-bold text-lg">{npc.name}</h5>
                      <p className="text-slate-400 text-sm">{npc.industry}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${getRelationshipColor(npc.relationship)}`}>
                      {getRelationshipLabel(npc.relationship)}
                    </p>
                    <p className="text-slate-400 text-sm">{npc.relationship}/100</p>
                  </div>
                </div>

                <div className="h-2 bg-slate-700 rounded-full overflow-hidden mb-4">
                  <div
                    className={`h-full transition-all duration-500 ${
                      npc.relationship >= 80
                        ? 'bg-gradient-to-r from-green-500 to-emerald-500'
                        : npc.relationship >= 50
                        ? 'bg-gradient-to-r from-yellow-500 to-orange-500'
                        : 'bg-gradient-to-r from-red-500 to-orange-500'
                    }`}
                    style={{ width: `${npc.relationship}%` }}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-slate-700 rounded p-3">
                    <p className="text-slate-400 text-xs mb-1">ارزش قرارداد</p>
                    <p className="text-white font-bold">${(npc.contractValue / 1000).toFixed(0)}K</p>
                  </div>
                  <div className="bg-slate-700 rounded p-3">
                    <p className="text-slate-400 text-xs mb-1">درآمد روزانه</p>
                    <p className="text-green-400 font-bold">
                      ${((npc.contractValue * 0.05) / 1).toFixed(0)}
                    </p>
                  </div>
                </div>

                <div className="space-y-2 mb-4">
                  <p className="text-slate-400 text-sm font-bold">الزامات:</p>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className={`flex items-center gap-1 ${
                      company.brandEquity >= npc.requirements.brandEquity
                        ? 'text-green-400'
                        : 'text-red-400'
                    }`}>
                      {company.brandEquity >= npc.requirements.brandEquity ? (
                        <CheckCircle className="w-3 h-3" />
                      ) : (
                        <XCircle className="w-3 h-3" />
                      )}
                      <span>برند {npc.requirements.brandEquity}+</span>
                    </div>
                    <div className={`flex items-center gap-1 ${
                      company.revenue >= npc.requirements.revenue
                        ? 'text-green-400'
                        : 'text-red-400'
                    }`}>
                      {company.revenue >= npc.requirements.revenue ? (
                        <CheckCircle className="w-3 h-3" />
                      ) : (
                        <XCircle className="w-3 h-3" />
                      )}
                      <span>درآمد ${(npc.requirements.revenue / 1000).toFixed(0)}K+</span>
                    </div>
                    <div className={`flex items-center gap-1 ${
                      company.techLevel >= npc.requirements.techLevel
                        ? 'text-green-400'
                        : 'text-red-400'
                    }`}>
                      {company.techLevel >= npc.requirements.techLevel ? (
                        <CheckCircle className="w-3 h-3" />
                      ) : (
                        <XCircle className="w-3 h-3" />
                      )}
                      <span>تکنولوژی {npc.requirements.techLevel}+</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedCompany(npc.id)}
                    className="flex-1 py-2 bg-slate-700 text-white font-medium rounded-lg hover:bg-slate-600 transition-colors text-sm"
                  >
                    لابی‌گری
                  </button>
                  <button
                    onClick={() => signContract(npc.id)}
                    disabled={!canSign || hasActiveContract}
                    className="flex-1 py-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:from-green-600 hover:to-emerald-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                  >
                    {hasActiveContract ? 'قرارداد فعال' : 'امضای قرارداد'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* پنل لابی‌گری */}
      {selectedNPC && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-amber-900/50 to-orange-900/50 rounded-xl p-6 border border-amber-500/30"
        >
          <h4 className="text-xl font-bold text-white mb-4">
            لابی‌گری با {selectedNPC.name}
          </h4>
          
          <p className="text-amber-200 mb-4">
            هرچه بیشتر سرمایه‌گذاری کنید، روابط شما بهتر می‌شود
          </p>

          <div className="bg-slate-800/50 rounded-lg p-4 mb-4">
            <label className="block text-white font-bold mb-2">مبلغ لابی‌گری</label>
            <input
              type="range"
              min={50000}
              max={500000}
              step={50000}
              value={lobbyAmount}
              onChange={(e) => setLobbyAmount(Number(e.target.value))}
              className="w-full"
            />
            <div className="flex justify-between text-sm mt-2">
              <span className="text-slate-400">$50K</span>
              <span className="text-white font-bold">${(lobbyAmount / 1000).toFixed(0)}K</span>
              <span className="text-slate-400">$500K</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-slate-800/50 rounded-lg p-3 text-center">
              <p className="text-slate-400 text-sm mb-1">بهبود روابط</p>
              <p className="text-green-400 font-bold">+{(lobbyAmount / 10000).toFixed(0)}</p>
            </div>
            <div className="bg-slate-800/50 rounded-lg p-3 text-center">
              <p className="text-slate-400 text-sm mb-1">روابط جدید</p>
              <p className={`font-bold ${getRelationshipColor(
                Math.min(selectedNPC.relationship + lobbyAmount / 10000, 100)
              )}`}>
                {Math.min(selectedNPC.relationship + lobbyAmount / 10000, 100).toFixed(0)}/100
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => setSelectedCompany(null)}
              className="flex-1 py-3 bg-slate-700 text-white font-bold rounded-lg hover:bg-slate-600 transition-colors"
            >
              انصراف
            </button>
            <button
              onClick={() => {
                if (company.cash >= lobbyAmount) {
                  improveRelationship(selectedNPC.id, lobbyAmount);
                  setSelectedCompany(null);
                  setLobbyAmount(50000);
                }
              }}
              disabled={company.cash < lobbyAmount}
              className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              تایید لابی‌گری
            </button>
          </div>
        </motion.div>
      )}

      {/* قراردادهای تکمیل شده */}
      {completedContracts.length > 0 && (
        <div className="bg-slate-800 rounded-lg p-6">
          <h4 className="text-lg font-bold text-white mb-4">قراردادهای تکمیل شده</h4>
          <div className="space-y-2">
            {completedContracts.slice(-5).map((contract) => (
              <div key={contract.id} className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-white font-medium">{contract.companyName}</span>
                </div>
                <span className="text-green-400 font-bold">
                  +${(contract.revenue * contract.duration).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* راهنما */}
      <div className="bg-blue-500/10 border border-blue-500 rounded-lg p-4">
        <h5 className="text-blue-400 font-bold mb-2 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5" />
          نکات لابی‌گری
        </h5>
        <ul className="text-blue-300 text-sm space-y-1">
          <li>• برای امضای قرارداد، روابط باید حداقل 70 باشد</li>
          <li>• قراردادهای بزرگ‌تر نیاز به برند و درآمد بالاتر دارند</li>
          <li>• هر قرارداد درآمد روزانه ثابت ایجاد می‌کند</li>
          <li>• می‌توانید با چند شرکت همزمان قرارداد داشته باشید</li>
        </ul>
      </div>
    </div>
  );
}
