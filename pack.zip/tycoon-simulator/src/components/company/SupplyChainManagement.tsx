import { motion } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { Package, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { useNotification } from '../ui/NotificationProvider';

export default function SupplyChainManagement() {
  const company = useGameStore(state => state.company);
  const updateCompany = useGameStore(state => state.updateCompany);
  const notify = useNotification();

  if (!company) return null;

  const supplyChain = company.supplyChain || {
    supplier: 'premium',
    warehouseLevel: 50,
    qualityControl: 70,
    inventory: 1000,
    monthlyCost: 10000,
  };

  const handleSupplierChange = (supplier: 'cheap' | 'premium') => {
    updateCompany({
      ...company,
      supplyChain: {
        ...supplyChain,
        supplier,
        monthlyCost: supplier === 'cheap' ? 5000 : 10000,
        qualityControl: supplier === 'cheap' ? 50 : 85,
      },
    });
    notify.success(`تامین‌کننده به ${supplier === 'cheap' ? 'ارزان' : 'پریمیوم'} تغییر یافت`);
  };

  const handleWarehouseUpgrade = () => {
    if (company.cash < 50000) {
      notify.error('موجودی کافی نیست!');
      return;
    }
    
    updateCompany({
      ...company,
      cash: company.cash - 50000,
      supplyChain: {
        ...supplyChain,
        warehouseLevel: Math.min(supplyChain.warehouseLevel + 10, 100),
      },
    });
    notify.success('سطح انبار ارتقا یافت!');
  };

  return (
    <div className="bg-slate-800 rounded-lg p-6 space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Package className="w-6 h-6 text-blue-500" />
        <h4 className="text-lg font-bold text-white">مدیریت زنجیره تامین</h4>
      </div>

      {/* Supplier Selection */}
      <div>
        <h5 className="text-sm font-medium text-slate-400 mb-3">انتخاب تامین‌کننده</h5>
        <div className="grid grid-cols-2 gap-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleSupplierChange('cheap')}
            className={`p-4 rounded-lg border-2 transition-all ${
              supplyChain.supplier === 'cheap'
                ? 'border-amber-500 bg-amber-500/10'
                : 'border-slate-700 bg-slate-900 hover:border-slate-600'
            }`}
          >
            <TrendingDown className="w-6 h-6 text-red-500 mx-auto mb-2" />
            <p className="font-bold text-white text-sm">ارزان</p>
            <p className="text-xs text-slate-400 mt-1">هزینه پایین، ریسک بالا</p>
            <p className="text-xs text-green-400 mt-2">$5,000/ماه</p>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => handleSupplierChange('premium')}
            className={`p-4 rounded-lg border-2 transition-all ${
              supplyChain.supplier === 'premium'
                ? 'border-amber-500 bg-amber-500/10'
                : 'border-slate-700 bg-slate-900 hover:border-slate-600'
            }`}
          >
            <TrendingUp className="w-6 h-6 text-green-500 mx-auto mb-2" />
            <p className="font-bold text-white text-sm">پریمیوم</p>
            <p className="text-xs text-slate-400 mt-1">کیفیت بالا، قابل اعتماد</p>
            <p className="text-xs text-red-400 mt-2">$10,000/ماه</p>
          </motion.button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-900 rounded-lg p-4">
          <p className="text-sm text-slate-400">سطح انبار</p>
          <div className="flex items-center gap-2 mt-2">
            <div className="flex-1 bg-slate-700 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full"
                style={{ width: `${supplyChain.warehouseLevel}%` }}
              />
            </div>
            <span className="text-white font-bold text-sm">{supplyChain.warehouseLevel}%</span>
          </div>
        </div>

        <div className="bg-slate-900 rounded-lg p-4">
          <p className="text-sm text-slate-400">کنترل کیفیت</p>
          <div className="flex items-center gap-2 mt-2">
            <div className="flex-1 bg-slate-700 rounded-full h-2">
              <div
                className="bg-green-500 h-2 rounded-full"
                style={{ width: `${supplyChain.qualityControl}%` }}
              />
            </div>
            <span className="text-white font-bold text-sm">{supplyChain.qualityControl}%</span>
          </div>
        </div>
      </div>

      {/* Warehouse Upgrade */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleWarehouseUpgrade}
        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
      >
        ارتقای انبار (+10%) - $50,000
      </motion.button>

      {supplyChain.qualityControl < 60 && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
          <AlertTriangle className="w-5 h-5 text-red-500" />
          <p className="text-sm text-red-400">هشدار: کیفیت پایین می‌تواند به شهرت برند آسیب بزند</p>
        </div>
      )}
    </div>
  );
}
