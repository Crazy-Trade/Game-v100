import { useState } from 'react';
import { useGameStore } from '../../store/gameStore';
import { Building2, TrendingUp, DollarSign, Users, CheckCircle, AlertCircle, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

type IPOPhase = 'preparation' | 'audit' | 'pricing' | 'offering' | 'listed';

export default function IPOModule() {
  const company = useGameStore(state => state.company);
  const ipo = useGameStore(state => state.ipo);
  const player = useGameStore(state => state.player);
  const startIPO = useGameStore(state => state.startIPO);
  const advanceIPOPhase = useGameStore(state => state.advanceIPOPhase);
  const payDividend = useGameStore(state => state.payDividend);
  
  const [selectedBank, setSelectedBank] = useState<'premium' | 'standard' | null>(null);

  if (!company || !company.isUnlocked) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-8 text-center">
        <Building2 className="w-16 h-16 mx-auto text-slate-600 mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">شرکت فعال نیست</h3>
        <p className="text-slate-400">ابتدا باید شرکت خود را فعال کنید</p>
      </div>
    );
  }

  // بررسی شرایط واجد شرایط بودن برای IPO
  const canStartIPO = company.companyValue >= 100000000 && // $100M
                       company.revenue >= 10000000 && // $10M
                       !ipo;

  // اگر هنوز IPO شروع نشده
  if (!ipo) {
    return (
      <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Building2 className="w-8 h-8 text-amber-500" />
          <h3 className="text-2xl font-bold text-white">عرضه عمومی اولیه (IPO)</h3>
        </div>

        <div className="bg-slate-800 rounded-lg p-6 space-y-4">
          <h4 className="text-lg font-bold text-white">الزامات IPO</h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              {company.companyValue >= 100000000 ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-400" />
              )}
              <div>
                <p className="text-sm text-slate-400">ارزش شرکت</p>
                <p className="text-white font-bold">
                  ${(company.companyValue / 1000000).toFixed(1)}M / $100M
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {company.revenue >= 10000000 ? (
                <CheckCircle className="w-5 h-5 text-green-400" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-400" />
              )}
              <div>
                <p className="text-sm text-slate-400">درآمد سالانه</p>
                <p className="text-white font-bold">
                  ${(company.revenue / 1000000).toFixed(1)}M / $10M
                </p>
              </div>
            </div>
          </div>
        </div>

        {canStartIPO ? (
          <>
            <div className="space-y-4">
              <h4 className="text-lg font-bold text-white">انتخاب بانک سرمایه‌گذاری</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedBank('standard')}
                  className={`p-6 rounded-lg border-2 transition-colors ${
                    selectedBank === 'standard'
                      ? 'border-amber-500 bg-amber-500/10'
                      : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <h5 className="text-lg font-bold text-white mb-2">بانک استاندارد</h5>
                  <p className="text-sm text-slate-400 mb-4">کارمزد کمتر، ریسک بیشتر</p>
                  <div className="space-y-2 text-right">
                    <p className="text-sm text-slate-300">• کارمزد: 3% ارزش شرکت</p>
                    <p className="text-sm text-slate-300">• مدت بازرسی: 30 روز</p>
                    <p className="text-sm text-slate-300">• نرخ موفقیت: 75%</p>
                  </div>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setSelectedBank('premium')}
                  className={`p-6 rounded-lg border-2 transition-colors ${
                    selectedBank === 'premium'
                      ? 'border-amber-500 bg-amber-500/10'
                      : 'border-slate-700 bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <h5 className="text-lg font-bold text-white mb-2">بانک پرمیوم</h5>
                  <p className="text-sm text-slate-400 mb-4">کارمزد بیشتر، اطمینان بالا</p>
                  <div className="space-y-2 text-right">
                    <p className="text-sm text-slate-300">• کارمزد: 7% ارزش شرکت</p>
                    <p className="text-sm text-slate-300">• مدت بازرسی: 15 روز</p>
                    <p className="text-sm text-slate-300">• نرخ موفقیت: 95%</p>
                  </div>
                </motion.button>
              </div>
            </div>

            {selectedBank && (
              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                onClick={() => startIPO(selectedBank)}
                className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors"
              >
                شروع فرآیند IPO
              </motion.button>
            )}
          </>
        ) : (
          <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 text-center">
            <AlertCircle className="w-8 h-8 mx-auto text-red-400 mb-2" />
            <p className="text-red-400">
              شرکت شما هنوز شرایط لازم برای IPO را ندارد
            </p>
          </div>
        )}
      </div>
    );
  }

  // مراحل مختلف IPO
  const getPhaseInfo = (phase: IPOPhase) => {
    switch (phase) {
      case 'preparation':
        return {
          title: 'آماده‌سازی اولیه',
          description: 'جمع‌آوری اسناد و آماده‌سازی شرکت برای بازرسی',
          icon: AlertCircle,
          color: 'text-blue-400',
        };
      case 'audit':
        return {
          title: 'بازرسی و ممیزی',
          description: 'بررسی دقیق صورت‌های مالی و عملکرد شرکت',
          icon: CheckCircle,
          color: 'text-purple-400',
        };
      case 'pricing':
        return {
          title: 'تعیین قیمت سهام',
          description: 'ارزیابی و تعیین قیمت مناسب برای سهام',
          icon: DollarSign,
          color: 'text-amber-400',
        };
      case 'offering':
        return {
          title: 'عرضه عمومی',
          description: 'فروش سهام به سرمایه‌گذاران عمومی',
          icon: Users,
          color: 'text-green-400',
        };
      case 'listed':
        return {
          title: 'لیست شده در بورس',
          description: 'شرکت شما اکنون در بورس معامله می‌شود',
          icon: TrendingUp,
          color: 'text-emerald-400',
        };
    }
  };

  const currentPhaseInfo = getPhaseInfo(ipo.phase);
  const PhaseIcon = currentPhaseInfo.icon;

  const canAdvance = ipo.daysInPhase >= (ipo.auditDuration || 15);

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-700 p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Building2 className="w-8 h-8 text-amber-500" />
          <h3 className="text-2xl font-bold text-white">عرضه عمومی اولیه</h3>
        </div>
        {ipo.listed && (
          <div className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            <span className="font-bold">لیست شده</span>
          </div>
        )}
      </div>

      {/* مرحله فعلی */}
      <div className="bg-slate-800 rounded-lg p-6">
        <div className="flex items-center gap-4 mb-4">
          <PhaseIcon className={`w-10 h-10 ${currentPhaseInfo.color}`} />
          <div>
            <h4 className="text-xl font-bold text-white">{currentPhaseInfo.title}</h4>
            <p className="text-slate-400">{currentPhaseInfo.description}</p>
          </div>
        </div>

        {!ipo.listed && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">پیشرفت</span>
              <span className="text-white font-bold">
                {Math.min(ipo.daysInPhase, ipo.auditDuration || 15)} / {ipo.auditDuration || 15} روز
              </span>
            </div>
            <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(ipo.daysInPhase / (ipo.auditDuration || 15)) * 100}%` }}
                className="h-full bg-gradient-to-r from-amber-500 to-orange-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* اطلاعات سهام */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-slate-400 text-sm mb-1">قیمت سهام</p>
          <p className="text-2xl font-bold text-white">${ipo.sharePrice.toFixed(2)}</p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-slate-400 text-sm mb-1">ارزش بازار</p>
          <p className="text-2xl font-bold text-white">
            ${(ipo.marketCap / 1000000).toFixed(1)}M
          </p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4">
          <p className="text-slate-400 text-sm mb-1">بازدهی سود سهام</p>
          <p className="text-2xl font-bold text-amber-400">{ipo.dividendYield.toFixed(2)}%</p>
        </div>
      </div>

      {/* سودهای فصلی */}
      {ipo.listed && (
        <div className="bg-slate-800 rounded-lg p-6">
          <h4 className="text-lg font-bold text-white mb-4">سودهای فصلی</h4>
          <div className="grid grid-cols-4 gap-4 mb-4">
            {ipo.quarterlyProfits.slice(-4).map((profit, idx) => (
              <div key={idx} className="text-center">
                <p className="text-slate-400 text-sm">فصل {idx + 1}</p>
                <p className={`text-lg font-bold ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  ${(profit / 1000).toFixed(1)}K
                </p>
              </div>
            ))}
          </div>
          
          <button
            onClick={() => payDividend()}
            disabled={company.profit < 1000000}
            className="w-full py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:from-green-600 hover:to-emerald-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <div className="flex items-center justify-center gap-2">
              <DollarSign className="w-5 h-5" />
              <span>پرداخت سود سهام (${(company.profit * 0.3 / 1000000).toFixed(2)}M)</span>
            </div>
          </button>
        </div>
      )}

      {/* دکمه پیشروی */}
      {!ipo.listed && canAdvance && (
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={() => advanceIPOPhase()}
          className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white font-bold rounded-lg hover:from-amber-600 hover:to-orange-600 transition-colors flex items-center justify-center gap-2"
        >
          <Zap className="w-5 h-5" />
          <span>انتقال به مرحله بعدی</span>
        </motion.button>
      )}
    </div>
  );
}
