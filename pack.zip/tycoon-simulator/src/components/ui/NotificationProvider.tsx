import { createContext, useContext, useState, ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, Info, AlertTriangle } from 'lucide-react';

type NotificationType = 'success' | 'error' | 'info' | 'warning';

interface Notification {
  id: string;
  type: NotificationType;
  message: string;
}

interface NotificationContextType {
  success: (message: string) => void;
  error: (message: string) => void;
  info: (message: string) => void;
  warning: (message: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within NotificationProvider');
  }
  return context;
};

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = (type: NotificationType, message: string) => {
    const id = `${Date.now()}-${Math.random()}`;
    const notification = { id, type, message };
    
    console.log('Adding notification:', notification);
    setNotifications(prev => [...prev, notification]);

    setTimeout(() => {
      console.log('Removing notification:', id);
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000); // زمان بیشتر: 5 ثانیه
  };

  const success = (message: string) => addNotification('success', message);
  const error = (message: string) => addNotification('error', message);
  const info = (message: string) => addNotification('info', message);
  const warning = (message: string) => addNotification('warning', message);

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-400" />;
      default:
        return <Info className="w-5 h-5 text-blue-400" />;
    }
  };

  const getColors = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return 'border-green-500/50 bg-green-500/10';
      case 'error':
        return 'border-red-500/50 bg-red-500/10';
      case 'warning':
        return 'border-amber-500/50 bg-amber-500/10';
      default:
        return 'border-blue-500/50 bg-blue-500/10';
    }
  };

  return (
    <NotificationContext.Provider value={{ success, error, info, warning }}>
      {children}
      <div className="fixed top-24 left-1/2 transform -translate-x-1/2 z-[9999] space-y-2 pointer-events-none">
        <AnimatePresence>
          {notifications.map(notification => (
            <motion.div
              key={notification.id}
              initial={{ opacity: 0, y: -20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className={`flex items-center gap-3 px-6 py-4 rounded-lg border backdrop-blur-md shadow-2xl pointer-events-auto ${getColors(notification.type)}`}
              style={{ minWidth: '300px' }}
            >
              {getIcon(notification.type)}
              <p className="text-white font-medium text-base">{notification.message}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </NotificationContext.Provider>
  );
}
