import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useGameStore } from '../../store/gameStore';
import { TrendingUp, TrendingDown, Activity, BarChart3, Eye } from 'lucide-react';

type ChartType = 'line' | 'area';
type Indicator = 'none' | 'ma' | 'rsi' | 'macd' | 'bollinger';

// محاسبه میانگین متحرک ساده
function calculateSMA(data: number[], period: number): (number | null)[] {
  return data.map((_, idx) => {
    if (idx < period - 1) return null;
    const sum = data.slice(idx - period + 1, idx + 1).reduce((a, b) => a + b, 0);
    return sum / period;
  });
}

// محاسبه RSI
function calculateRSI(prices: number[], period: number = 14): (number | null)[] {
  const changes = prices.slice(1).map((price, i) => price - prices[i]);
  const gains = changes.map(c => c > 0 ? c : 0);
  const losses = changes.map(c => c < 0 ? -c : 0);
  
  const result: (number | null)[] = new Array(period).fill(null);
  
  for (let i = period; i < prices.length; i++) {
    const avgGain = gains.slice(i - period, i).reduce((a, b) => a + b, 0) / period;
    const avgLoss = losses.slice(i - period, i).reduce((a, b) => a + b, 0) / period;
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const rsi = 100 - (100 / (1 + rs));
    result.push(rsi);
  }
  
  return result;
}

// محاسبه MACD
function calculateMACD(prices: number[]) {
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const macdLine = ema12.map((val, i) => val !== null && ema26[i] !== null ? val - ema26[i] : null);
  const signalLine = calculateEMA(macdLine.filter(v => v !== null) as number[], 9);
  
  return { macdLine, signalLine };
}

// محاسبه میانگین متحرک نمایی
function calculateEMA(data: (number | null)[], period: number): (number | null)[] {
  const k = 2 / (period + 1);
  const result: (number | null)[] = [];
  let ema = data.find(v => v !== null) || 0;
  
  data.forEach((value, i) => {
    if (value === null) {
      result.push(null);
    } else {
      ema = value * k + ema * (1 - k);
      result.push(ema);
    }
  });
  
  return result;
}

// محاسبه Bollinger Bands
function calculateBollingerBands(prices: number[], period: number = 20, stdDev: number = 2) {
  const sma = calculateSMA(prices, period);
  const upper: (number | null)[] = [];
  const lower: (number | null)[] = [];
  
  prices.forEach((_, idx) => {
    if (idx < period - 1) {
      upper.push(null);
      lower.push(null);
    } else {
      const slice = prices.slice(idx - period + 1, idx + 1);
      const mean = slice.reduce((a, b) => a + b, 0) / period;
      const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period;
      const std = Math.sqrt(variance);
      upper.push(mean + stdDev * std);
      lower.push(mean - stdDev * std);
    }
  });
  
  return { middle: sma, upper, lower };
}

export default function MarketChart() {
  const selectedAsset = useGameStore(state => state.selectedAsset);
  const [chartType, setChartType] = useState<ChartType>('line');
  const [indicator, setIndicator] = useState<Indicator>('none');

  const chartData = useMemo(() => {
    if (!selectedAsset) return [];
    
    const prices = selectedAsset.priceHistory.map(p => p.close);
    const data = selectedAsset.priceHistory.map((point, idx) => ({
      timestamp: point.timestamp,
      price: point.close,
      time: new Date(point.timestamp).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
    }));

    // اضافه کردن اندیکاتورها
    if (indicator === 'ma') {
      const ma20 = calculateSMA(prices, 20);
      const ma50 = calculateSMA(prices, 50);
      data.forEach((d, i) => {
        (d as any).ma20 = ma20[i];
        (d as any).ma50 = ma50[i];
      });
    } else if (indicator === 'rsi') {
      const rsi = calculateRSI(prices);
      data.forEach((d, i) => {
        (d as any).rsi = rsi[i];
      });
    } else if (indicator === 'macd') {
      const { macdLine, signalLine } = calculateMACD(prices);
      data.forEach((d, i) => {
        (d as any).macd = macdLine[i];
        (d as any).signal = i < signalLine.length ? signalLine[i] : null;
      });
    } else if (indicator === 'bollinger') {
      const { middle, upper, lower } = calculateBollingerBands(prices);
      data.forEach((d, i) => {
        (d as any).bbMiddle = middle[i];
        (d as any).bbUpper = upper[i];
        (d as any).bbLower = lower[i];
      });
    }

    return data;
  }, [selectedAsset, indicator]);

  if (!selectedAsset) {
    return (
      <div className="h-full flex items-center justify-center bg-secondary rounded-xl border border-border-primary">
        <div className="text-center">
          <Eye className="w-16 h-16 text-text-tertiary mx-auto mb-4 opacity-50" />
          <p className="text-text-secondary text-lg">یک دارایی را انتخاب کنید</p>
          <p className="text-text-tertiary text-sm mt-2">برای مشاهده چارت و تحلیل</p>
        </div>
      </div>
    );
  }

  const isPositive = selectedAsset.changePercent >= 0;
  const priceColor = isPositive ? '#00C853' : '#FF3B30';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="h-full bg-secondary rounded-xl border border-border-primary shadow-xl overflow-hidden"
    >
      {/* Header */}
      <div className="bg-elevated border-b border-border-primary p-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          {/* Asset Info */}
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h2 className="font-heading text-3xl font-bold text-gold">
                {selectedAsset.name}
              </h2>
              <span className="text-text-tertiary text-sm font-medium px-3 py-1 bg-bg-tertiary rounded-lg">
                {selectedAsset.symbol}
              </span>
            </div>
            <div className="flex items-center gap-4 flex-wrap">
              <span className="font-numbers text-4xl font-extrabold text-primary">
                ${selectedAsset.currentPrice.toLocaleString('en-US', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: selectedAsset.currentPrice < 1 ? 4 : 2
                })}
              </span>
              <motion.div 
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-lg shadow-lg ${
                  isPositive 
                    ? 'bg-success/20 text-success border border-success/30' 
                    : 'bg-danger/20 text-danger border border-danger/30'
                }`}
              >
                {isPositive ? (
                  <TrendingUp className="w-5 h-5" strokeWidth={3} />
                ) : (
                  <TrendingDown className="w-5 h-5" strokeWidth={3} />
                )}
                <span className="font-numbers">
                  {isPositive ? '+' : ''}{selectedAsset.changePercent.toFixed(2)}%
                </span>
              </motion.div>
            </div>
          </div>

          {/* Chart Type Selector */}
          <div className="flex gap-2">
            {([
              { type: 'line', label: 'خطی', icon: Activity },
              { type: 'area', label: 'ناحیه‌ای', icon: BarChart3 }
            ] as const).map(({ type, label, icon: Icon }) => (
              <motion.button
                key={type}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setChartType(type)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-bold 
                           transition-all duration-normal shadow-md ${
                  chartType === type
                    ? 'bg-gold text-bg-primary shadow-gold'
                    : 'bg-tertiary text-text-secondary hover:bg-elevated hover:text-primary border border-border-secondary'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Indicators */}
        <div className="flex items-center gap-3 mt-4 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue/10 flex items-center justify-center">
              <Activity className="w-4 h-4 text-blue" />
            </div>
            <span className="text-text-secondary text-sm font-medium">اندیکاتور:</span>
          </div>
          {([
            { value: 'none', label: 'هیچ' },
            { value: 'ma', label: 'MA' },
            { value: 'rsi', label: 'RSI' },
            { value: 'macd', label: 'MACD' },
            { value: 'bollinger', label: 'Bollinger' }
          ] as const).map(({ value, label }) => (
            <motion.button
              key={value}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIndicator(value)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-normal ${
                indicator === value
                  ? 'bg-blue text-white shadow-md font-bold'
                  : 'bg-tertiary text-text-tertiary hover:bg-elevated hover:text-primary border border-border-secondary'
              }`}
            >
              {label}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <div className="p-6">
        <div className="h-96 bg-bg-primary rounded-xl p-4 border border-border-secondary">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'line' ? (
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
                <XAxis 
                  dataKey="time" 
                  stroke="#718096"
                  style={{ fontSize: '11px', fontFamily: 'var(--font-numbers-fa)' }}
                  tick={{ fill: '#718096' }}
                />
                <YAxis 
                  stroke="#718096"
                  style={{ fontSize: '11px', fontFamily: 'var(--font-numbers-fa)' }}
                  tick={{ fill: '#718096' }}
                  domain={['auto', 'auto']}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#131832',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '12px',
                    boxShadow: '0 10px 30px rgba(0, 0, 0, 0.5)',
                  }}
                  labelStyle={{ color: '#FFB800', fontWeight: 'bold', marginBottom: '8px' }}
                />
                <Line
                  type="monotone"
                  dataKey="price"
                  stroke={priceColor}
                  strokeWidth={3}
                  dot={false}
                  name="قیمت"
                  animationDuration={500}
                />
                {indicator === 'ma' && (
                  <>
                    <Line type="monotone" dataKey="ma20" stroke="#FFB800" strokeWidth={2} dot={false} name="MA20" />
                    <Line type="monotone" dataKey="ma50" stroke="#00A8FF" strokeWidth={2} dot={false} name="MA50" />
                  </>
                )}
                {indicator === 'rsi' && (
                  <Line type="monotone" dataKey="rsi" stroke="#00A8FF" strokeWidth={3} dot={false} name="RSI" />
                )}
                {indicator === 'macd' && (
                  <>
                    <Line type="monotone" dataKey="macd" stroke="#00A8FF" strokeWidth={2} dot={false} name="MACD" />
                    <Line type="monotone" dataKey="signal" stroke="#FF9500" strokeWidth={2} dot={false} name="Signal" />
                  </>
                )}
                {indicator === 'bollinger' && (
                  <>
                    <Line type="monotone" dataKey="bbUpper" stroke="#FF9500" strokeWidth={1.5} dot={false} name="BB بالا" strokeDasharray="5 5" />
                    <Line type="monotone" dataKey="bbMiddle" stroke="#FFB800" strokeWidth={2} dot={false} name="BB میانه" />
                    <Line type="monotone" dataKey="bbLower" stroke="#FF9500" strokeWidth={1.5} dot={false} name="BB پایین" strokeDasharray="5 5" />
                  </>
                )}
              </LineChart>
            ) : (
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={priceColor} stopOpacity={0.4}/>
                    <stop offset="95%" stopColor={priceColor} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
                <XAxis 
                  dataKey="time" 
                  stroke="#718096"
                  style={{ fontSize: '11px', fontFamily: 'var(--font-numbers-fa)' }}
                  tick={{ fill: '#718096' }}
                />
                <YAxis 
                  stroke="#718096"
                  style={{ fontSize: '11px', fontFamily: 'var(--font-numbers-fa)' }}
                  tick={{ fill: '#718096' }}
                  domain={['auto', 'auto']}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#131832',
                    border: '1px solid rgba(255, 255, 255, 0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '12px',
                    boxShadow: '0 10px 30px rgba(0, 0, 0, 0.5)',
                  }}
                  labelStyle={{ color: '#FFB800', fontWeight: 'bold', marginBottom: '8px' }}
                />
                <Area
                  type="monotone"
                  dataKey="price"
                  stroke={priceColor}
                  strokeWidth={3}
                  fill="url(#colorPrice)"
                  name="قیمت"
                  animationDuration={500}
                />
                {indicator === 'ma' && (
                  <>
                    <Line type="monotone" dataKey="ma20" stroke="#FFB800" strokeWidth={2} dot={false} name="MA20" />
                    <Line type="monotone" dataKey="ma50" stroke="#00A8FF" strokeWidth={2} dot={false} name="MA50" />
                  </>
                )}
                {indicator === 'bollinger' && (
                  <>
                    <Line type="monotone" dataKey="bbUpper" stroke="#FF9500" strokeWidth={1.5} dot={false} name="BB بالا" strokeDasharray="5 5" />
                    <Line type="monotone" dataKey="bbMiddle" stroke="#FFB800" strokeWidth={2} dot={false} name="BB میانه" />
                    <Line type="monotone" dataKey="bbLower" stroke="#FF9500" strokeWidth={1.5} dot={false} name="BB پایین" strokeDasharray="5 5" />
                  </>
                )}
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          {[
            { 
              label: 'قیمت باز', 
              value: `$${selectedAsset.priceHistory[0]?.open.toFixed(2) || 0}`,
              color: 'text-blue'
            },
            { 
              label: 'بیشترین', 
              value: `$${Math.max(...selectedAsset.priceHistory.map(p => p.high)).toFixed(2)}`,
              color: 'text-success'
            },
            { 
              label: 'کمترین', 
              value: `$${Math.min(...selectedAsset.priceHistory.map(p => p.low)).toFixed(2)}`,
              color: 'text-danger'
            },
            { 
              label: 'حجم', 
              value: selectedAsset.priceHistory[selectedAsset.priceHistory.length - 1]?.volume.toLocaleString('en-US') || '0',
              color: 'text-gold'
            }
          ].map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-tertiary border border-border-secondary rounded-xl p-4 hover:bg-elevated 
                         transition-all duration-normal hover-lift"
            >
              <p className="text-text-tertiary text-xs font-medium mb-1">{stat.label}</p>
              <p className={`font-numbers text-xl font-bold ${stat.color}`}>
                {stat.value}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
