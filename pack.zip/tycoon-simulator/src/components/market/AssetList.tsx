import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { ASSET_CATEGORIES } from '../../constants/assets';
import { TrendingUp, TrendingDown, Search, Activity } from 'lucide-react';
import { useState } from 'react';
import { AssetCategory } from '../../types';

export default function AssetList() {
  const assets = useGameStore(state => state.assets);
  const selectedAsset = useGameStore(state => state.selectedAsset);
  const selectAsset = useGameStore(state => state.selectAsset);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<AssetCategory | 'all'>('all');

  const filteredAssets = assets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         asset.symbol.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || asset.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-secondary rounded-xl border border-primary p-6 h-full shadow-lg">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
          <Activity className="w-5 h-5 text-gold" />
        </div>
        <h3 className="font-heading text-xl font-bold text-gold">بازارها</h3>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-tertiary" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="جستجوی دارایی..."
          className="w-full bg-tertiary border border-border-primary rounded-lg pr-10 pl-4 py-3 text-primary text-sm 
                     transition-all duration-normal
                     focus:outline-none focus:border-gold focus:shadow-gold
                     placeholder:text-text-tertiary"
          style={{ fontFamily: 'var(--font-primary-fa)' }}
        />
      </div>

      {/* Category Filter */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap 
                     transition-all duration-normal hover-lift
                     ${selectedCategory === 'all'
                       ? 'bg-gold text-bg-primary shadow-gold font-bold'
                       : 'bg-tertiary text-text-secondary hover:bg-elevated hover:text-primary border border-border-secondary'
                     }`}
        >
          همه ({assets.length})
        </button>
        {Object.entries(ASSET_CATEGORIES).map(([key, label]) => {
          const count = assets.filter(a => a.category === key).length;
          return (
            <button
              key={key}
              onClick={() => setSelectedCategory(key as AssetCategory)}
              className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap 
                         transition-all duration-normal hover-lift
                         ${selectedCategory === key
                           ? 'bg-gold text-bg-primary shadow-gold font-bold'
                           : 'bg-tertiary text-text-secondary hover:bg-elevated hover:text-primary border border-border-secondary'
                         }`}
            >
              {label} ({count})
            </button>
          );
        })}
      </div>

      {/* Asset Count */}
      <div className="mb-3 px-2">
        <p className="text-xs text-text-tertiary">
          نمایش {filteredAssets.length} دارایی
        </p>
      </div>

      {/* Asset List */}
      <div className="space-y-2 max-h-[calc(100vh-400px)] overflow-y-auto pr-1 scrollbar-thin">
        <AnimatePresence mode="popLayout">
          {filteredAssets.map((asset, index) => {
            const isPositive = asset.changePercent >= 0;
            const isSelected = selectedAsset?.id === asset.id;

            return (
              <motion.button
                key={asset.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ 
                  duration: 0.2, 
                  delay: index * 0.02,
                  ease: 'easeOut' 
                }}
                whileHover={{ 
                  scale: 1.02, 
                  transition: { duration: 0.15 } 
                }}
                whileTap={{ scale: 0.98 }}
                onClick={() => selectAsset(asset.id)}
                className={`w-full p-4 rounded-lg transition-all duration-normal
                           ${isSelected
                             ? 'bg-gold/10 border-2 border-gold shadow-gold'
                             : 'bg-tertiary border border-border-secondary hover:border-gold/50 hover:bg-elevated'
                           }`}
              >
                <div className="flex items-center justify-between gap-3">
                  {/* Asset Info */}
                  <div className="text-right flex-1 min-w-0">
                    <p className="font-bold text-primary text-base truncate mb-1">
                      {asset.name}
                    </p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-text-tertiary font-medium">
                        {asset.symbol}
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded bg-bg-elevated text-text-secondary">
                        {ASSET_CATEGORIES[asset.category]}
                      </span>
                    </div>
                  </div>

                  {/* Price & Change */}
                  <div className="text-left">
                    <p className="font-numbers font-bold text-primary text-base mb-1">
                      ${asset.currentPrice.toLocaleString('en-US', { 
                        minimumFractionDigits: 2,
                        maximumFractionDigits: asset.currentPrice < 1 ? 4 : 2
                      })}
                    </p>
                    <div className={`flex items-center gap-1.5 text-sm font-medium ${
                      isPositive ? 'text-success' : 'text-danger'
                    }`}>
                      {isPositive ? (
                        <TrendingUp className="w-4 h-4" strokeWidth={2.5} />
                      ) : (
                        <TrendingDown className="w-4 h-4" strokeWidth={2.5} />
                      )}
                      <span className="font-numbers">
                        {isPositive ? '+' : ''}{asset.changePercent.toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>

                {/* Volatility & Liquidity Indicators (subtle) */}
                {isSelected && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="mt-3 pt-3 border-t border-border-secondary flex gap-4 text-xs"
                  >
                    <div className="flex items-center gap-1.5">
                      <span className="text-text-tertiary">نوسان:</span>
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <div
                            key={i}
                            className={`w-1 h-3 rounded-full ${
                              i < Math.ceil(asset.volatility * 2)
                                ? 'bg-warning'
                                : 'bg-bg-elevated'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-text-tertiary">نقدینگی:</span>
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <div
                            key={i}
                            className={`w-1 h-3 rounded-full ${
                              i < Math.ceil(asset.liquidity * 2.5)
                                ? 'bg-blue'
                                : 'bg-bg-elevated'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </motion.button>
            );
          })}
        </AnimatePresence>

        {/* Empty State */}
        {filteredAssets.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Search className="w-12 h-12 text-text-tertiary mx-auto mb-3 opacity-50" />
            <p className="text-text-secondary text-sm">دارایی‌ای یافت نشد</p>
            <p className="text-text-tertiary text-xs mt-1">جستجوی خود را تغییر دهید</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
