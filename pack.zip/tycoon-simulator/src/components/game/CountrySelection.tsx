import { useState } from 'react';
import { motion } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { COUNTRIES } from '../../constants/countries';
import { Globe, TrendingUp, Factory, Package, Zap } from 'lucide-react';

const bonusIcons = {
  stocks: TrendingUp,
  production: Factory,
  exports: Package,
  tech: Zap,
  energy: Zap,
};

export default function CountrySelection() {
  const [selectedCountry, setSelectedCountry] = useState<string>('');
  const initializeGame = useGameStore(state => state.initializeGame);

  const handleStart = () => {
    if (selectedCountry) {
      initializeGame(selectedCountry);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl w-full"
      >
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Globe className="w-12 h-12 text-amber-500" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-amber-500 to-amber-300 bg-clip-text text-transparent">
              Tycoon Simulator
            </h1>
          </div>
          <p className="text-slate-400 text-lg">
            کشور خود را انتخاب کنید و سفر به سوی ثروت را آغاز کنید
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {COUNTRIES.map((country) => {
            const BonusIcon = bonusIcons[country.bonus.type];
            return (
              <motion.button
                key={country.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedCountry(country.id)}
                className={`
                  p-6 rounded-xl border-2 transition-all
                  ${selectedCountry === country.id
                    ? 'border-amber-500 bg-amber-500/10 shadow-lg shadow-amber-500/20'
                    : 'border-slate-700 bg-slate-800/50 hover:border-slate-600'
                  }
                `}
              >
                <div className="text-5xl mb-3">{country.flag}</div>
                <h3 className="text-xl font-bold text-white mb-2">{country.name}</h3>
                <div className="flex items-center justify-center gap-2 text-sm">
                  <BonusIcon className="w-4 h-4 text-amber-500" />
                  <span className="text-slate-300">
                    +{country.bonus.value}% {
                      country.bonus.type === 'stocks' ? 'سهام' :
                      country.bonus.type === 'production' ? 'تولید' :
                      country.bonus.type === 'exports' ? 'صادرات' :
                      country.bonus.type === 'tech' ? 'فناوری' :
                      'انرژی'
                    }
                  </span>
                </div>
              </motion.button>
            );
          })}
        </div>

        <div className="text-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStart}
            disabled={!selectedCountry}
            className={`
              px-12 py-4 rounded-xl font-bold text-lg transition-all
              ${selectedCountry
                ? 'bg-gradient-to-r from-amber-600 to-amber-500 text-white shadow-lg shadow-amber-500/30 hover:shadow-xl'
                : 'bg-slate-700 text-slate-500 cursor-not-allowed'
              }
            `}
          >
            شروع بازی
          </motion.button>
        </div>

        <div className="mt-12 p-6 bg-slate-800/50 rounded-xl border border-slate-700">
          <h3 className="text-lg font-bold text-white mb-3">اطلاعات اولیه</h3>
          <ul className="space-y-2 text-slate-300 text-sm">
            <li>• سرمایه اولیه: $100,000</li>
            <li>• هر روز = یک جلسه معاملاتی ۹۰ ثانیه‌ای</li>
            <li>• قیمت‌ها هر ۱۰ ثانیه آپدیت می‌شوند</li>
            <li>• برای باز کردن ماژول شرکت به ۵۰ میلیون دلار نیاز دارید</li>
          </ul>
        </div>
      </motion.div>
    </div>
  );
}
