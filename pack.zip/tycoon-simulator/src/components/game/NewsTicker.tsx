import { motion } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { AlertCircle, Radio, Newspaper } from 'lucide-react';

export default function NewsTicker() {
  const activeNews = useGameStore(state => state.activeNews);

  if (activeNews.length === 0) return null;

  return (
    <div className="bg-gradient-to-r from-bg-secondary via-bg-tertiary to-bg-secondary border-b-2 border-border-primary shadow-2xl">
      <div className="flex items-center gap-4 px-6 py-3">
        {/* Icon & Label */}
        <div className="flex items-center gap-2.5 flex-shrink-0">
          <div className="relative">
            <Radio className="w-5 h-5 text-danger animate-pulse-glow" fill="currentColor" />
            <div className="absolute inset-0 animate-ping">
              <Radio className="w-5 h-5 text-danger opacity-75" />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Newspaper className="w-4 h-4 text-gold" />
            <span className="font-heading text-sm font-bold text-gold">اخبار لحظه‌ای</span>
          </div>
        </div>
        
        {/* News Ticker */}
        <div className="flex-1 overflow-hidden relative">
          {/* Gradient fade edges */}
          <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-l from-transparent to-bg-secondary z-10 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-r from-transparent to-bg-secondary z-10 pointer-events-none" />
          
          <div className="flex gap-8 animate-scroll-ticker">
            {[...activeNews, ...activeNews].map((news, index) => (
              <motion.div
                key={`${news.id}-${index}`}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-3 flex-shrink-0"
              >
                {/* Severity Indicator */}
                {news.severity === 'major' ? (
                  <div className="relative">
                    <AlertCircle className="w-4 h-4 text-danger animate-pulse" fill="currentColor" />
                    <div className="absolute -inset-1 bg-danger/20 rounded-full animate-ping" />
                  </div>
                ) : (
                  <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                )}
                
                {/* News Content */}
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-bold whitespace-nowrap ${
                    news.severity === 'major' ? 'text-danger' : 'text-primary'
                  }`}>
                    {news.title}
                  </span>
                  <span className="text-xs text-text-tertiary whitespace-nowrap">
                    • {news.description.slice(0, 80)}...
                  </span>
                </div>
                
                {/* Separator */}
                <div className="w-1 h-4 bg-border-primary rounded-full" />
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Live Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 bg-danger/10 border border-danger/30 rounded-lg flex-shrink-0">
          <div className="w-2 h-2 rounded-full bg-danger animate-pulse" />
          <span className="text-danger text-xs font-bold">LIVE</span>
        </div>
      </div>
    </div>
  );
}
