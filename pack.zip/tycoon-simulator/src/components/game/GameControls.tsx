import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNotification } from '../ui/NotificationProvider';
import { useGameStore } from '../../store/gameStore';
import { 
  Play, 
  Pause, 
  Clock, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  Zap, 
  Save,
  Activity,
  Wallet
} from 'lucide-react';

export default function GameControls() {
  const game = useGameStore(state => state.game);
  const player = useGameStore(state => state.player);
  const startDay = useGameStore(state => state.startDay);
  const pauseDay = useGameStore(state => state.pauseDay);
  const resumeDay = useGameStore(state => state.resumeDay);
  const updateTick = useGameStore(state => state.updateTick);
  const saveGame = useGameStore(state => state.saveGame);
  const fastSimulate = useGameStore(state => state.fastSimulate);
  const notify = useNotification();

  const [showFastSimMenu, setShowFastSimMenu] = useState(false);
  const [clickCount, setClickCount] = useState(0);

  // Triple-click cheat code for testing
  const handleDayClick = () => {
    setClickCount(prev => prev + 1);
    
    setTimeout(() => setClickCount(0), 500);
    
    if (clickCount === 2) {
      // Add $5M for testing company modules
      useGameStore.setState(state => ({
        player: {
          ...state.player,
          cash: state.player.cash + 5000000,
          totalValue: state.player.totalValue + 5000000,
        },
      }));
      notify.success('🎮 حالت توسعه: +$5M اضافه شد!');
      setClickCount(0);
    }
  };

  // Timer effect
  useEffect(() => {
    if (!game.isRunning || game.isPaused) return;

    const interval = setInterval(() => {
      updateTick();
    }, 10000); // 10 seconds

    return () => clearInterval(interval);
  }, [game.isRunning, game.isPaused, updateTick]);

  const handleFastSim = (days: number) => {
    fastSimulate(days);
    setShowFastSimMenu(false);
  };

  const profitPercent = ((player.totalValue - player.startingCapital) / player.startingCapital) * 100;

  return (
    <div className="bg-secondary border-b-2 border-border-primary shadow-xl">
      <div className="max-w-[1920px] mx-auto px-6 py-4">
        <div className="flex items-center justify-between flex-wrap gap-4">
          {/* Left: Game Stats */}
          <div className="flex items-center gap-4 flex-wrap">
            {/* Day Counter */}
            <motion.div 
              className="glass rounded-xl px-4 py-3 cursor-pointer select-none hover-lift
                         border border-border-secondary"
              onClick={handleDayClick}
              title="Triple-click for dev mode"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-xs text-text-tertiary font-medium mb-0.5">روز معاملاتی</p>
                  <p className="font-numbers text-2xl font-extrabold text-gold">
                    {game.currentDay}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Timer */}
            <div className="glass rounded-xl px-4 py-3 border border-border-secondary">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue/10 flex items-center justify-center">
                  <Clock className={`w-5 h-5 text-blue ${game.isRunning && !game.isPaused ? 'animate-pulse' : ''}`} />
                </div>
                <div>
                  <p className="text-xs text-text-tertiary font-medium mb-0.5">زمان باقی‌مانده</p>
                  <p className="font-numbers text-2xl font-extrabold text-blue">
                    {game.isRunning ? `${game.secondsRemaining}s` : '90s'}
                  </p>
                </div>
              </div>
            </div>

            {/* Total Value */}
            <div className="glass rounded-xl px-4 py-3 border border-border-secondary">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-success" />
                </div>
                <div>
                  <p className="text-xs text-text-tertiary font-medium mb-0.5">ارزش کل</p>
                  <p className="font-numbers text-2xl font-extrabold text-primary">
                    ${player.totalValue.toLocaleString('en-US')}
                  </p>
                </div>
              </div>
            </div>

            {/* Daily P&L */}
            <div className="glass rounded-xl px-4 py-3 border border-border-secondary">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  player.dailyPnL >= 0 ? 'bg-success/10' : 'bg-danger/10'
                }`}>
                  <TrendingUp className={`w-5 h-5 ${
                    player.dailyPnL >= 0 ? 'text-success' : 'text-danger rotate-180'
                  }`} />
                </div>
                <div>
                  <p className="text-xs text-text-tertiary font-medium mb-0.5">سود/زیان روزانه</p>
                  <p className={`font-numbers text-xl font-bold ${
                    player.dailyPnL >= 0 ? 'text-success' : 'text-danger'
                  }`}>
                    {player.dailyPnL >= 0 ? '+' : ''}${player.dailyPnL.toLocaleString('en-US', {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2
                    })}
                  </p>
                </div>
              </div>
            </div>

            {/* Total Profit % */}
            <div className="glass rounded-xl px-4 py-3 border border-border-secondary">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  profitPercent >= 0 ? 'bg-gold/10' : 'bg-warning/10'
                }`}>
                  <Activity className={`w-5 h-5 ${
                    profitPercent >= 0 ? 'text-gold' : 'text-warning'
                  }`} />
                </div>
                <div>
                  <p className="text-xs text-text-tertiary font-medium mb-0.5">سود کل</p>
                  <p className={`font-numbers text-xl font-bold ${
                    profitPercent >= 0 ? 'text-gold' : 'text-warning'
                  }`}>
                    {profitPercent >= 0 ? '+' : ''}{profitPercent.toFixed(2)}%
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Game Controls */}
          <div className="flex items-center gap-3">
            {/* Start/Pause Button */}
            {!game.isRunning ? (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={startDay}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-br from-success to-success-dark 
                           text-white rounded-xl font-bold shadow-lg hover:shadow-xl
                           transition-all duration-normal border-2 border-success-light"
              >
                <Play className="w-5 h-5" fill="currentColor" />
                <span className="font-heading">شروع روز</span>
              </motion.button>
            ) : (
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={game.isPaused ? resumeDay : pauseDay}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold shadow-lg hover:shadow-xl
                           transition-all duration-normal border-2
                           ${game.isPaused 
                             ? 'bg-gradient-to-br from-gold to-gold-dark text-bg-primary border-gold-light' 
                             : 'bg-gradient-to-br from-warning to-warning-dark text-white border-warning-light'
                           }`}
              >
                {game.isPaused ? (
                  <>
                    <Play className="w-5 h-5" fill="currentColor" />
                    <span className="font-heading">ادامه</span>
                  </>
                ) : (
                  <>
                    <Pause className="w-5 h-5" fill="currentColor" />
                    <span className="font-heading">توقف</span>
                  </>
                )}
              </motion.button>
            )}

            {/* Fast Simulate */}
            <div className="relative">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowFastSimMenu(!showFastSimMenu)}
                className="flex items-center gap-2 px-5 py-3 bg-tertiary text-primary rounded-xl 
                           font-medium border border-border-primary hover:border-gold
                           transition-all duration-normal hover:bg-elevated shadow-md"
              >
                <Zap className="w-5 h-5 text-gold" />
                <span>شبیه‌سازی سریع</span>
              </motion.button>

              <AnimatePresence>
                {showFastSimMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-full left-0 mt-2 bg-elevated border border-border-primary 
                               rounded-xl shadow-2xl overflow-hidden z-50 min-w-[160px]"
                  >
                    {[7, 30, 90].map(days => (
                      <motion.button
                        key={days}
                        onClick={() => handleFastSim(days)}
                        whileHover={{ backgroundColor: 'var(--bg-tertiary)' }}
                        className="block w-full px-5 py-3 text-right text-primary 
                                   transition-colors border-b border-border-secondary last:border-b-0
                                   hover:text-gold font-medium"
                      >
                        <div className="flex items-center justify-between">
                          <span>{days} روز</span>
                          <Zap className="w-4 h-4 text-gold" />
                        </div>
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Save Button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                saveGame();
                notify.success('بازی ذخیره شد!');
              }}
              className="flex items-center gap-2 px-5 py-3 bg-tertiary text-primary rounded-xl 
                         font-medium border border-border-primary hover:border-blue
                         transition-all duration-normal hover:bg-elevated shadow-md"
            >
              <Save className="w-5 h-5 text-blue" />
              <span>ذخیره</span>
            </motion.button>
          </div>
        </div>

        {/* Progress Bar */}
        <AnimatePresence>
          {game.isRunning && (
            <motion.div 
              className="mt-4"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <div className="w-full bg-bg-elevated rounded-full h-3 border border-border-secondary overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-gold via-gold-light to-gold rounded-full
                             shadow-gold relative overflow-hidden"
                  initial={{ width: '0%' }}
                  animate={{ width: `${(game.ticksInDay / 9) * 100}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                >
                  {/* Shimmer effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent
                                  animate-shimmer" />
                </motion.div>
              </div>
              <div className="flex justify-between items-center mt-2">
                <p className="text-xs text-text-tertiary font-medium">
                  پیشرفت روز: تیک {game.ticksInDay} از 9
                </p>
                <p className="text-xs font-numbers text-text-secondary">
                  {Math.round((game.ticksInDay / 9) * 100)}%
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
