import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight, ArrowLeft, CheckCircle } from 'lucide-react';
import { useGameStore } from '../../store/gameStore';

interface TutorialStep {
  id: string;
  title: string;
  description: string;
  target?: string;
  action?: string;
}

const tutorialSteps: TutorialStep[] = [
  {
    id: 'welcome',
    title: 'خوش آمدید به Tycoon Simulator!',
    description: 'در این بازی شما یک سرمایه‌گذار حرفه‌ای هستید که با معامله در بازارهای مختلف، ثروت خود را افزایش می‌دهید.',
  },
  {
    id: 'start-day',
    title: 'شروع جلسه معاملاتی',
    description: 'هر روز بازی یک جلسه 90 ثانیه‌ای است. برای شروع، دکمه "شروع روز" را کلیک کنید.',
    target: 'start-day-button',
  },
  {
    id: 'select-asset',
    title: 'انتخاب دارایی',
    description: 'از لیست سمت چپ، یک دارایی برای معامله انتخاب کنید. Bitcoin را برای شروع امتحان کنید.',
    target: 'asset-list',
  },
  {
    id: 'place-trade',
    title: 'انجام معامله',
    description: 'از پنل سمت راست، نوع معامله (اسپات یا مارجین)، مقدار و سمت (خرید/فروش) را انتخاب کرده و معامله را انجام دهید.',
    target: 'trading-panel',
  },
  {
    id: 'monitor',
    title: 'نظارت بر معاملات',
    description: 'در تب پورتفولیو می‌توانید معاملات باز خود را مشاهده و مدیریت کنید. سود و زیان به صورت لحظه‌ای نمایش داده می‌شود.',
    target: 'portfolio-tab',
  },
  {
    id: 'complete',
    title: 'آماده‌اید!',
    description: 'شما آماده‌اید! اکنون می‌توانید با استراتژی خود، ثروتمند شوید. موفق باشید!',
  },
];

export default function Tutorial() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [completed, setCompleted] = useState(false);
  const player = useGameStore(state => state.player);

  useEffect(() => {
    // نمایش tutorial برای کاربران جدید
    const tutorialCompleted = localStorage.getItem('tutorial-completed');
    if (!tutorialCompleted && player.country) {
      setTimeout(() => setIsOpen(true), 1000);
    }
  }, [player.country]);

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    setCompleted(true);
    localStorage.setItem('tutorial-completed', 'true');
    setTimeout(() => {
      setIsOpen(false);
      setCompleted(false);
      setCurrentStep(0);
    }, 2000);
  };

  const handleSkip = () => {
    localStorage.setItem('tutorial-completed', 'true');
    setIsOpen(false);
  };

  if (!isOpen) return null;

  const step = tutorialSteps[currentStep];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[10000] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-slate-900 rounded-2xl border-2 border-amber-500/30 p-8 max-w-2xl w-full shadow-2xl"
        >
          {!completed ? (
            <>
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-amber-500/20 flex items-center justify-center">
                    <span className="text-2xl font-bold text-amber-500">
                      {currentStep + 1}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white">{step.title}</h3>
                    <p className="text-sm text-slate-400">
                      مرحله {currentStep + 1} از {tutorialSteps.length}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleSkip}
                  className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
                >
                  <X className="w-6 h-6 text-slate-400" />
                </button>
              </div>

              {/* Content */}
              <div className="mb-8">
                <p className="text-lg text-slate-300 leading-relaxed">
                  {step.description}
                </p>
              </div>

              {/* Progress Bar */}
              <div className="mb-6">
                <div className="w-full bg-slate-800 rounded-full h-2">
                  <motion.div
                    className="bg-gradient-to-r from-amber-600 to-amber-500 h-2 rounded-full"
                    initial={{ width: '0%' }}
                    animate={{ width: `${((currentStep + 1) / tutorialSteps.length) * 100}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between">
                <button
                  onClick={handlePrev}
                  disabled={currentStep === 0}
                  className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all ${
                    currentStep === 0
                      ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                      : 'bg-slate-800 text-white hover:bg-slate-700'
                  }`}
                >
                  <ArrowRight className="w-5 h-5" />
                  قبلی
                </button>

                <div className="flex gap-2">
                  {tutorialSteps.map((_, index) => (
                    <div
                      key={index}
                      className={`w-2 h-2 rounded-full transition-all ${
                        index === currentStep
                          ? 'bg-amber-500 w-8'
                          : index < currentStep
                          ? 'bg-amber-500/50'
                          : 'bg-slate-700'
                      }`}
                    />
                  ))}
                </div>

                <button
                  onClick={handleNext}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-600 to-amber-500 text-white rounded-lg font-bold shadow-lg shadow-amber-500/30 hover:shadow-xl transition-all"
                >
                  {currentStep === tutorialSteps.length - 1 ? 'شروع کنید!' : 'بعدی'}
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              {/* Skip Button */}
              <div className="mt-4 text-center">
                <button
                  onClick={handleSkip}
                  className="text-sm text-slate-500 hover:text-slate-300 transition-colors"
                >
                  رد شدن از آموزش
                </button>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-20 h-20 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4"
              >
                <CheckCircle className="w-12 h-12 text-green-500" />
              </motion.div>
              <h3 className="text-2xl font-bold text-white mb-2">تبریک!</h3>
              <p className="text-slate-400">آموزش با موفقیت تکمیل شد</p>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
