import { useGameStore } from '../../store/gameStore';
import { motion } from 'framer-motion';
import { Award, Trophy } from 'lucide-react';

export default function Achievements() {
  const achievements = useGameStore(state => state.achievements);
  const unlockedCount = achievements.filter(a => a.unlocked).length;

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-700 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center gap-2">
          <Trophy className="w-6 h-6 text-amber-500" />
          دستاوردها
        </h3>
        <span className="text-slate-400 text-sm">
          {unlockedCount} / {achievements.length}
        </span>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {achievements.map(achievement => (
          <motion.div
            key={achievement.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`p-4 rounded-lg border transition-all ${
              achievement.unlocked
                ? 'bg-amber-500/10 border-amber-500'
                : 'bg-slate-800 border-slate-700'
            }`}
          >
            <div className="flex items-start gap-3">
              <Award className={`w-5 h-5 flex-shrink-0 ${
                achievement.unlocked ? 'text-amber-500' : 'text-slate-600'
              }`} />
              <div className="flex-1">
                <h4 className={`font-bold ${achievement.unlocked ? 'text-white' : 'text-slate-500'}`}>
                  {achievement.name}
                </h4>
                <p className={`text-sm ${achievement.unlocked ? 'text-slate-300' : 'text-slate-600'}`}>
                  {achievement.description}
                </p>
                {achievement.reward && achievement.reward > 0 && (
                  <p className="text-xs text-amber-500 mt-1">
                    جایزه: ${achievement.reward.toLocaleString()}
                  </p>
                )}
                {achievement.unlocked && achievement.unlockedAt && (
                  <p className="text-xs text-slate-500 mt-1">
                    باز شده در: {new Date(achievement.unlockedAt).toLocaleDateString('fa-IR')}
                  </p>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
