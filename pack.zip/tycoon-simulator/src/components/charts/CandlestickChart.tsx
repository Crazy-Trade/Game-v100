// Professional Candlestick Chart Component for Tycoon Simulator 3.0
import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import { 
  createChart, 
  IChartApi, 
  ISeriesApi, 
  ColorType,
  LineStyle,
  CrosshairMode,
  PriceScaleMode,
  PriceScalePosition,
  PriceLineSource,
  TickMarkType,
  LineWidth,
  ChartOptions,
  SeriesDataItemTypeMap,
  UTCTimestamp,
  SeriesType
} from 'lightweight-charts';
import { useGameStoreV3 } from '../../store/gameStoreV3';
import type { Asset, PricePoint, TechnicalIndicator, DrawingTool, OrderBookData } from '../../types';
import { Button } from '../ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { 
  TrendingUp, 
  TrendingDown, 
  Volume2, 
  BarChart3, 
  Settings, 
  ZoomIn, 
  ZoomOut,
  RotateCcw,
  Download,
  Save,
  Eye,
  EyeOff,
  Play,
  Pause,
  VolumeX,
  Maximize2,
  Minimize2
} from 'lucide-react';

interface CandlestickChartProps {
  assetId: string;
  className?: string;
  height?: number;
  showControls?: boolean;
  showTechnicalIndicators?: boolean;
  showDrawingTools?: boolean;
  onPriceUpdate?: (price: number) => void;
}

interface ChartData {
  candles: SeriesDataItemTypeMap['Candlestick'];
  volume: SeriesDataItemTypeMap['Histogram'];
}

type TimeframeOption = '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w' | '1M';

const TIMEFRAME_MAP: Record<TimeframeOption, { seconds: number; resolution: string }> = {
  '1m': { seconds: 60, resolution: '1' },
  '5m': { seconds: 300, resolution: '5' },
  '15m': { seconds: 900, resolution: '15' },
  '1h': { seconds: 3600, resolution: '60' },
  '4h': { seconds: 14400, resolution: '240' },
  '1d': { seconds: 86400, resolution: '1D' },
  '1w': { seconds: 604800, resolution: '1W' },
  '1M': { seconds: 2592000, resolution: '1M' }
};

const TECHNICAL_INDICATORS = [
  { id: 'sma', name: 'Simple Moving Average', type: 'sma', color: '#4F46E5', period: 20 },
  { id: 'ema', name: 'Exponential Moving Average', type: 'ema', color: '#7C3AED', period: 21 },
  { id: 'bb', name: 'Bollinger Bands', type: 'bb', color: '#F59E0B', period: 20 },
  { id: 'rsi', name: 'Relative Strength Index', type: 'rsi', color: '#EF4444', period: 14 },
  { id: 'macd', name: 'MACD', type: 'macd', color: '#10B981', period: 12 },
  { id: 'atr', name: 'Average True Range', type: 'atr', color: '#8B5CF6', period: 14 }
];

const DRAWING_TOOLS = [
  { id: 'trendline', name: 'خط روند', icon: '↗️' },
  { id: 'fibonacci', name: 'فیبوناچی', icon: '🌀' },
  { id: 'support', name: 'مقاومت/حمایت', icon: '📊' },
  { id: 'channel', name: 'کانال', icon: '📏' },
  { id: 'triangle', name: 'مثلث', icon: '🔺' },
  { id: 'rectangle', name: 'مستطیل', icon: '▭' }
];

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  assetId,
  className = '',
  height = 600,
  showControls = true,
  showTechnicalIndicators = true,
  showDrawingTools = true,
  onPriceUpdate
}) => {
  // State management
  const [currentTimeframe, setCurrentTimeframe] = useState<TimeframeOption>('1d');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showVolume, setShowVolume] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [activeIndicators, setActiveIndicators] = useState<string[]>(['sma', 'ema', 'rsi']);
  const [activeDrawingTool, setActiveDrawingTool] = useState<string | null>(null);
  const [chartSettings, setChartSettings] = useState({
    theme: 'dark',
    priceScaleMode: 'percentage' as any,
    crosshairMode: 'normal' as any,
    rightOffset: 12,
    barSpacing: 8,
    timeScale: {
      rightOffset: 12,
      barSpacing: 8,
      fixLeftEdge: false,
      lockVisibleTimeRangeOnResize: true,
      rightBarStaysOnScroll: false,
      borderVisible: false,
      borderColor: '#2962FF',
      timeVisible: true,
      secondsVisible: false
    }
  });

  // Refs
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  const technicalSeriesRefs = useRef<Map<string, ISeriesApi<any>>>(new Map());

  // Store and data
  const { assets, updateAssetPrice } = useGameStoreV3();
  const currentAsset = assets.find(asset => asset.id === assetId);

  // Convert PricePoint to Lightweight Charts format
  const convertToChartData = useCallback((priceHistory: PricePoint[], timeframe: TimeframeOption): ChartData[] => {
    if (!priceHistory || priceHistory.length === 0) return [];

    const timeframeMs = TIMEFRAME_MAP[timeframe].seconds * 1000;
    const groupedData = new Map<number, PricePoint[]>();

    // Group data by timeframe
    priceHistory.forEach(pricePoint => {
      const timeBucket = Math.floor(pricePoint.timestamp / timeframeMs) * timeframeMs;
      if (!groupedData.has(timeBucket)) {
        groupedData.set(timeBucket, []);
      }
      groupedData.get(timeBucket)!.push(pricePoint);
    });

    // Convert to chart data
    return Array.from(groupedData.entries())
      .map(([time, points]) => {
        const firstPoint = points[0];
        const lastPoint = points[points.length - 1];
        const high = Math.max(...points.map(p => p.high));
        const low = Math.min(...points.map(p => p.low));
        const volume = points.reduce((sum, p) => sum + (p.volume || 0), 0);

        return {
          candles: {
            time: time / 1000 as UTCTimestamp,
            open: firstPoint.open,
            high: high,
            low: low,
            close: lastPoint.close
          },
          volume: {
            time: time / 1000 as UTCTimestamp,
            value: volume,
            color: lastPoint.close >= firstPoint.open ? '#26a69a' : '#ef5350'
          }
        };
      })
      .sort((a, b) => a.candles.time - b.candles.time);
  }, []);

  // Initialize chart
  const initializeChart = useCallback(() => {
    if (!chartContainerRef.current || !currentAsset) return;

    // Clear existing chart
    if (chartRef.current) {
      chartRef.current.remove();
    }

    // Create new chart
    const chart = createChart(chartContainerRef.current, {
      width: chartContainerRef.current.clientWidth,
      height: height,
      layout: {
        background: { type: 'Solid' as any, color: chartSettings.theme === 'dark' ? '#0f1419' : '#ffffff' },
        textColor: chartSettings.theme === 'dark' ? '#d1d4dc' : '#3a3a3a',
        fontSize: 12,
        fontFamily: 'Inter, system-ui, -apple-system, sans-serif'
      },
      rightPriceScale: {
        borderColor: chartSettings.theme === 'dark' ? '#1e222d' : '#d1d4dc',
        scaleMargins: {
          top: 0.05,
          bottom: 0.15
        },
        mode: chartSettings.priceScaleMode
      },
      leftPriceScale: {
        visible: false,
        scaleMargins: {
          top: 0.05,
          bottom: 0.15
        }
      },
      timeScale: chartSettings.timeScale,
      crosshair: {
        mode: chartSettings.crosshairMode,
        vertLine: {
          width: 1,
          color: chartSettings.theme === 'dark' ? '#758696' : '#758696',
          style: LineStyle.Dashed
        },
        horzLine: {
          width: 1,
          color: chartSettings.theme === 'dark' ? '#758696' : '#758696',
          style: LineStyle.Dashed
        }
      },
      grid: {
        vertLines: { visible: showGrid, color: chartSettings.theme === 'dark' ? '#1e222d' : '#e1e5f0' },
        horzLines: { visible: showGrid, color: chartSettings.theme === 'dark' ? '#1e222d' : '#e1e5f0' }
      }
    });

    chartRef.current = chart;

    // Add candlestick series
    const candlestickSeries = chart.addSeries('Candlestick' as SeriesType, {
      upColor: chartSettings.theme === 'dark' ? '#26a69a' : '#26a69a',
      downColor: chartSettings.theme === 'dark' ? '#ef5350' : '#ef5350',
      borderUpColor: chartSettings.theme === 'dark' ? '#26a69a' : '#26a69a',
      borderDownColor: chartSettings.theme === 'dark' ? '#ef5350' : '#ef5350',
      wickUpColor: chartSettings.theme === 'dark' ? '#26a69a' : '#26a69a',
      wickDownColor: chartSettings.theme === 'dark' ? '#ef5350' : '#ef5350',
      priceLineVisible: true,
      lastValueVisible: true,
      priceLineSource: PriceLineSource.LastBar,
      priceLineColor: chartSettings.theme === 'dark' ? '#2962FF' : '#2962FF',
      priceLineWidth: 2
    });

    candlestickSeriesRef.current = candlestickSeries;

    // Add volume series if enabled
    if (showVolume) {
      const volumeSeries = chart.addSeries('Histogram' as SeriesType, {
        color: chartSettings.theme === 'dark' ? '#26a69a' : '#26a69a',
        priceFormat: {
          type: 'volume'
        },
        priceScaleId: 'volume',
        priceLineVisible: false,
        lastValueVisible: false,
        scaleMargins: {
          top: 0.8,
          bottom: 0
        }
      });

      // Position volume series on the right
      chart.priceScale('volume').applyOptions({
        position: 'Right' as any,
        borderColor: chartSettings.theme === 'dark' ? '#1e222d' : '#d1d4dc',
        borderVisible: true
      });

      volumeSeriesRef.current = volumeSeries;
    }

    // Add technical indicators
    addTechnicalIndicators();

    // Load data
    loadChartData();

    // Set up resize handler
    const handleResize = () => {
      if (chart && chartContainerRef.current) {
        chart.applyOptions({ width: chartContainerRef.current.clientWidth });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [currentAsset, height, chartSettings, showVolume, showGrid]);

  // Load chart data
  const loadChartData = useCallback(() => {
    if (!candlestickSeriesRef.current || !currentAsset?.priceHistory) return;

    const chartData = convertToChartData(currentAsset.priceHistory, currentTimeframe);
    
    if (chartData.length > 0) {
      candlestickSeriesRef.current.setData(chartData.map(d => d.candles));
      
      if (volumeSeriesRef.current && showVolume) {
        volumeSeriesRef.current.setData(chartData.map(d => d.volume));
      }
    }

    // Call price update callback
    if (onPriceUpdate && currentAsset.currentPrice) {
      onPriceUpdate(currentAsset.currentPrice);
    }
  }, [currentAsset, currentTimeframe, convertToChartData, showVolume, onPriceUpdate]);

  // Add technical indicators
  const addTechnicalIndicators = useCallback(() => {
    if (!chartRef.current || !activeIndicators.length) return;

    activeIndicators.forEach(indicatorId => {
      const indicator = TECHNICAL_INDICATORS.find(ind => ind.id === indicatorId);
      if (!indicator) return;

      let series: ISeriesApi<any>;

      switch (indicator.type) {
        case 'sma':
        case 'ema':
          series = chartRef.current!.addSeries('Line' as SeriesType, {
            color: indicator.color,
            lineWidth: 2,
            priceLineVisible: true,
            lastValueVisible: true,
            title: indicator.name
          });
          break;
        case 'bb':
          // Bollinger Bands - upper and lower lines
          const upperSeries = chartRef.current!.addSeries('Line' as SeriesType, {
            color: indicator.color,
            lineWidth: 1,
            lineStyle: LineStyle.Dashed,
            priceLineVisible: false,
            title: 'BB Upper'
          });
          const lowerSeries = chartRef.current!.addSeries('Line' as SeriesType, {
            color: indicator.color,
            lineWidth: 1,
            lineStyle: LineStyle.Dashed,
            priceLineVisible: false,
            title: 'BB Lower'
          });
          technicalSeriesRefs.current.set(`${indicatorId}_upper`, upperSeries);
          technicalSeriesRefs.current.set(`${indicatorId}_lower`, lowerSeries);
          break;
        case 'rsi':
          series = chartRef.current!.addSeries('Line' as SeriesType, {
            color: indicator.color,
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: false,
            title: indicator.name
          });
          // RSI needs separate scale
          chartRef.current!.priceScale('right').applyOptions({
            mode: PriceScaleMode.Normal,
            scaleMargins: {
              top: 0,
              bottom: 0
            }
          });
          break;
        case 'macd':
        case 'atr':
          series = chartRef.current!.addSeries('Line' as SeriesType, {
            color: indicator.color,
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: false,
            title: indicator.name
          });
          break;
        default:
          return;
      }

      if (series && indicator.type !== 'bb') {
        technicalSeriesRefs.current.set(indicatorId, series);
      }
    });
  }, [activeIndicators]);

  // Calculate technical indicator values
  const calculateTechnicalIndicators = useCallback((data: ChartData[]) => {
    const indicators: Record<string, number[]> = {};
    
    activeIndicators.forEach(indicatorId => {
      const indicator = TECHNICAL_INDICATORS.find(ind => ind.id === indicatorId);
      if (!indicator || !data.length) return;

      const closes = data.map(d => d.candles.close);
      const highs = data.map(d => d.candles.high);
      const lows = data.map(d => d.candles.low);

      switch (indicator.type) {
        case 'sma':
          indicators[indicatorId] = calculateSMA(closes, indicator.period);
          break;
        case 'ema':
          indicators[indicatorId] = calculateEMA(closes, indicator.period);
          break;
        case 'bb':
          const bb = calculateBollingerBands(closes, indicator.period);
          indicators[`${indicatorId}_upper`] = bb.upper;
          indicators[`${indicatorId}_lower`] = bb.lower;
          break;
        case 'rsi':
          indicators[indicatorId] = calculateRSI(closes, indicator.period);
          break;
        case 'macd':
          const macd = calculateMACD(closes);
          indicators[indicatorId] = macd.macd;
          break;
        case 'atr':
          indicators[indicatorId] = calculateATR(highs, lows, closes, indicator.period);
          break;
      }
    });

    return indicators;
  }, [activeIndicators]);

  // Technical indicator calculation functions
  const calculateSMA = (data: number[], period: number): number[] => {
    const result: number[] = [];
    for (let i = period - 1; i < data.length; i++) {
      const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
      result.push(sum / period);
    }
    return result;
  };

  const calculateEMA = (data: number[], period: number): number[] => {
    const result: number[] = [];
    const multiplier = 2 / (period + 1);
    result.push(data[0]); // First value is the same

    for (let i = 1; i < data.length; i++) {
      result.push((data[i] * multiplier) + (result[i - 1] * (1 - multiplier)));
    }
    return result;
  };

  const calculateBollingerBands = (data: number[], period: number) => {
    const sma = calculateSMA(data, period);
    const result = { upper: [], lower: [] };
    
    for (let i = 0; i < sma.length; i++) {
      const slice = data.slice(i + period - period, i + period);
      const variance = slice.reduce((sum, val) => sum + Math.pow(val - sma[i], 2), 0) / period;
      const stdDev = Math.sqrt(variance);
      result.upper.push(sma[i] + (stdDev * 2));
      result.lower.push(sma[i] - (stdDev * 2));
    }
    
    return result;
  };

  const calculateRSI = (data: number[], period: number): number[] => {
    const result: number[] = [];
    const changes: number[] = [];
    
    for (let i = 1; i < data.length; i++) {
      changes.push(data[i] - data[i - 1]);
    }
    
    for (let i = period; i <= changes.length; i++) {
      const slice = changes.slice(i - period, i);
      const gains = slice.filter(c => c > 0).reduce((a, b) => a + b, 0) / period;
      const losses = Math.abs(slice.filter(c => c < 0).reduce((a, b) => a + b, 0) / period);
      const rs = gains / (losses || 1);
      result.push(100 - (100 / (1 + rs)));
    }
    
    return result;
  };

  const calculateMACD = (data: number[]) => {
    const ema12 = calculateEMA(data, 12);
    const ema26 = calculateEMA(data, 26);
    const macd: number[] = [];
    
    for (let i = 0; i < Math.min(ema12.length, ema26.length); i++) {
      macd.push(ema12[i] - ema26[i]);
    }
    
    return { macd };
  };

  const calculateATR = (highs: number[], lows: number[], closes: number[], period: number): number[] => {
    const trueRanges: number[] = [];
    
    for (let i = 1; i < highs.length; i++) {
      const tr1 = highs[i] - lows[i];
      const tr2 = Math.abs(highs[i] - closes[i - 1]);
      const tr3 = Math.abs(lows[i] - closes[i - 1]);
      trueRanges.push(Math.max(tr1, tr2, tr3));
    }
    
    return calculateSMA(trueRanges, period);
  };

  // Real-time updates
  useEffect(() => {
    if (!currentAsset) return;

    const interval = setInterval(() => {
      if (isPlaying && chartRef.current) {
        // Simulate real-time price updates
        const newPrice = currentAsset.currentPrice * (1 + (Math.random() - 0.5) * 0.02);
        if (onPriceUpdate) {
          onPriceUpdate(newPrice);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [currentAsset, isPlaying, onPriceUpdate]);

  // Initialize chart on mount
  useEffect(() => {
    if (currentAsset) {
      const cleanup = initializeChart();
      return cleanup;
    }
  }, [initializeChart, currentAsset]);

  // Update chart when timeframe changes
  useEffect(() => {
    if (currentAsset && chartRef.current) {
      loadChartData();
    }
  }, [currentTimeframe, loadChartData, currentAsset]);

  // Chart controls handlers
  const handleTimeframeChange = (timeframe: TimeframeOption) => {
    setCurrentTimeframe(timeframe);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleIndicator = (indicatorId: string) => {
    setActiveIndicators(prev => 
      prev.includes(indicatorId) 
        ? prev.filter(id => id !== indicatorId)
        : [...prev, indicatorId]
    );
  };

  const toggleDrawingTool = (toolId: string) => {
    setActiveDrawingTool(prev => prev === toolId ? null : toolId);
  };

  const resetChart = () => {
    if (chartRef.current) {
      chartRef.current.timeScale().fitContent();
    }
  };

  const exportChart = () => {
    if (chartRef.current) {
      // Implementation for chart export
      console.log('Exporting chart...');
    }
  };

  if (!currentAsset) {
    return (
      <div className={`flex items-center justify-center h-64 ${className}`}>
        <div className="text-center">
          <div className="text-gray-400 mb-2">دارایی یافت نشد</div>
          <div className="text-sm text-gray-500">Asset ID: {assetId}</div>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-background border rounded-lg ${isFullscreen ? 'fixed inset-0 z-50' : ''} ${className}`}>
      {/* Chart Header */}
      {showControls && (
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <h3 className="font-semibold text-lg">{currentAsset.name}</h3>
              <Badge variant="outline" className="text-xs">
                {currentAsset.symbol}
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <span className={`text-lg font-bold ${
                currentAsset.changePercent >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                ${currentAsset.currentPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className={`text-sm ${
                currentAsset.changePercent >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                ({currentAsset.changePercent >= 0 ? '+' : ''}{currentAsset.changePercent.toFixed(2)}%)
              </span>
              {currentAsset.changePercent >= 0 ? (
                <TrendingUp className="w-4 h-4 text-green-600" />
              ) : (
                <TrendingDown className="w-4 h-4 text-red-600" />
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={togglePlay}
              className="gap-2"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isPlaying ? 'مکث' : 'اجرا'}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={resetChart}
              title="ریست نمودار"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={exportChart}
              title="خروجی نمودار"
            >
              <Download className="w-4 h-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={toggleFullscreen}
              title="تمام صفحه"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      )}

      {/* Chart Controls */}
      {showControls && (
        <div className="flex items-center justify-between p-3 border-b bg-muted/30">
          {/* Timeframe Selector */}
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">تایم فریم:</span>
            <div className="flex space-x-1">
              {Object.keys(TIMEFRAME_MAP).map((timeframe) => (
                <Button
                  key={timeframe}
                  variant={currentTimeframe === timeframe ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleTimeframeChange(timeframe as TimeframeOption)}
                  className="text-xs px-2"
                >
                  {timeframe}
                </Button>
              ))}
            </div>
          </div>

          {/* Chart Options */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Switch
                checked={showVolume}
                onCheckedChange={setShowVolume}
              />
              <span className="text-sm">حجم</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                checked={showGrid}
                onCheckedChange={setShowGrid}
              />
              <span className="text-sm">شبکه</span>
            </div>
          </div>
        </div>
      )}

      {/* Chart Container */}
      <div className="relative">
        <div 
          ref={chartContainerRef} 
          className="w-full"
          style={{ height: `${height}px` }}
        />
        
        {/* Loading Overlay */}
        {!currentAsset.priceHistory && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/80">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <div className="text-sm text-muted-foreground">در حال بارگذاری داده...</div>
            </div>
          </div>
        )}
      </div>

      {/* Technical Indicators Panel */}
      {showTechnicalIndicators && (
        <div className="border-t p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">شاخص‌های تکنیکال:</span>
            <div className="flex space-x-2">
              {TECHNICAL_INDICATORS.map((indicator) => (
                <Button
                  key={indicator.id}
                  variant={activeIndicators.includes(indicator.id) ? "default" : "outline"}
                  size="sm"
                  onClick={() => toggleIndicator(indicator.id)}
                  className="text-xs"
                >
                  {indicator.name}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Drawing Tools Panel */}
      {showDrawingTools && (
        <div className="border-t p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">ابزارهای ترسیم:</span>
            <div className="flex space-x-2">
              {DRAWING_TOOLS.map((tool) => (
                <Button
                  key={tool.id}
                  variant={activeDrawingTool === tool.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => toggleDrawingTool(tool.id)}
                  className="text-xs gap-2"
                >
                  <span>{tool.icon}</span>
                  {tool.name}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CandlestickChart;