// Drawing Tools Panel Component
import React, { useState, useCallback } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Pen, 
  Eraser, 
  Square, 
  Circle, 
  ArrowRight, 
  Minus, 
  Plus,
  Trash2,
  Undo,
  Redo,
  Save,
  Download,
  Upload,
  Settings,
  Eye,
  EyeOff,
  Grid3X3,
  Magnet
} from 'lucide-react';
import type { DrawingTool } from '../../types';

interface DrawingToolsPanelProps {
  activeTool: string | null;
  onToolSelect: (toolId: string | null) => void;
  onToolSettingsChange: (settings: DrawingToolSettings) => void;
  onClearTools: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  tools: DrawingTool[];
  className?: string;
}

interface DrawingToolSettings {
  color: string;
  lineWidth: number;
  lineStyle: 'solid' | 'dashed' | 'dotted';
  opacity: number;
  fillOpacity: number;
  showLabels: boolean;
  snapToGrid: boolean;
  autoExtend: boolean;
}

interface Tool {
  id: string;
  name: string;
  nameEn: string;
  icon: React.ReactNode;
  category: 'line' | 'shape' | 'fibonacci' | 'measurement' | 'annotation';
  description: string;
  shortcut?: string;
  defaultSettings: Partial<DrawingToolSettings>;
}

const DRAWING_TOOLS: Tool[] = [
  {
    id: 'select',
    name: 'انتخاب',
    nameEn: 'Select',
    icon: <Settings className="w-4 h-4" />,
    category: 'annotation',
    description: 'انتخاب و ویرایش اشکال',
    shortcut: 'V',
    defaultSettings: { opacity: 1 }
  },
  {
    id: 'hand',
    name: 'دست',
    nameEn: 'Hand',
    icon: <Eraser className="w-4 h-4" />,
    category: 'annotation',
    description: 'حرکت نمودار',
    shortcut: 'H',
    defaultSettings: { opacity: 1 }
  },
  {
    id: 'trendline',
    name: 'خط روند',
    nameEn: 'Trend Line',
    icon: <ArrowRight className="w-4 h-4" />,
    category: 'line',
    description: 'ترسیم خط بین دو نقطه',
    shortcut: 'T',
    defaultSettings: { color: '#4F46E5', lineWidth: 2, lineStyle: 'solid' }
  },
  {
    id: 'horizontal',
    name: 'خط افقی',
    nameEn: 'Horizontal Line',
    icon: <Minus className="w-4 h-4" />,
    category: 'line',
    description: 'خط افقی برای حمایت/مقاومت',
    shortcut: 'H',
    defaultSettings: { color: '#F59E0B', lineWidth: 1, lineStyle: 'dashed' }
  },
  {
    id: 'vertical',
    name: 'خط عمودی',
    nameEn: 'Vertical Line',
    icon: <Plus className="w-4 h-4" />,
    category: 'line',
    description: 'خط عمودی برای تقسیم زمانی',
    shortcut: 'V',
    defaultSettings: { color: '#EF4444', lineWidth: 1, lineStyle: 'dotted' }
  },
  {
    id: 'rectangle',
    name: 'مستطیل',
    nameEn: 'Rectangle',
    icon: <Square className="w-4 h-4" />,
    category: 'shape',
    description: 'مستطیل برای مناطق قیمتی',
    shortcut: 'R',
    defaultSettings: { color: '#10B981', lineWidth: 2, fillOpacity: 0.1 }
  },
  {
    id: 'circle',
    name: 'دایره',
    nameEn: 'Circle',
    icon: <Circle className="w-4 h-4" />,
    category: 'shape',
    description: 'دایره برای دامنه قیمتی',
    shortcut: 'C',
    defaultSettings: { color: '#8B5CF6', lineWidth: 2, fillOpacity: 0.1 }
  },
  {
    id: 'triangle',
    name: 'مثلث',
    nameEn: 'Triangle',
    icon: <div className="w-4 h-4 bg-current" style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }} />,
    category: 'shape',
    description: 'الگوی مثلث',
    shortcut: 'G',
    defaultSettings: { color: '#F97316', lineWidth: 2, fillOpacity: 0.1 }
  },
  {
    id: 'fibonacci',
    name: 'فیبوناچی',
    nameEn: 'Fibonacci',
    icon: <div className="w-4 h-4 flex flex-col justify-center space-y-0.5">
      <div className="h-0.5 bg-current w-full"></div>
      <div className="h-0.5 bg-current w-3/4"></div>
      <div className="h-0.5 bg-current w-1/2"></div>
      <div className="h-0.5 bg-current w-1/3"></div>
      <div className="h-0.5 bg-current w-1/4"></div>
    </div>,
    category: 'fibonacci',
    description: 'سطوح بازگشت فیبوناچی',
    shortcut: 'F',
    defaultSettings: { color: '#EC4899', lineWidth: 1, lineStyle: 'dashed' }
  },
  {
    id: 'channel',
    name: 'کانال',
    nameEn: 'Channel',
    icon: <div className="w-4 h-4 border border-current relative">
      <div className="absolute top-0 left-0 w-full h-full border-t border-current"></div>
      <div className="absolute bottom-0 left-0 w-full h-full border-b border-current"></div>
    </div>,
    category: 'line',
    description: 'کانال قیمتی',
    shortcut: 'K',
    defaultSettings: { color: '#06B6D4', lineWidth: 2, lineStyle: 'solid' }
  },
  {
    id: 'text',
    name: 'متن',
    nameEn: 'Text',
    icon: <Pen className="w-4 h-4" />,
    category: 'annotation',
    description: 'افزودن یادداشت متنی',
    shortcut: 'A',
    defaultSettings: { color: '#1F2937', lineWidth: 1 }
  },
  {
    id: 'measure',
    name: 'اندازه‌گیری',
    nameEn: 'Measure',
    icon: <div className="w-4 h-4 flex items-center justify-center text-xs font-bold">
      1.0
    </div>,
    category: 'measurement',
    description: 'اندازه‌گیری فاصله قیمتی',
    shortcut: 'M',
    defaultSettings: { color: '#6B7280', lineWidth: 1, lineStyle: 'dotted' }
  }
];

const COLORS = [
  { name: 'آبی', value: '#4F46E5' },
  { name: 'قرمز', value: '#EF4444' },
  { name: 'سبز', value: '#10B981' },
  { name: 'نارنجی', value: '#F97316' },
  { name: 'بنفش', value: '#8B5CF6' },
  { name: 'صورتی', value: '#EC4899' },
  { name: 'زرد', value: '#F59E0B' },
  { name: 'فیروزه‌ای', value: '#06B6D4' },
  { name: 'خاکستری', value: '#6B7280' },
  { name: 'سیاه', value: '#1F2937' }
];

const LINE_STYLES = [
  { name: 'پیوسته', value: 'solid' as const },
  { name: 'خط‌چین', value: 'dashed' as const },
  { name: 'نقطه‌چین', value: 'dotted' as const }
];

export const DrawingToolsPanel: React.FC<DrawingToolsPanelProps> = ({
  activeTool,
  onToolSelect,
  onToolSettingsChange,
  onClearTools,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  tools,
  className = ''
}) => {
  const [currentSettings, setCurrentSettings] = useState<DrawingToolSettings>({
    color: '#4F46E5',
    lineWidth: 2,
    lineStyle: 'solid',
    opacity: 1,
    fillOpacity: 0.1,
    showLabels: true,
    snapToGrid: false,
    autoExtend: true
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', name: 'همه' },
    { id: 'line', name: 'خطوط' },
    { id: 'shape', name: 'اشکال' },
    { id: 'fibonacci', name: 'فیبوناچی' },
    { id: 'measurement', name: 'اندازه‌گیری' },
    { id: 'annotation', name: 'یادداشت' }
  ];

  const filteredTools = selectedCategory === 'all' 
    ? DRAWING_TOOLS 
    : DRAWING_TOOLS.filter(tool => tool.category === selectedCategory);

  const handleSettingChange = useCallback((key: keyof DrawingToolSettings, value: any) => {
    const newSettings = { ...currentSettings, [key]: value };
    setCurrentSettings(newSettings);
    onToolSettingsChange(newSettings);
  }, [currentSettings, onToolSettingsChange]);

  const handleToolClick = (toolId: string) => {
    const tool = DRAWING_TOOLS.find(t => t.id === toolId);
    if (tool) {
      onToolSelect(toolId);
      // Apply default settings for the tool
      const toolSettings = { ...currentSettings, ...tool.defaultSettings };
      setCurrentSettings(toolSettings);
      onToolSettingsChange(toolSettings);
    }
  };

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center space-x-2">
            <Pen className="w-5 h-5" />
            <span>ابزارهای ترسیم</span>
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onUndo}
              disabled={!canUndo}
              className="h-8 w-8 p-0"
            >
              <Undo className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onRedo}
              disabled={!canRedo}
              className="h-8 w-8 p-0"
            >
              <Redo className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearTools}
              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
        {tools.length > 0 && (
          <Badge variant="secondary" className="text-xs w-fit">
            {tools.length} ابزار فعال
          </Badge>
        )}
      </CardHeader>

      <CardContent className="p-0">
        {/* Category Tabs */}
        <div className="px-4 border-b">
          <div className="flex space-x-1 overflow-x-auto">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "ghost"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="text-xs whitespace-nowrap h-8"
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Tools Grid */}
        <div className="p-4">
          <div className="grid grid-cols-3 gap-2">
            {filteredTools.map((tool) => (
              <Button
                key={tool.id}
                variant={activeTool === tool.id ? "default" : "outline"}
                size="sm"
                onClick={() => handleToolClick(tool.id)}
                className="flex flex-col items-center space-y-1 p-3 h-auto"
              >
                <div className="text-center">
                  {tool.icon}
                </div>
                <div className="text-xs text-center">
                  {tool.name}
                </div>
                {tool.shortcut && (
                  <div className="text-xs text-muted-foreground">
                    {tool.shortcut}
                  </div>
                )}
              </Button>
            ))}
          </div>
        </div>

        <Separator />

        {/* Settings Panel */}
        {activeTool && (
          <div className="p-4 space-y-4">
            <div>
              <h4 className="text-sm font-medium mb-3">تنظیمات ابزار</h4>
              
              {/* Color */}
              <div className="space-y-2">
                <Label className="text-xs">رنگ</Label>
                <div className="grid grid-cols-5 gap-2">
                  {COLORS.map((color) => (
                    <Button
                      key={color.value}
                      variant={currentSettings.color === color.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleSettingChange('color', color.value)}
                      className="h-8 w-8 p-0"
                      style={{ backgroundColor: color.value }}
                    >
                      {currentSettings.color === color.value && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </Button>
                  ))}
                </div>
              </div>

              <Separator className="my-3" />

              {/* Line Width */}
              <div className="space-y-2">
                <Label className="text-xs">ضخامت خط: {currentSettings.lineWidth}px</Label>
                <Input
                  type="range"
                  min="1"
                  max="10"
                  value={currentSettings.lineWidth}
                  onChange={(e) => handleSettingChange('lineWidth', parseInt(e.target.value))}
                  className="h-2"
                />
              </div>

              {/* Line Style */}
              <div className="space-y-2">
                <Label className="text-xs">سبک خط</Label>
                <Select
                  value={currentSettings.lineStyle}
                  onValueChange={(value) => handleSettingChange('lineStyle', value)}
                >
                  <SelectTrigger className="h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LINE_STYLES.map((style) => (
                      <SelectItem key={style.value} value={style.value}>
                        {style.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Opacity */}
              <div className="space-y-2">
                <Label className="text-xs">شفافیت: {Math.round(currentSettings.opacity * 100)}%</Label>
                <Input
                  type="range"
                  min="0.1"
                  max="1"
                  step="0.1"
                  value={currentSettings.opacity}
                  onChange={(e) => handleSettingChange('opacity', parseFloat(e.target.value))}
                  className="h-2"
                />
              </div>

              {/* Fill Opacity (for shapes) */}
              {(activeTool === 'rectangle' || activeTool === 'circle' || activeTool === 'triangle') && (
                <div className="space-y-2">
                  <Label className="text-xs">شفافیت پر: {Math.round(currentSettings.fillOpacity * 100)}%</Label>
                  <Input
                    type="range"
                    min="0"
                    max="0.5"
                    step="0.1"
                    value={currentSettings.fillOpacity}
                    onChange={(e) => handleSettingChange('fillOpacity', parseFloat(e.target.value))}
                    className="h-2"
                  />
                </div>
              )}

              <Separator className="my-3" />

              {/* Additional Options */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-xs">نمایش برچسب‌ها</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSettingChange('showLabels', !currentSettings.showLabels)}
                    className="h-6 w-6 p-0"
                  >
                    {currentSettings.showLabels ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  </Button>
                </div>

                <div className="flex items-center justify-between">
                  <Label className="text-xs">چسبیدن به شبکه</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSettingChange('snapToGrid', !currentSettings.snapToGrid)}
                    className="h-6 w-6 p-0"
                  >
                    <Magnet className={`w-3 h-3 ${currentSettings.snapToGrid ? 'text-primary' : ''}`} />
                  </Button>
                </div>

                <div className="flex items-center justify-between">
                  <Label className="text-xs">تمدید خودکار</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSettingChange('autoExtend', !currentSettings.autoExtend)}
                    className="h-6 w-6 p-0"
                  >
                    {currentSettings.autoExtend ? <Grid3X3 className="w-3 h-3" /> : <div className="w-3 h-3 border border-current" />}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tools List */}
        {tools.length > 0 && (
          <div className="border-t p-4">
            <h4 className="text-sm font-medium mb-3">ابزارهای ترسیم شده:</h4>
            <ScrollArea className="h-32">
              <div className="space-y-2">
                {tools.map((tool) => (
                  <div
                    key={tool.id}
                    className="flex items-center justify-between p-2 border rounded text-sm"
                  >
                    <div className="flex items-center space-x-2">
                      <div
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: tool.style.color }}
                      ></div>
                      <span>{tool.type}</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {/* Handle delete */}}
                      className="h-6 w-6 p-0"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DrawingToolsPanel;