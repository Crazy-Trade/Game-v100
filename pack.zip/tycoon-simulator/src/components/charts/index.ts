// Charts Components Index - Tycoon Simulator 3.0
export { default as CandlestickChart } from './CandlestickChart';
export { default as ChartHeader } from './ChartHeader';
export { default as TechnicalIndicatorsPanel } from './TechnicalIndicatorsPanel';
export { default as VolumeAndOrderBookPanel } from './VolumeAndOrderBookPanel';
export { default as DrawingToolsPanel } from './DrawingToolsPanel';

// Re-export specific components
export { VolumeChart, OrderBook, VolumeAndOrderBookPanel } from './VolumeAndOrderBook';

// Chart Types
export type { 
  ChartData, 
  TimeframeOption 
} from './CandlestickChart';

export type { 
  DrawingToolSettings 
} from './DrawingToolsPanel';

// Chart Constants
export const CHART_TIMEFRAMES = {
  '1m': { label: '۱ دقیقه', seconds: 60, resolution: '1' },
  '5m': { label: '۵ دقیقه', seconds: 300, resolution: '5' },
  '15m': { label: '۱۵ دقیقه', seconds: 900, resolution: '15' },
  '1h': { label: '۱ ساعت', seconds: 3600, resolution: '60' },
  '4h': { label: '۴ ساعت', seconds: 14400, resolution: '240' },
  '1d': { label: '۱ روز', seconds: 86400, resolution: '1D' },
  '1w': { label: '۱ هفته', seconds: 604800, resolution: '1W' },
  '1M': { label: '۱ ماه', seconds: 2592000, resolution: '1M' }
} as const;

export const TECHNICAL_INDICATORS = [
  { id: 'sma', name: 'Simple Moving Average', type: 'sma', color: '#4F46E5', period: 20 },
  { id: 'ema', name: 'Exponential Moving Average', type: 'ema', color: '#7C3AED', period: 21 },
  { id: 'bb', name: 'Bollinger Bands', type: 'bb', color: '#F59E0B', period: 20 },
  { id: 'rsi', name: 'Relative Strength Index', type: 'rsi', color: '#EF4444', period: 14 },
  { id: 'macd', name: 'MACD', type: 'macd', color: '#10B981', period: 12 },
  { id: 'atr', name: 'Average True Range', type: 'atr', color: '#8B5CF6', period: 14 }
] as const;

export const CHART_COLORS = {
  background: {
    dark: '#0f1419',
    light: '#ffffff'
  },
  text: {
    dark: '#d1d4dc',
    light: '#3a3a3a'
  },
  grid: {
    dark: '#1e222d',
    light: '#e1e5f0'
  },
  border: {
    dark: '#1e222d',
    light: '#d1d4dc'
  },
  up: {
    primary: '#26a69a',
    secondary: 'rgba(38, 166, 154, 0.1)'
  },
  down: {
    primary: '#ef5350',
    secondary: 'rgba(239, 83, 80, 0.1)'
  }
} as const;