// Chart Header Component - Asset Information Display
import React from 'react';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { Card, CardContent } from '../ui/card';
import { 
  TrendingUp, 
  TrendingDown, 
  Star, 
  StarOff, 
  Bell, 
  BellOff,
  Share,
  Download,
  Info,
  DollarSign,
  BarChart3,
  Activity
} from 'lucide-react';
import type { Asset } from '../../types';

interface ChartHeaderProps {
  asset: Asset;
  onWatchlistToggle?: (assetId: string) => void;
  onAlertToggle?: (assetId: string) => void;
  onExport?: (assetId: string) => void;
  onShare?: (assetId: string) => void;
  isWatchlisted?: boolean;
  hasAlerts?: boolean;
  className?: string;
}

export const ChartHeader: React.FC<ChartHeaderProps> = ({
  asset,
  onWatchlistToggle,
  onAlertToggle,
  onExport,
  onShare,
  isWatchlisted = false,
  hasAlerts = false,
  className = ''
}) => {
  const priceChange = asset.currentPrice - asset.previousPrice;
  const priceChangePercent = ((priceChange / asset.previousPrice) * 100);
  const isPositive = priceChange >= 0;

  const formatNumber = (num: number, decimals: number = 2): string => {
    if (num >= 1e12) return `$${(num / 1e12).toFixed(1)}T`;
    if (num >= 1e9) return `$${(num / 1e9).toFixed(1)}B`;
    if (num >= 1e6) return `$${(num / 1e6).toFixed(1)}M`;
    if (num >= 1e3) return `$${(num / 1e3).toFixed(1)}K`;
    return num.toFixed(decimals);
  };

  const formatVolume = (volume: number): string => {
    return formatNumber(volume, 0);
  };

  const formatMarketCap = (marketCap: number): string => {
    return formatNumber(marketCap, 0);
  };

  const getSentimentColor = (sentiment: number) => {
    if (sentiment > 0.6) return 'text-green-500';
    if (sentiment < -0.6) return 'text-red-500';
    return 'text-yellow-500';
  };

  const getSentimentLabel = (sentiment: number) => {
    if (sentiment > 0.6) return 'صعودی قوی';
    if (sentiment > 0.3) return 'صعودی';
    if (sentiment > -0.3) return 'خنثی';
    if (sentiment > -0.6) return 'نزولی';
    return 'نزولی قوی';
  };

  return (
    <div className={`bg-background border rounded-lg ${className}`}>
      {/* Main Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          {/* Asset Info */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h2 className="text-xl font-bold">{asset.name}</h2>
                  <Badge variant="secondary" className="text-xs">
                    {asset.symbol}
                  </Badge>
                  <Badge 
                    variant={asset.category === 'crypto' ? 'default' : 
                           asset.category === 'stock' ? 'outline' : 
                           'destructive'} 
                    className="text-xs"
                  >
                    {asset.category === 'crypto' ? 'رمزارز' :
                     asset.category === 'stock' ? 'سهام' :
                     asset.category === 'commodity' ? 'کالا' :
                     asset.category === 'currency' ? 'ارز' : 'شاخص'}
                  </Badge>
                  {asset.realData && (
                    <Badge variant="default" className="text-xs bg-green-100 text-green-800">
                      داده واقعی
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-2xl font-bold">
                    ${asset.currentPrice.toLocaleString('en-US', { 
                      minimumFractionDigits: 2, 
                      maximumFractionDigits: 6 
                    })}
                  </span>
                  
                  <div className="flex items-center space-x-1">
                    {isPositive ? (
                      <TrendingUp className="w-4 h-4 text-green-500" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-500" />
                    )}
                    <span className={`text-sm font-medium ${
                      isPositive ? 'text-green-500' : 'text-red-500'
                    }`}>
                      ${priceChange >= 0 ? '+' : ''}{priceChange.toFixed(4)}
                    </span>
                    <span className={`text-sm ${
                      isPositive ? 'text-green-500' : 'text-red-500'
                    }`}>
                      ({priceChangePercent >= 0 ? '+' : ''}{priceChangePercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onWatchlistToggle?.(asset.id)}
              className="gap-2"
            >
              {isWatchlisted ? (
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              ) : (
                <StarOff className="w-4 h-4" />
              )}
              {isWatchlisted ? 'نشان‌شده' : 'نشان کردن'}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => onAlertToggle?.(asset.id)}
              className="gap-2"
            >
              {hasAlerts ? (
                <Bell className="w-4 h-4 fill-blue-500 text-blue-500" />
              ) : (
                <BellOff className="w-4 h-4" />
              )}
              {hasAlerts ? 'هشدار فعال' : 'هشدار'}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => onShare?.(asset.id)}
              className="gap-2"
            >
              <Share className="w-4 h-4" />
              اشتراک
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => onExport?.(asset.id)}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              خروجی
            </Button>
          </div>
        </div>
      </div>

      {/* Detailed Stats Tabs */}
      <div className="p-0">
        <Tabs defaultValue="overview" className="w-full">
          <div className="flex items-center justify-between px-4 border-b">
            <TabsList className="h-10">
              <TabsTrigger value="overview" className="text-xs">خلاصه</TabsTrigger>
              <TabsTrigger value="market" className="text-xs">بازار</TabsTrigger>
              <TabsTrigger value="technical" className="text-xs">تکنیکال</TabsTrigger>
            </TabsList>

            <div className="flex items-center space-x-2">
              {asset.sentiment !== undefined && (
                <div className="flex items-center space-x-1">
                  <span className="text-xs text-muted-foreground">احساس بازار:</span>
                  <span className={`text-xs font-medium ${getSentimentColor(asset.sentiment)}`}>
                    {getSentimentLabel(asset.sentiment)}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Overview Tab */}
          <TabsContent value="overview" className="p-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2">
                    <DollarSign className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">قیمت قبلی</p>
                      <p className="text-sm font-medium">
                        ${asset.previousPrice.toFixed(6)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {asset.marketCap && (
                <Card>
                  <CardContent className="p-3">
                    <div className="flex items-center space-x-2">
                      <BarChart3 className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">ارزش بازار</p>
                        <p className="text-sm font-medium">
                          {formatMarketCap(asset.marketCap)}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {asset.volume24h && (
                <Card>
                  <CardContent className="p-3">
                    <div className="flex items-center space-x-2">
                      <Activity className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">حجم ۲۴ساعت</p>
                        <p className="text-sm font-medium">
                          {formatVolume(asset.volume24h)}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {asset.peRatio && (
                <Card>
                  <CardContent className="p-3">
                    <div className="flex items-center space-x-2">
                      <BarChart3 className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="text-xs text-muted-foreground">P/E Ratio</p>
                        <p className="text-sm font-medium">
                          {asset.peRatio.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Market Tab */}
          <TabsContent value="market" className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-3">
                  <h4 className="text-sm font-medium mb-2">نوسان‌پذیری</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-xs text-muted-foreground">Volatility</span>
                      <span className="text-xs">
                        {(asset.volatility || 0).toFixed(2)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1">
                      <div 
                        className="bg-blue-500 h-1 rounded-full" 
                        style={{ width: `${Math.min((asset.volatility || 0), 100)}%` }}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-3">
                  <h4 className="text-sm font-medium mb-2">نقدشوندگی</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-xs text-muted-foreground">Liquidity</span>
                      <span className="text-xs">
                        {((asset.liquidity || 0) * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1">
                      <div 
                        className="bg-green-500 h-1 rounded-full" 
                        style={{ width: `${(asset.liquidity || 0) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Technical Tab */}
          <TabsContent value="technical" className="p-4">
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 border rounded-lg">
                  <div className="text-2xl font-bold text-green-500">
                    {(asset.volatility || 0) < 15 ? 'کم' : 
                     (asset.volatility || 0) < 30 ? 'متوسط' : 'بالا'}
                  </div>
                  <div className="text-xs text-muted-foreground">نوسان‌پذیری</div>
                </div>
                
                <div className="text-center p-3 border rounded-lg">
                  <div className="text-2xl font-bold text-blue-500">
                    {(asset.liquidity || 0) > 0.7 ? 'بالا' : 
                     (asset.liquidity || 0) > 0.4 ? 'متوسط' : 'پایین'}
                  </div>
                  <div className="text-xs text-muted-foreground">نقدشوندگی</div>
                </div>
              </div>

              {asset.sentiment !== undefined && (
                <Card>
                  <CardContent className="p-3">
                    <h4 className="text-sm font-medium mb-2">تحلیل احساسی</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-xs text-muted-foreground">احساس کلی</span>
                        <span className={`text-xs font-medium ${getSentimentColor(asset.sentiment)}`}>
                          {getSentimentLabel(asset.sentiment)}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            asset.sentiment > 0 ? 'bg-green-500' : 'bg-red-500'
                          }`}
                          style={{ 
                            width: `${Math.abs(asset.sentiment) * 100}%`,
                            marginLeft: asset.sentiment < 0 ? 'auto' : '0'
                          }}
                        ></div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Last Updated */}
      <div className="px-4 pb-3 border-t">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>آخرین به‌روزرسانی: {new Date(asset.lastUpdated).toLocaleString('fa-IR')}</span>
          <div className="flex items-center space-x-1">
            <Info className="w-3 h-3" />
            <span>TradingView-like Interface</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChartHeader;