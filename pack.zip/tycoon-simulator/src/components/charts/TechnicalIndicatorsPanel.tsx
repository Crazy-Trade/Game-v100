// Technical Indicators Panel Component
import React, { useState, useCallback } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { ScrollArea } from '../ui/scroll-area';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Settings, 
  Eye, 
  EyeOff,
  BarChart3,
  Activity,
  Target,
  Zap
} from 'lucide-react';
import type { TechnicalIndicator } from '../../types';

interface TechnicalIndicatorsPanelProps {
  activeIndicators: string[];
  onToggleIndicator: (indicatorId: string) => void;
  onIndicatorChange: (indicatorId: string, settings: any) => void;
  indicatorValues?: Record<string, TechnicalIndicator>;
  className?: string;
}

interface IndicatorConfig {
  id: string;
  name: string;
  nameEn: string;
  type: 'trend' | 'momentum' | 'volatility' | 'volume' | 'support';
  category: 'overlay' | 'separate';
  color: string;
  defaultPeriod: number;
  description: string;
  signals: {
    buy: number;
    sell: number;
  };
  parameters: {
    name: string;
    type: 'number' | 'boolean' | 'select';
    default: any;
    options?: string[];
    min?: number;
    max?: number;
    step?: number;
  }[];
}

const INDICATOR_CONFIGS: IndicatorConfig[] = [
  {
    id: 'sma',
    name: 'میانگین متحرک ساده',
    nameEn: 'Simple Moving Average',
    type: 'trend',
    category: 'overlay',
    color: '#4F46E5',
    defaultPeriod: 20,
    description: 'میانگین قیمت در دوره مشخص',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'period', type: 'number', default: 20, min: 2, max: 200, step: 1 }
    ]
  },
  {
    id: 'ema',
    name: 'میانگین متحرک نمایی',
    nameEn: 'Exponential Moving Average',
    type: 'trend',
    category: 'overlay',
    color: '#7C3AED',
    defaultPeriod: 21,
    description: 'میانگین متحرک با وزن بیشتر برای قیمت‌های جدید',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'period', type: 'number', default: 21, min: 2, max: 200, step: 1 }
    ]
  },
  {
    id: 'bb',
    name: 'باندهای بولینجر',
    nameEn: 'Bollinger Bands',
    type: 'volatility',
    category: 'overlay',
    color: '#F59E0B',
    defaultPeriod: 20,
    description: 'اندازه‌گیری نوسان‌پذیری و سطوح حمایت/مقاومت',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'period', type: 'number', default: 20, min: 5, max: 50, step: 1 },
      { name: 'stdDev', type: 'number', default: 2, min: 1, max: 3, step: 0.1 }
    ]
  },
  {
    id: 'rsi',
    name: 'شاخص قدرت نسبی',
    nameEn: 'Relative Strength Index',
    type: 'momentum',
    category: 'separate',
    color: '#EF4444',
    defaultPeriod: 14,
    description: 'اندازه‌گیری سرعت و تغییر قیمت',
    signals: { buy: 70, sell: 30 },
    parameters: [
      { name: 'period', type: 'number', default: 14, min: 2, max: 50, step: 1 },
      { name: 'upperBand', type: 'number', default: 70, min: 50, max: 90, step: 1 },
      { name: 'lowerBand', type: 'number', default: 30, min: 10, max: 50, step: 1 }
    ]
  },
  {
    id: 'macd',
    name: 'MACD',
    nameEn: 'Moving Average Convergence Divergence',
    type: 'momentum',
    category: 'separate',
    color: '#10B981',
    defaultPeriod: 12,
    description: 'اندازه‌گیری رابطه میان دو میانگین متحرک',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'fastPeriod', type: 'number', default: 12, min: 2, max: 50, step: 1 },
      { name: 'slowPeriod', type: 'number', default: 26, min: 10, max: 100, step: 1 },
      { name: 'signalPeriod', type: 'number', default: 9, min: 2, max: 20, step: 1 }
    ]
  },
  {
    id: 'atr',
    name: 'ATR',
    nameEn: 'Average True Range',
    type: 'volatility',
    category: 'separate',
    color: '#8B5CF6',
    defaultPeriod: 14,
    description: 'اندازه‌گیری نوسان‌پذیری بازار',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'period', type: 'number', default: 14, min: 2, max: 50, step: 1 }
    ]
  },
  {
    id: 'vwap',
    name: 'VWAP',
    nameEn: 'Volume Weighted Average Price',
    type: 'volume',
    category: 'overlay',
    color: '#06B6D4',
    defaultPeriod: 1,
    description: 'قیمت میانگین موزون حجمی',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'session', type: 'select', default: 'daily', options: ['daily', 'weekly', 'monthly'] }
    ]
  },
  {
    id: 'stoch',
    name: 'استوکاستیک',
    nameEn: 'Stochastic Oscillator',
    type: 'momentum',
    category: 'separate',
    color: '#F97316',
    defaultPeriod: 14,
    description: 'مقایسه قیمت بسته‌شدن با دامنه قیمت',
    signals: { buy: 80, sell: 20 },
    parameters: [
      { name: 'kPeriod', type: 'number', default: 14, min: 2, max: 50, step: 1 },
      { name: 'dPeriod', type: 'number', default: 3, min: 1, max: 20, step: 1 }
    ]
  },
  {
    id: 'adx',
    name: 'ADX',
    nameEn: 'Average Directional Index',
    type: 'trend',
    category: 'separate',
    color: '#84CC16',
    defaultPeriod: 14,
    description: 'قدت روند بازار',
    signals: { buy: 25, sell: 25 },
    parameters: [
      { name: 'period', type: 'number', default: 14, min: 2, max: 50, step: 1 }
    ]
  },
  {
    id: 'fibonacci',
    name: 'فیبوناچی',
    nameEn: 'Fibonacci Retracements',
    type: 'support',
    category: 'overlay',
    color: '#EC4899',
    defaultPeriod: 1,
    description: 'سطوح بازگشت فیبوناچی',
    signals: { buy: 0, sell: 0 },
    parameters: [
      { name: 'levels', type: 'select', default: 'standard', options: ['standard', 'extended'] }
    ]
  }
];

const getIndicatorIcon = (type: string) => {
  switch (type) {
    case 'trend': return <TrendingUp className="w-4 h-4" />;
    case 'momentum': return <Zap className="w-4 h-4" />;
    case 'volatility': return <Activity className="w-4 h-4" />;
    case 'volume': return <BarChart3 className="w-4 h-4" />;
    case 'support': return <Target className="w-4 h-4" />;
    default: return <BarChart3 className="w-4 h-4" />;
  }
};

const getSignalIcon = (signal: 'buy' | 'sell' | 'hold', strength: number) => {
  const color = signal === 'buy' ? 'text-green-500' : signal === 'sell' ? 'text-red-500' : 'text-yellow-500';
  const Icon = signal === 'buy' ? TrendingUp : signal === 'sell' ? TrendingDown : Minus;
  
  return (
    <div className="flex items-center space-x-1">
      <Icon className={`w-3 h-3 ${color}`} />
      <span className={`text-xs ${color}`}>
        {signal === 'buy' ? 'خرید' : signal === 'sell' ? 'فروش' : 'نگهداری'}
      </span>
      <span className="text-xs text-muted-foreground">
        ({Math.round(strength * 100)}%)
      </span>
    </div>
  );
};

export const TechnicalIndicatorsPanel: React.FC<TechnicalIndicatorsPanelProps> = ({
  activeIndicators,
  onToggleIndicator,
  onIndicatorChange,
  indicatorValues = {},
  className = ''
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [indicatorSettings, setIndicatorSettings] = useState<Record<string, any>>({});

  const categories = [
    { id: 'all', name: 'همه' },
    { id: 'trend', name: 'روند' },
    { id: 'momentum', name: 'مومنتوم' },
    { id: 'volatility', name: 'نوسان' },
    { id: 'volume', name: 'حجم' },
    { id: 'support', name: 'حمایت' }
  ];

  const filteredIndicators = selectedCategory === 'all' 
    ? INDICATOR_CONFIGS 
    : INDICATOR_CONFIGS.filter(ind => ind.type === selectedCategory);

  const handleParameterChange = useCallback((indicatorId: string, paramName: string, value: any) => {
    const updatedSettings = {
      ...indicatorSettings,
      [indicatorId]: {
        ...indicatorSettings[indicatorId],
        [paramName]: value
      }
    };
    setIndicatorSettings(updatedSettings);
    onIndicatorChange(indicatorId, updatedSettings[indicatorId]);
  }, [indicatorSettings, onIndicatorChange]);

  const resetToDefaults = (indicatorId: string) => {
    const indicator = INDICATOR_CONFIGS.find(ind => ind.id === indicatorId);
    if (indicator) {
      const defaultSettings: any = {};
      indicator.parameters.forEach(param => {
        defaultSettings[param.name] = param.default;
      });
      setIndicatorSettings(prev => ({
        ...prev,
        [indicatorId]: defaultSettings
      }));
      onIndicatorChange(indicatorId, defaultSettings);
    }
  };

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center space-x-2">
            <BarChart3 className="w-5 h-5" />
            <span>شاخص‌های تکنیکال</span>
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            {activeIndicators.length} فعال
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {/* Category Tabs */}
        <div className="px-4 border-b">
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="h-8 w-full justify-start">
              {categories.map((category) => (
                <TabsTrigger 
                  key={category.id} 
                  value={category.id}
                  className="text-xs h-6 px-3"
                >
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        {/* Indicators List */}
        <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
          {filteredIndicators.map((indicator) => {
            const isActive = activeIndicators.includes(indicator.id);
            const currentSettings = indicatorSettings[indicator.id] || {};
            const indicatorValue = indicatorValues[indicator.id];

            return (
              <div 
                key={indicator.id} 
                className={`p-3 border rounded-lg transition-colors ${
                  isActive ? 'border-primary bg-primary/5' : 'border-border'
                }`}
              >
                {/* Indicator Header */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getIndicatorIcon(indicator.type)}
                    <div>
                      <h4 className="text-sm font-medium">{indicator.name}</h4>
                      <p className="text-xs text-muted-foreground">{indicator.nameEn}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {isActive && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => resetToDefaults(indicator.id)}
                        className="h-6 w-6 p-0"
                        title="بازگردانی به تنظیمات پیش‌فرض"
                      >
                        <Settings className="w-3 h-3" />
                      </Button>
                    )}
                    <Switch
                      checked={isActive}
                      onCheckedChange={() => onToggleIndicator(indicator.id)}
                      size="sm"
                    />
                  </div>
                </div>

                {/* Description */}
                <p className="text-xs text-muted-foreground mb-3">
                  {indicator.description}
                </p>

                {/* Current Value */}
                {isActive && indicatorValue && (
                  <div className="mb-3 p-2 bg-muted/50 rounded text-xs">
                    <div className="flex items-center justify-between">
                      <span>مقدار فعلی:</span>
                      <span className="font-medium">{indicatorValue.value.toFixed(4)}</span>
                    </div>
                    <div className="mt-1">
                      {getSignalIcon(indicatorValue.signal, indicatorValue.strength)}
                    </div>
                  </div>
                )}

                {/* Parameters */}
                {isActive && (
                  <div className="space-y-2">
                    {indicator.parameters.map((param) => (
                      <div key={param.name} className="grid grid-cols-2 gap-2 items-center">
                        <Label className="text-xs">
                          {param.name === 'period' ? 'دوره' :
                           param.name === 'fastPeriod' ? 'سریع' :
                           param.name === 'slowPeriod' ? 'آهسته' :
                           param.name === 'signalPeriod' ? 'سیگنال' :
                           param.name === 'upperBand' ? 'باند بالا' :
                           param.name === 'lowerBand' ? 'باند پایین' :
                           param.name === 'kPeriod' ? 'K' :
                           param.name === 'dPeriod' ? 'D' :
                           param.name === 'stdDev' ? 'انحراف' :
                           param.name === 'session' ? 'جلسه' :
                           param.name === 'levels' ? 'سطوح' : param.name}:
                        </Label>
                        
                        {param.type === 'number' ? (
                          <Input
                            type="number"
                            value={currentSettings[param.name] || param.default}
                            onChange={(e) => handleParameterChange(
                              indicator.id, 
                              param.name, 
                              parseFloat(e.target.value)
                            )}
                            min={param.min}
                            max={param.max}
                            step={param.step}
                            className="h-6 text-xs"
                          />
                        ) : param.type === 'boolean' ? (
                          <Switch
                            checked={currentSettings[param.name] || false}
                            onCheckedChange={(checked) => handleParameterChange(
                              indicator.id, 
                              param.name, 
                              checked
                            )}
                            size="sm"
                          />
                        ) : param.type === 'select' ? (
                          <Select
                            value={currentSettings[param.name] || param.default}
                            onValueChange={(value) => handleParameterChange(
                              indicator.id, 
                              param.name, 
                              value
                            )}
                          >
                            <SelectTrigger className="h-6 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {param.options?.map((option) => (
                                <SelectItem key={option} value={option}>
                                  {option}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : null}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Active Indicators Summary */}
        {activeIndicators.length > 0 && (
          <div className="p-4 border-t bg-muted/30">
            <h4 className="text-sm font-medium mb-2">شاخص‌های فعال:</h4>
            <div className="flex flex-wrap gap-2">
              {activeIndicators.map((indicatorId) => {
                const indicator = INDICATOR_CONFIGS.find(ind => ind.id === indicatorId);
                const value = indicatorValues[indicatorId];
                
                return (
                  <Badge 
                    key={indicatorId}
                    variant="secondary" 
                    className="text-xs"
                    style={{ borderColor: indicator?.color }}
                  >
                    {indicator?.name}
                    {value && (
                      <span className="ml-1 text-muted-foreground">
                        ({value.value.toFixed(2)})
                      </span>
                    )}
                  </Badge>
                );
              })}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default TechnicalIndicatorsPanel;