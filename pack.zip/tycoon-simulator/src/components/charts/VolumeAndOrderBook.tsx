// Volume Chart and Order Book Component
import React, { useState, useEffect } from 'react';
import { createChart, IChartApi, ISeriesApi } from 'lightweight-charts';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { ScrollArea } from '../ui/scroll-area';
import { ScrollArea } from '../ui/scroll-area';
import { 
  Volume2, 
  TrendingUp, 
  TrendingDown,
  BarChart3,
  DollarSign,
  Activity
} from 'lucide-react';
import type { PricePoint, OrderBookData, OrderBookLevel } from '../../types';

interface VolumeChartProps {
  data: PricePoint[];
  currentPrice: number;
  className?: string;
  showVolumeProfile?: boolean;
}

interface OrderBookProps {
  orderBook: OrderBookData;
  className?: string;
  maxLevels?: number;
}

const VolumeChart: React.FC<VolumeChartProps> = ({
  data,
  currentPrice,
  className = '',
  showVolumeProfile = true
}) => {
  const chartRef = React.useRef<HTMLDivElement>(null);
  const chartInstanceRef = React.useRef<IChartApi | null>(null);

  useEffect(() => {
    if (!chartRef.current || !data.length) return;

    // Clean up existing chart
    if (chartInstanceRef.current) {
      chartInstanceRef.current.remove();
    }

    // Create new chart
    const chart = createChart(chartRef.current, {
      width: chartRef.current.clientWidth,
      height: 200,
      layout: {
        background: { type: 'Solid' as any, color: 'transparent' },
        textColor: '#d1d4dc',
      },
      rightPriceScale: {
        borderColor: '#1e222d',
        scaleMargins: {
          top: 0.1,
          bottom: 0.1
        }
      },
      timeScale: {
        borderColor: '#1e222d',
        timeVisible: false,
        secondsVisible: false
      },
      crosshair: {
        mode: 0
      },
      grid: {
        vertLines: { visible: false },
        horzLines: { visible: false }
      }
    });

    chartInstanceRef.current = chart;

    // Add volume bars
    const volumeSeries = chart.addSeries('Histogram' as any, {
      color: '#26a69a',
      priceFormat: {
        type: 'volume'
      },
      priceScaleId: 'volume',
      scaleMargins: {
        top: 0.7,
        bottom: 0
      }
    });

    // Process and set volume data
    const volumeData = data.map((point, index) => ({
      time: point.timestamp / 1000 as any,
      value: point.volume || 0,
      color: point.close >= point.open ? '#26a69a' : '#ef5350'
    }));

    volumeSeries.setData(volumeData);

    // Resize handler
    const handleResize = () => {
      if (chart && chartRef.current) {
        chart.applyOptions({ width: chartRef.current.clientWidth });
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [data]);

  const totalVolume = data.reduce((sum, point) => sum + (point.volume || 0), 0);
  const avgVolume = totalVolume / data.length;
  const currentVolume = data[data.length - 1]?.volume || 0;
  const volumeRatio = currentVolume / avgVolume;

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center space-x-2">
            <Volume2 className="w-5 h-5" />
            <span>حجم معاملات</span>
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Badge variant={volumeRatio > 1.5 ? 'destructive' : volumeRatio > 1 ? 'default' : 'secondary'}>
              {volumeRatio > 1.5 ? 'بالا' : volumeRatio > 1 ? 'متوسط' : 'پایین'}
            </Badge>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div ref={chartRef} className="w-full" style={{ height: '200px' }} />
        
        <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
          <div>
            <div className="text-muted-foreground text-xs">حجم فعلی</div>
            <div className="font-medium">{currentVolume.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs">میانگین</div>
            <div className="font-medium">{avgVolume.toLocaleString()}</div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs">کل</div>
            <div className="font-medium">{totalVolume.toLocaleString()}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const OrderBook: React.FC<OrderBookProps> = ({
  orderBook,
  className = '',
  maxLevels = 20
}) => {
  const formatPrice = (price: number) => {
    return price.toFixed(price > 100 ? 2 : price > 1 ? 4 : 6);
  };

  const formatQuantity = (quantity: number) => {
    if (quantity >= 1000000) return `${(quantity / 1000000).toFixed(1)}M`;
    if (quantity >= 1000) return `${(quantity / 1000).toFixed(1)}K`;
    return quantity.toFixed(0);
  };

  const maxBidQuantity = Math.max(...orderBook.bids.map(bid => bid.quantity));
  const maxAskQuantity = Math.max(...orderBook.asks.map(ask => ask.quantity));
  const maxQuantity = Math.max(maxBidQuantity, maxAskQuantity);

  return (
    <Card className={className}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center space-x-2">
            <BarChart3 className="w-5 h-5" />
            <span>دفتر سفارشات</span>
          </CardTitle>
          <div className="text-right">
            <div className="text-sm text-muted-foreground">اسپرد</div>
            <div className="font-medium">
              {orderBook.spreadPercent.toFixed(3)}%
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="bids" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="bids" className="text-green-600">
              پیشنهادات خرید
            </TabsTrigger>
            <TabsTrigger value="asks" className="text-red-600">
              پیشنهادات فروش
            </TabsTrigger>
          </TabsList>

          <TabsContent value="bids" className="mt-3">
            <div className="space-y-1">
              {/* Header */}
              <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground border-b pb-1">
                <div>قیمت</div>
                <div>مقدار</div>
                <div className="text-right">مجموع</div>
              </div>
              
              {/* Bid levels */}
              <ScrollArea className="h-64">
                <div className="space-y-1">
                  {orderBook.bids.slice(0, maxLevels).map((bid, index) => (
                    <div 
                      key={index}
                      className="grid grid-cols-3 gap-2 text-xs py-1 hover:bg-green-50 dark:hover:bg-green-950 rounded"
                    >
                      <div className="text-green-600 font-medium">
                        {formatPrice(bid.price)}
                      </div>
                      <div className="text-muted-foreground">
                        {formatQuantity(bid.quantity)}
                      </div>
                      <div className="text-right">
                        <div 
                          className="h-2 bg-green-500/20 rounded"
                          style={{ 
                            width: `${(bid.quantity / maxQuantity) * 100}%` 
                          }}
                        ></div>
                        <span className="text-muted-foreground text-xs">
                          {formatQuantity(bid.total)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="asks" className="mt-3">
            <div className="space-y-1">
              {/* Header */}
              <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground border-b pb-1">
                <div>قیمت</div>
                <div>مقدار</div>
                <div className="text-right">مجموع</div>
              </div>
              
              {/* Ask levels */}
              <ScrollArea className="h-64">
                <div className="space-y-1">
                  {orderBook.asks.slice(0, maxLevels).map((ask, index) => (
                    <div 
                      key={index}
                      className="grid grid-cols-3 gap-2 text-xs py-1 hover:bg-red-50 dark:hover:bg-red-950 rounded"
                    >
                      <div className="text-red-600 font-medium">
                        {formatPrice(ask.price)}
                      </div>
                      <div className="text-muted-foreground">
                        {formatQuantity(ask.quantity)}
                      </div>
                      <div className="text-right">
                        <div 
                          className="h-2 bg-red-500/20 rounded"
                          style={{ 
                            width: `${(ask.quantity / maxQuantity) * 100}%` 
                          }}
                        ></div>
                        <span className="text-muted-foreground text-xs">
                          {formatQuantity(ask.total)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>
        </Tabs>

        {/* Market summary */}
        <div className="mt-4 p-3 bg-muted/30 rounded-lg">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground text-xs">آخرین قیمت</div>
              <div className="font-medium">{formatPrice(orderBook.lastPrice)}</div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs">اسپرد</div>
              <div className="font-medium">
                {orderBook.spread.toFixed(6)} ({(orderBook.spreadPercent * 100).toFixed(3)}%)
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const VolumeAndOrderBookPanel: React.FC<{
  priceHistory: PricePoint[];
  currentPrice: number;
  orderBook?: OrderBookData;
  className?: string;
}> = ({ priceHistory, currentPrice, orderBook, className = '' }) => {
  const [activeTab, setActiveTab] = useState<'volume' | 'orderbook'>('volume');

  // Generate mock order book if not provided
  const generateMockOrderBook = (currentPrice: number): OrderBookData => {
    const bids: OrderBookLevel[] = [];
    const asks: OrderBookLevel[] = [];
    
    // Generate bid levels (prices below current)
    for (let i = 1; i <= 20; i++) {
      const price = currentPrice * (1 - (i * 0.0001));
      const quantity = Math.random() * 1000 + 100;
      const total = quantity * (21 - i);
      bids.push({ price, quantity, total });
    }
    
    // Generate ask levels (prices above current)
    for (let i = 1; i <= 20; i++) {
      const price = currentPrice * (1 + (i * 0.0001));
      const quantity = Math.random() * 1000 + 100;
      const total = quantity * (21 - i);
      asks.push({ price, quantity, total });
    }
    
    // Calculate spread
    const bestBid = bids[0].price;
    const bestAsk = asks[0].price;
    const spread = bestAsk - bestBid;
    const spreadPercent = (spread / currentPrice) * 100;
    
    return {
      bids: bids.sort((a, b) => b.price - a.price),
      asks: asks.sort((a, b) => a.price - b.price),
      spread,
      spreadPercent,
      lastPrice: currentPrice
    };
  };

  const orderBookData = orderBook || generateMockOrderBook(currentPrice);

  return (
    <div className={className}>
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="volume" className="gap-2">
            <Volume2 className="w-4 h-4" />
            حجم
          </TabsTrigger>
          <TabsTrigger value="orderbook" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            دفتر سفارشات
          </TabsTrigger>
        </TabsList>

        <TabsContent value="volume" className="mt-4">
          <VolumeChart 
            data={priceHistory} 
            currentPrice={currentPrice}
            className="w-full"
          />
        </TabsContent>

        <TabsContent value="orderbook" className="mt-4">
          <OrderBook 
            orderBook={orderBookData}
            className="w-full"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export { VolumeChart, OrderBook, VolumeAndOrderBookPanel };
export default VolumeAndOrderBookPanel;