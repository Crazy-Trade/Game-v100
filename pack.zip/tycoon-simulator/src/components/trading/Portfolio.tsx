import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { 
  TrendingUp, 
  TrendingDown, 
  X, 
  AlertTriangle, 
  Wallet,
  DollarSign,
  Activity,
  Target,
  Clock,
  Zap,
  Award,
  CheckCircle2
} from 'lucide-react';

export default function Portfolio() {
  const openTrades = useGameStore(state => state.openTrades);
  const closedTrades = useGameStore(state => state.closedTrades);
  const closeTrade = useGameStore(state => state.closeTrade);
  const player = useGameStore(state => state.player);

  const totalPnL = openTrades.reduce((sum, trade) => sum + trade.pnl, 0);
  const totalPnLPercent = openTrades.length > 0
    ? (totalPnL / openTrades.reduce((sum, trade) => sum + trade.margin, 0)) * 100
    : 0;

  // آمار معاملات بسته شده
  const successfulTrades = closedTrades.filter(t => t.pnl > 0).length;
  const totalClosedTrades = closedTrades.length;
  const winRate = totalClosedTrades > 0 
    ? (successfulTrades / totalClosedTrades) * 100 
    : 0;

  return (
    <div className="space-y-4">
      {/* هدر و خلاصه */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold gradient-text flex items-center gap-2">
            <Wallet size={28} />
            پورتفولیو من
          </h3>
          <div className="text-left">
            <p className="text-xs text-muted mb-1">سود/زیان کل</p>
            <p className={`text-2xl font-bold flex items-center gap-2 ${
              totalPnL >= 0 ? 'text-success' : 'text-danger'
            }`}>
              {totalPnL >= 0 ? <TrendingUp size={24} /> : <TrendingDown size={24} />}
              {totalPnL >= 0 ? '+' : ''}${Math.abs(totalPnL).toFixed(2)}
            </p>
            <p className={`text-sm ${totalPnL >= 0 ? 'text-success' : 'text-danger'}`}>
              ({totalPnL >= 0 ? '+' : ''}{totalPnLPercent.toFixed(2)}%)
            </p>
          </div>
        </div>

        {/* آمار کلی */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="glass-card p-4 border border-gold/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="text-gold" size={20} />
              <p className="text-xs text-muted">موجودی نقدی</p>
            </div>
            <p className="text-xl font-bold text-white">
              ${player.cash.toLocaleString()}
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="glass-card p-4 border border-blue/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <Activity className="text-blue" size={20} />
              <p className="text-xs text-muted">ارزش دارایی‌ها</p>
            </div>
            <p className="text-xl font-bold text-white">
              ${player.totalAssets.toLocaleString()}
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="glass-card p-4 border border-gold/30"
          >
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="text-gold" size={20} />
              <p className="text-xs text-muted">ارزش کل</p>
            </div>
            <p className="text-xl font-bold gradient-text">
              ${player.totalValue.toLocaleString()}
            </p>
          </motion.div>

          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="glass-card p-4 border border-success/20"
          >
            <div className="flex items-center gap-2 mb-2">
              <Award className="text-success" size={20} />
              <p className="text-xs text-muted">نرخ برد</p>
            </div>
            <p className="text-xl font-bold text-success">
              {winRate.toFixed(1)}%
            </p>
            <p className="text-xs text-muted mt-1">
              {successfulTrades} از {totalClosedTrades}
            </p>
          </motion.div>
        </div>
      </div>

      {/* معاملات باز */}
      <div className="glass-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-xl font-bold gradient-text flex items-center gap-2">
            <Activity size={24} />
            معاملات باز
          </h4>
          <div className="px-3 py-1 rounded-full bg-gold/20 text-gold font-bold">
            {openTrades.length}
          </div>
        </div>

        <AnimatePresence mode="popLayout">
          {openTrades.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-12"
            >
              <Target className="w-16 h-16 mx-auto text-muted mb-3" />
              <p className="text-muted">هیچ معامله بازی وجود ندارد</p>
              <p className="text-sm text-muted/60 mt-2">
                برای شروع، یک دارایی انتخاب کرده و معامله باز کنید
              </p>
            </motion.div>
          ) : (
            <div className="space-y-3">
              {openTrades.map((trade, index) => {
                const isProfit = trade.pnl >= 0;
                const liquidationRisk = trade.liquidationPrice
                  ? Math.abs(((trade.currentPrice - trade.liquidationPrice) / trade.currentPrice) * 100)
                  : null;
                const isHighRisk = liquidationRisk !== null && liquidationRisk < 10;

                return (
                  <motion.div
                    key={trade.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ scale: 1.01 }}
                    className={`glass-card p-4 border ${
                      isHighRisk 
                        ? 'border-danger/50 bg-danger/5' 
                        : 'border-gold/20'
                    }`}
                  >
                    {/* هدر */}
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h5 className="font-bold text-white text-lg">
                          {trade.assetName}
                        </h5>
                        <span className={`px-3 py-1 rounded-lg text-xs font-bold ${
                          trade.side === 'long'
                            ? 'bg-success/20 text-success'
                            : 'bg-danger/20 text-danger'
                        }`}>
                          {trade.side === 'long' ? (
                            <span className="flex items-center gap-1">
                              <TrendingUp size={14} />
                              خرید (Long)
                            </span>
                          ) : (
                            <span className="flex items-center gap-1">
                              <TrendingDown size={14} />
                              فروش (Short)
                            </span>
                          )}
                        </span>
                        {trade.type === 'margin' && (
                          <span className="px-3 py-1 rounded-lg text-xs font-bold bg-gold/20 text-gold flex items-center gap-1">
                            <Zap size={14} />
                            {trade.leverage}x
                          </span>
                        )}
                        <span className="px-3 py-1 rounded-lg text-xs font-medium bg-blue/10 text-blue">
                          {trade.type === 'spot' ? 'اسپات' : 'مارجین'}
                        </span>
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.1, rotate: 90 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => closeTrade(trade.id)}
                        className="p-2 hover:bg-danger/20 rounded-lg transition-colors group"
                      >
                        <X className="w-5 h-5 text-muted group-hover:text-danger" />
                      </motion.button>
                    </div>

                    {/* جزئیات قیمت */}
                    <div className="grid grid-cols-3 gap-3 mb-3">
                      <div className="glass-card p-3 border border-gold/10">
                        <p className="text-xs text-muted mb-1">قیمت ورود</p>
                        <p className="text-sm font-bold text-white">
                          ${trade.entryPrice.toFixed(2)}
                        </p>
                      </div>
                      <div className="glass-card p-3 border border-blue/10">
                        <p className="text-xs text-muted mb-1">قیمت فعلی</p>
                        <p className="text-sm font-bold text-blue">
                          ${trade.currentPrice.toFixed(2)}
                        </p>
                      </div>
                      <div className="glass-card p-3 border border-gold/10">
                        <p className="text-xs text-muted mb-1">مقدار</p>
                        <p className="text-sm font-bold text-white">
                          {trade.amount.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* سود/زیان */}
                    <div className={`p-3 rounded-lg ${
                      isProfit 
                        ? 'bg-success/10 border border-success/30' 
                        : 'bg-danger/10 border border-danger/30'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {isProfit ? (
                            <TrendingUp className="text-success" size={20} />
                          ) : (
                            <TrendingDown className="text-danger" size={20} />
                          )}
                          <span className="text-xs text-muted">سود/زیان:</span>
                        </div>
                        <div className="text-left">
                          <p className={`text-lg font-bold ${
                            isProfit ? 'text-success' : 'text-danger'
                          }`}>
                            {isProfit ? '+' : ''}${Math.abs(trade.pnl).toFixed(2)}
                          </p>
                          <p className={`text-xs ${
                            isProfit ? 'text-success' : 'text-danger'
                          }`}>
                            ({isProfit ? '+' : ''}{trade.pnlPercent.toFixed(2)}%)
                          </p>
                        </div>
                      </div>

                      {/* هشدار لیکوییدیشن */}
                      {isHighRisk && (
                        <motion.div 
                          animate={{ opacity: [0.5, 1, 0.5] }}
                          transition={{ repeat: Infinity, duration: 2 }}
                          className="flex items-center gap-2 text-danger text-sm mt-3 pt-3 border-t border-danger/30"
                        >
                          <AlertTriangle className="w-5 h-5" />
                          <div>
                            <p className="font-bold">خطر لیکوییدیشن!</p>
                            <p className="text-xs">
                              قیمت لیکوییدیشن: ${trade.liquidationPrice?.toFixed(2)} 
                              ({liquidationRisk?.toFixed(1)}% فاصله)
                            </p>
                          </div>
                        </motion.div>
                      )}
                    </div>

                    {/* اطلاعات اضافی */}
                    {(trade.stopLoss || trade.takeProfit) && (
                      <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-gold/10">
                        {trade.stopLoss && (
                          <div className="flex items-center gap-2 text-xs">
                            <div className="w-2 h-2 rounded-full bg-danger" />
                            <span className="text-muted">حد ضرر:</span>
                            <span className="font-bold text-danger">
                              ${trade.stopLoss.toFixed(2)}
                            </span>
                          </div>
                        )}
                        {trade.takeProfit && (
                          <div className="flex items-center gap-2 text-xs">
                            <div className="w-2 h-2 rounded-full bg-success" />
                            <span className="text-muted">حد سود:</span>
                            <span className="font-bold text-success">
                              ${trade.takeProfit.toFixed(2)}
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* معاملات بسته شده اخیر */}
      {closedTrades.length > 0 && (
        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-xl font-bold gradient-text flex items-center gap-2">
              <CheckCircle2 size={24} />
              تاریخچه معاملات
            </h4>
            <div className="px-3 py-1 rounded-full bg-blue/20 text-blue font-bold text-sm">
              {closedTrades.length} معامله
            </div>
          </div>

          <div className="space-y-2 max-h-96 overflow-y-auto custom-scrollbar">
            {closedTrades.slice(-10).reverse().map((trade, index) => {
              const isProfit = trade.pnl >= 0;
              return (
                <motion.div
                  key={trade.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                  whileHover={{ scale: 1.01, x: 4 }}
                  className={`glass-card p-3 border ${
                    isProfit ? 'border-success/20' : 'border-danger/20'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        isProfit ? 'bg-success/20' : 'bg-danger/20'
                      }`}>
                        {isProfit ? (
                          <TrendingUp className="text-success" size={20} />
                        ) : (
                          <TrendingDown className="text-danger" size={20} />
                        )}
                      </div>
                      <div>
                        <p className="font-bold text-white">{trade.assetName}</p>
                        <div className="flex items-center gap-2 text-xs text-muted mt-1">
                          <Clock size={12} />
                          <span>
                            {new Date(trade.closedAt!).toLocaleDateString('fa-IR')}
                          </span>
                          <span className={`px-2 py-0.5 rounded ${
                            trade.side === 'long'
                              ? 'bg-success/20 text-success'
                              : 'bg-danger/20 text-danger'
                          }`}>
                            {trade.side === 'long' ? 'Long' : 'Short'}
                          </span>
                          {trade.type === 'margin' && (
                            <span className="px-2 py-0.5 rounded bg-gold/20 text-gold">
                              {trade.leverage}x
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className={`text-lg font-bold ${
                        isProfit ? 'text-success' : 'text-danger'
                      }`}>
                        {isProfit ? '+' : ''}${Math.abs(trade.pnl).toFixed(2)}
                      </p>
                      <p className={`text-xs ${
                        isProfit ? 'text-success' : 'text-danger'
                      }`}>
                        {isProfit ? '+' : ''}{trade.pnlPercent.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
