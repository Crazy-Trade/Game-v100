import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNotification } from '../ui/NotificationProvider';
import { useGameStore } from '../../store/gameStore';
import { LEVERAGE_OPTIONS } from '../../constants/assets';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Zap, 
  Target,
  DollarSign,
  Shield,
  TrendingDownIcon as TrailingIcon,
  Link2,
  EyeOff,
  Clock
} from 'lucide-react';
import { OrderType } from '../../types';

export default function TradingPanel() {
  const selectedAsset = useGameStore(state => state.selectedAsset);
  const player = useGameStore(state => state.player);
  const openTrade = useGameStore(state => state.openTrade);
  const placeOrder = useGameStore(state => state.placeOrder);
  const notify = useNotification();

  const [tradeType, setTradeType] = useState<'spot' | 'margin'>('spot');
  const [side, setSide] = useState<'long' | 'short'>('long');
  const [orderType, setOrderType] = useState<OrderType>('market');
  const [amount, setAmount] = useState<number>(1);
  const [leverage, setLeverage] = useState<number>(1);
  const [limitPrice, setLimitPrice] = useState<string>('');
  const [stopLoss, setStopLoss] = useState<string>('');
  const [takeProfit, setTakeProfit] = useState<string>('');
  
  // Advanced order parameters
  const [trailingPercent, setTrailingPercent] = useState<string>('5');
  const [ocoSecondPrice, setOcoSecondPrice] = useState<string>('');
  const [icebergVisible, setIcebergVisible] = useState<string>('');
  const [fokExpiry, setFokExpiry] = useState<string>('60');

  if (!selectedAsset) {
    return (
      <div className="bg-secondary rounded-xl border border-border-primary p-6 shadow-lg">
        <div className="text-center py-8">
          <Target className="w-16 h-16 text-text-tertiary mx-auto mb-4 opacity-50" />
          <p className="text-text-secondary text-lg font-medium">یک دارایی را انتخاب کنید</p>
          <p className="text-text-tertiary text-sm mt-2">برای شروع معاملات</p>
        </div>
      </div>
    );
  }

  const currentPrice = selectedAsset.currentPrice;
  const effectivePrice = orderType === 'market' ? currentPrice : (parseFloat(limitPrice) || currentPrice);
  const totalCost = tradeType === 'spot'
    ? amount * effectivePrice
    : (amount * effectivePrice) / leverage;

  const canTrade = player.cash >= totalCost;

  const handleExecute = () => {
    if (!canTrade) {
      notify.error('موجودی کافی نیست!');
      return;
    }

    if (orderType === 'market') {
      // اجرای فوری
      openTrade({
        assetId: selectedAsset.id,
        assetName: selectedAsset.name,
        type: tradeType,
        side,
        entryPrice: selectedAsset.currentPrice,
        amount,
        leverage: tradeType === 'margin' ? leverage : 1,
        margin: totalCost,
        stopLoss: stopLoss ? parseFloat(stopLoss) : undefined,
        takeProfit: takeProfit ? parseFloat(takeProfit) : undefined,
      });
      notify.success(`معامله ${side === 'long' ? 'خرید' : 'فروش'} ${selectedAsset.name} با موفقیت انجام شد!`);
    } else {
      // ثبت سفارش
      const orderData: any = {
        assetId: selectedAsset.id,
        assetName: selectedAsset.name,
        type: orderType,
        side,
        price: parseFloat(limitPrice) || currentPrice,
        amount,
        leverage: tradeType === 'margin' ? leverage : 1,
        stopLoss: stopLoss ? parseFloat(stopLoss) : undefined,
        takeProfit: takeProfit ? parseFloat(takeProfit) : undefined,
      };

      // Add advanced parameters
      if (orderType === 'trailing-stop' && trailingPercent) {
        orderData.trailingPercent = parseFloat(trailingPercent);
      }
      if (orderType === 'oco' && ocoSecondPrice) {
        orderData.ocoSecondPrice = parseFloat(ocoSecondPrice);
      }
      if (orderType === 'iceberg' && icebergVisible) {
        orderData.icebergVisibleAmount = parseFloat(icebergVisible);
      }
      if (orderType === 'fill-or-kill' && fokExpiry) {
        orderData.fillOrKillExpiry = Date.now() + parseInt(fokExpiry) * 1000;
      }

      placeOrder(orderData);
      notify.success(`سفارش ${getOrderTypeLabel(orderType)} با موفقیت ثبت شد!`);
    }

    // Reset form
    setAmount(1);
    setLimitPrice('');
    setStopLoss('');
    setTakeProfit('');
  };

  const liquidationPrice = tradeType === 'margin'
    ? side === 'long'
      ? selectedAsset.currentPrice * (1 - 1 / leverage)
      : selectedAsset.currentPrice * (1 + 1 / leverage)
    : null;

  const getOrderTypeLabel = (type: OrderType) => {
    const labels: Record<OrderType, string> = {
      'market': 'بازار',
      'limit': 'محدود',
      'stop-loss': 'حد ضرر',
      'take-profit': 'حد سود',
      'trailing-stop': 'حد ضرر دنباله‌دار',
      'oco': 'OCO',
      'iceberg': 'یخ‌چالی',
      'fill-or-kill': 'اجرا یا لغو'
    };
    return labels[type];
  };

  const orderTypes: Array<{ value: OrderType; label: string; icon: any; description: string }> = [
    { value: 'market', label: 'بازار', icon: Zap, description: 'اجرای فوری' },
    { value: 'limit', label: 'محدود', icon: Target, description: 'قیمت مشخص' },
    { value: 'trailing-stop', label: 'Trailing', icon: TrailingIcon, description: 'دنباله‌دار' },
    { value: 'oco', label: 'OCO', icon: Link2, description: 'دو سفارش' },
    { value: 'iceberg', label: 'Iceberg', icon: EyeOff, description: 'مخفی' },
    { value: 'fill-or-kill', label: 'FOK', icon: Clock, description: 'فوری/لغو' },
  ];

  return (
    <div className="bg-secondary rounded-xl border border-border-primary shadow-xl overflow-hidden">
      {/* Header */}
      <div className="bg-elevated border-b border-border-primary p-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center">
            <DollarSign className="w-5 h-5 text-gold" />
          </div>
          <h3 className="font-heading text-xl font-bold text-gold">پنل معاملات</h3>
        </div>
      </div>

      <div className="p-5 space-y-5">
        {/* Trade Type */}
        <div>
          <label className="block text-text-secondary text-sm font-medium mb-2">نوع معامله</label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { value: 'spot', label: 'اسپات (Spot)', desc: 'خرید/فروش واقعی' },
              { value: 'margin', label: 'مارجین (Margin)', desc: 'با اهرم' }
            ].map(({ value, label, desc }) => (
              <motion.button
                key={value}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setTradeType(value as 'spot' | 'margin')}
                className={`p-3 rounded-lg font-medium transition-all duration-normal ${
                  tradeType === value
                    ? 'bg-gold text-bg-primary shadow-gold font-bold'
                    : 'bg-tertiary text-text-secondary hover:bg-elevated border border-border-secondary'
                }`}
              >
                <div className="text-sm">{label}</div>
                <div className="text-xs opacity-70 mt-0.5">{desc}</div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Side */}
        <div>
          <label className="block text-text-secondary text-sm font-medium mb-2">جهت معامله</label>
          <div className="grid grid-cols-2 gap-2">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSide('long')}
              className={`flex items-center justify-center gap-2 py-4 rounded-lg font-bold transition-all duration-normal ${
                side === 'long'
                  ? 'bg-success text-white shadow-lg'
                  : 'bg-tertiary text-text-secondary hover:bg-elevated border border-border-secondary'
              }`}
            >
              <TrendingUp className="w-5 h-5" strokeWidth={3} />
              خرید (Long)
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSide('short')}
              className={`flex items-center justify-center gap-2 py-4 rounded-lg font-bold transition-all duration-normal ${
                side === 'short'
                  ? 'bg-danger text-white shadow-lg'
                  : 'bg-tertiary text-text-secondary hover:bg-elevated border border-border-secondary'
              }`}
            >
              <TrendingDown className="w-5 h-5" strokeWidth={3} />
              فروش (Short)
            </motion.button>
          </div>
        </div>

        {/* Order Type - Advanced */}
        <div>
          <label className="block text-text-secondary text-sm font-medium mb-2">
            نوع سفارش
            <span className="text-xs text-text-tertiary mr-2">(پیشرفته)</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {orderTypes.map(({ value, label, icon: Icon, description }) => (
              <motion.button
                key={value}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setOrderType(value)}
                className={`p-2.5 rounded-lg transition-all duration-normal ${
                  orderType === value
                    ? 'bg-blue text-white shadow-md font-bold'
                    : 'bg-tertiary text-text-tertiary hover:bg-elevated border border-border-secondary'
                }`}
              >
                <Icon className="w-4 h-4 mx-auto mb-1" />
                <div className="text-xs font-semibold">{label}</div>
                <div className="text-[10px] opacity-70 mt-0.5">{description}</div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Leverage (only for margin) */}
        <AnimatePresence>
          {tradeType === 'margin' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-text-secondary text-sm font-medium mb-2">
                اهرم (Leverage)
                <span className="text-warning text-xs mr-2">⚠️ ریسک بالا</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {LEVERAGE_OPTIONS.map(lev => (
                  <motion.button
                    key={lev}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setLeverage(lev)}
                    className={`py-2.5 rounded-lg text-sm font-bold transition-all ${
                      leverage === lev
                        ? lev >= 20 ? 'bg-danger text-white shadow-lg' : 'bg-gold text-bg-primary shadow-gold'
                        : 'bg-tertiary text-text-tertiary hover:bg-elevated border border-border-secondary'
                    }`}
                  >
                    {lev}x
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Limit Price (if not market order) */}
        <AnimatePresence>
          {orderType !== 'market' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-text-secondary text-sm font-medium mb-2">قیمت سفارش</label>
              <input
                type="number"
                value={limitPrice}
                onChange={(e) => setLimitPrice(e.target.value)}
                step="0.01"
                placeholder={`${currentPrice.toFixed(2)}`}
                className="w-full bg-tertiary border border-border-primary rounded-lg px-4 py-3 
                           text-primary font-numbers text-lg transition-all duration-normal
                           focus:outline-none focus:border-gold focus:shadow-gold
                           placeholder:text-text-tertiary"
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Advanced Order Parameters */}
        <AnimatePresence>
          {orderType === 'trailing-stop' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-text-secondary text-sm font-medium mb-2">
                درصد دنباله‌دار (Trailing %)
              </label>
              <input
                type="number"
                value={trailingPercent}
                onChange={(e) => setTrailingPercent(e.target.value)}
                step="0.1"
                min="0.1"
                max="50"
                className="w-full bg-tertiary border border-border-primary rounded-lg px-4 py-3 
                           text-primary font-numbers transition-all
                           focus:outline-none focus:border-blue focus:shadow-md"
              />
              <p className="text-xs text-text-tertiary mt-1">
                حد ضرر به صورت خودکار با قیمت حرکت می‌کند
              </p>
            </motion.div>
          )}

          {orderType === 'oco' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-text-secondary text-sm font-medium mb-2">
                قیمت دوم OCO
              </label>
              <input
                type="number"
                value={ocoSecondPrice}
                onChange={(e) => setOcoSecondPrice(e.target.value)}
                step="0.01"
                placeholder="قیمت سفارش دوم"
                className="w-full bg-tertiary border border-border-primary rounded-lg px-4 py-3 
                           text-primary font-numbers transition-all
                           focus:outline-none focus:border-blue focus:shadow-md"
              />
              <p className="text-xs text-text-tertiary mt-1">
                اجرای یک سفارش، دیگری را لغو می‌کند
              </p>
            </motion.div>
          )}

          {orderType === 'iceberg' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-text-secondary text-sm font-medium mb-2">
                مقدار قابل مشاهده
              </label>
              <input
                type="number"
                value={icebergVisible}
                onChange={(e) => setIcebergVisible(e.target.value)}
                step="0.1"
                placeholder={`کمتر از ${amount}`}
                className="w-full bg-tertiary border border-border-primary rounded-lg px-4 py-3 
                           text-primary font-numbers transition-all
                           focus:outline-none focus:border-blue focus:shadow-md"
              />
              <p className="text-xs text-text-tertiary mt-1">
                فقط بخشی از سفارش نمایش داده می‌شود
              </p>
            </motion.div>
          )}

          {orderType === 'fill-or-kill' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-text-secondary text-sm font-medium mb-2">
                زمان انقضا (ثانیه)
              </label>
              <input
                type="number"
                value={fokExpiry}
                onChange={(e) => setFokExpiry(e.target.value)}
                step="10"
                min="10"
                max="300"
                className="w-full bg-tertiary border border-border-primary rounded-lg px-4 py-3 
                           text-primary font-numbers transition-all
                           focus:outline-none focus:border-blue focus:shadow-md"
              />
              <p className="text-xs text-text-tertiary mt-1">
                اگر در این مدت اجرا نشود، لغو می‌شود
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Amount */}
        <div>
          <label className="block text-text-secondary text-sm font-medium mb-2">مقدار</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(Math.max(0.01, parseFloat(e.target.value) || 0))}
            step="0.01"
            min="0.01"
            className="w-full bg-tertiary border border-border-primary rounded-lg px-4 py-3 
                       text-primary font-numbers text-lg font-bold transition-all duration-normal
                       focus:outline-none focus:border-gold focus:shadow-gold"
          />
        </div>

        {/* Stop Loss & Take Profit */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-text-tertiary text-xs font-medium mb-2 flex items-center gap-1">
              <Shield className="w-3 h-3 text-danger" />
              حد ضرر (اختیاری)
            </label>
            <input
              type="number"
              value={stopLoss}
              onChange={(e) => setStopLoss(e.target.value)}
              step="0.01"
              placeholder={`< ${currentPrice.toFixed(2)}`}
              className="w-full bg-tertiary border border-border-primary rounded-lg px-3 py-2.5 
                         text-primary font-numbers text-sm transition-all
                         focus:outline-none focus:border-danger focus:shadow-md
                         placeholder:text-text-tertiary"
            />
          </div>
          <div>
            <label className="block text-text-tertiary text-xs font-medium mb-2 flex items-center gap-1">
              <Target className="w-3 h-3 text-success" />
              حد سود (اختیاری)
            </label>
            <input
              type="number"
              value={takeProfit}
              onChange={(e) => setTakeProfit(e.target.value)}
              step="0.01"
              placeholder={`> ${currentPrice.toFixed(2)}`}
              className="w-full bg-tertiary border border-border-primary rounded-lg px-3 py-2.5 
                         text-primary font-numbers text-sm transition-all
                         focus:outline-none focus:border-success focus:shadow-md
                         placeholder:text-text-tertiary"
            />
          </div>
        </div>

        {/* Summary */}
        <div className="bg-elevated rounded-xl p-4 space-y-2.5 border border-border-secondary">
          <div className="flex justify-between text-sm">
            <span className="text-text-tertiary">قیمت {orderType === 'market' ? 'فعلی' : 'سفارش'}</span>
            <span className="text-primary font-numbers font-bold">
              ${effectivePrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-text-tertiary">هزینه کل</span>
            <span className="text-gold font-numbers font-bold">
              ${totalCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          {liquidationPrice && (
            <div className="flex justify-between text-sm pt-2 border-t border-border-secondary">
              <span className="text-text-tertiary flex items-center gap-1">
                <AlertTriangle className="w-4 h-4 text-danger" />
                قیمت لیکوییدیشن
              </span>
              <span className="text-danger font-numbers font-bold">
                ${liquidationPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          )}
          <div className="flex justify-between text-sm pt-2 border-t border-border-secondary">
            <span className="text-text-tertiary">موجودی شما</span>
            <span className={`font-numbers font-bold ${canTrade ? 'text-success' : 'text-danger'}`}>
              ${player.cash.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </div>

        {/* Execute Button */}
        <motion.button
          whileHover={{ scale: canTrade ? 1.02 : 1 }}
          whileTap={{ scale: canTrade ? 0.98 : 1 }}
          onClick={handleExecute}
          disabled={!canTrade}
          className={`w-full py-4 rounded-xl font-heading text-lg font-extrabold 
                     transition-all duration-normal shadow-lg ${
            canTrade
              ? side === 'long'
                ? 'bg-gradient-to-br from-success to-success-dark text-white shadow-success/30 hover:shadow-success/50'
                : 'bg-gradient-to-br from-danger to-danger-dark text-white shadow-danger/30 hover:shadow-danger/50'
              : 'bg-bg-elevated text-text-disabled cursor-not-allowed border border-border-secondary'
          }`}
        >
          {orderType === 'market' 
            ? (side === 'long' ? 'خرید فوری' : 'فروش فوری')
            : `ثبت سفارش ${getOrderTypeLabel(orderType)}`
          }
        </motion.button>
      </div>
    </div>
  );
}
