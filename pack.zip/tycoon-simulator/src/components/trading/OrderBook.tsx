import React, { useMemo } from 'react';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';
import type { OrderBookData, OrderBookLevel } from '../../types';

interface OrderBookProps {
  assetId: string;
  assetSymbol: string;
  currentPrice: number;
}

// تولید Order Book شبیه‌سازی شده
const generateOrderBook = (currentPrice: number): OrderBookData => {
  const spread = currentPrice * 0.002; // 0.2% spread
  const midPrice = currentPrice;
  
  // تولید سطوح bid (خریدها - پایین‌تر از قیمت فعلی)
  const bids: OrderBookLevel[] = [];
  for (let i = 0; i < 10; i++) {
    const price = midPrice - (spread / 2) - (i * spread * 0.5);
    const quantity = Math.random() * 1000 + 100;
    const total = price * quantity;
    bids.push({ price, quantity, total });
  }
  
  // تولید سطوح ask (فروش‌ها - بالاتر از قیمت فعلی)
  const asks: OrderBookLevel[] = [];
  for (let i = 0; i < 10; i++) {
    const price = midPrice + (spread / 2) + (i * spread * 0.5);
    const quantity = Math.random() * 1000 + 100;
    const total = price * quantity;
    asks.push({ price, quantity, total });
  }
  
  const spreadValue = asks[0].price - bids[0].price;
  const spreadPercent = (spreadValue / midPrice) * 100;
  
  return {
    bids,
    asks,
    spread: spreadValue,
    spreadPercent,
    lastPrice: currentPrice
  };
};

export const OrderBook: React.FC<OrderBookProps> = ({ assetId, assetSymbol, currentPrice }) => {
  const orderBook = useMemo(() => generateOrderBook(currentPrice), [currentPrice, assetId]);
  
  const maxBidTotal = Math.max(...orderBook.bids.map(b => b.total));
  const maxAskTotal = Math.max(...orderBook.asks.map(a => a.total));
  const maxTotal = Math.max(maxBidTotal, maxAskTotal);
  
  return (
    <div className="glass-card p-4 space-y-3">
      {/* هدر */}
      <div className="flex items-center justify-between pb-3 border-b border-gold/20">
        <h3 className="text-lg font-bold gradient-text flex items-center gap-2">
          <Activity size={20} />
          دفتر سفارشات
        </h3>
        <div className="text-right">
          <div className="text-xs text-muted">اسپرد</div>
          <div className="text-sm font-bold text-gold">
            {orderBook.spreadPercent.toFixed(3)}%
          </div>
        </div>
      </div>

      {/* هدر جدول */}
      <div className="grid grid-cols-3 gap-2 text-xs text-muted font-bold px-2">
        <div className="text-right">قیمت</div>
        <div className="text-center">مقدار</div>
        <div className="text-left">جمع</div>
      </div>

      {/* سفارشات فروش (Asks) - قرمز */}
      <div className="space-y-1">
        {orderBook.asks.slice(0, 10).reverse().map((ask, index) => {
          const widthPercent = (ask.total / maxTotal) * 100;
          return (
            <div
              key={`ask-${index}`}
              className="relative grid grid-cols-3 gap-2 text-sm py-1 px-2 rounded hover:bg-danger/10 transition-colors cursor-pointer"
            >
              {/* نوار عمق */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-danger/10 rounded"
                style={{ width: `${widthPercent}%` }}
              />
              
              <div className="relative text-right font-mono text-danger font-bold">
                ${ask.price.toFixed(2)}
              </div>
              <div className="relative text-center font-mono text-muted">
                {ask.quantity.toFixed(2)}
              </div>
              <div className="relative text-left font-mono text-xs text-muted">
                ${ask.total.toFixed(0)}
              </div>
            </div>
          );
        })}
      </div>

      {/* قیمت فعلی */}
      <div className="flex items-center justify-center gap-3 py-3 my-2 bg-gradient-to-r from-transparent via-gold/20 to-transparent rounded-lg">
        <TrendingUp className="text-success" size={16} />
        <div className="text-center">
          <div className="text-xs text-muted mb-1">قیمت فعلی</div>
          <div className="text-xl font-bold gradient-text font-mono">
            ${currentPrice.toFixed(2)}
          </div>
        </div>
        <TrendingDown className="text-danger" size={16} />
      </div>

      {/* سفارشات خرید (Bids) - سبز */}
      <div className="space-y-1">
        {orderBook.bids.slice(0, 10).map((bid, index) => {
          const widthPercent = (bid.total / maxTotal) * 100;
          return (
            <div
              key={`bid-${index}`}
              className="relative grid grid-cols-3 gap-2 text-sm py-1 px-2 rounded hover:bg-success/10 transition-colors cursor-pointer"
            >
              {/* نوار عمق */}
              <div
                className="absolute right-0 top-0 bottom-0 bg-success/10 rounded"
                style={{ width: `${widthPercent}%` }}
              />
              
              <div className="relative text-right font-mono text-success font-bold">
                ${bid.price.toFixed(2)}
              </div>
              <div className="relative text-center font-mono text-muted">
                {bid.quantity.toFixed(2)}
              </div>
              <div className="relative text-left font-mono text-xs text-muted">
                ${bid.total.toFixed(0)}
              </div>
            </div>
          );
        })}
      </div>

      {/* آمار پایین */}
      <div className="pt-3 border-t border-gold/20 grid grid-cols-2 gap-4 text-center">
        <div>
          <div className="text-xs text-muted mb-1">حجم خرید</div>
          <div className="text-sm font-bold text-success">
            ${orderBook.bids.reduce((sum, b) => sum + b.total, 0).toLocaleString()}
          </div>
        </div>
        <div>
          <div className="text-xs text-muted mb-1">حجم فروش</div>
          <div className="text-sm font-bold text-danger">
            ${orderBook.asks.reduce((sum, a) => sum + a.total, 0).toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
};
