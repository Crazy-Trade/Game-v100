import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../../store/gameStore';
import { 
  TrendingUp, 
  TrendingDown,
  Activity,
  Brain,
  Target,
  AlertCircle,
  CheckCircle,
  MinusCircle,
  BarChart3,
  Smile,
  Frown,
  Meh
} from 'lucide-react';
import {
  calculateRSI,
  calculateSMA,
  calculateEMA,
  calculateMACD,
  calculateBollingerBands,
  analyzeTechnicalSignals,
  calculateFearGreedIndex
} from '../../lib/indicators';

type TabType = 'technical' | 'sentiment' | 'signals';

export default function FinancialAnalyzer() {
  const selectedAsset = useGameStore(state => state.selectedAsset);
  const [activeTab, setActiveTab] = useState<TabType>('technical');

  if (!selectedAsset) {
    return (
      <div className="bg-secondary rounded-xl border border-border-primary p-8 text-center">
        <Brain className="w-16 h-16 text-text-tertiary mx-auto mb-4 opacity-50" />
        <p className="text-text-secondary text-lg">یک دارایی را انتخاب کنید</p>
        <p className="text-text-tertiary text-sm mt-2">برای مشاهده تحلیل مالی کامل</p>
      </div>
    );
  }

  const prices = selectedAsset.priceHistory.map(p => p.close);
  const currentPrice = selectedAsset.currentPrice;

  // Calculate all indicators
  const rsi = calculateRSI(prices);
  const sma20 = calculateSMA(prices, 20);
  const sma50 = calculateSMA(prices, 50);
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const macd = calculateMACD(prices);
  const bb = calculateBollingerBands(prices);
  const technicalSignals = analyzeTechnicalSignals(selectedAsset);
  const fearGreedIndex = calculateFearGreedIndex(selectedAsset);

  const tabs = [
    { id: 'technical', label: 'تحلیل تکنیکال', icon: BarChart3 },
    { id: 'sentiment', label: 'سنتیمنت بازار', icon: Brain },
    { id: 'signals', label: 'سیگنال‌های معاملاتی', icon: Target }
  ];

  const getSignalIcon = (signal: 'buy' | 'sell' | 'hold') => {
    if (signal === 'buy') return <CheckCircle className="w-5 h-5 text-success" />;
    if (signal === 'sell') return <AlertCircle className="w-5 h-5 text-danger" />;
    return <MinusCircle className="w-5 h-5 text-warning" />;
  };

  const getSignalColor = (signal: 'buy' | 'sell' | 'hold') => {
    if (signal === 'buy') return 'text-success';
    if (signal === 'sell') return 'text-danger';
    return 'text-warning';
  };

  const getSignalBg = (signal: 'buy' | 'sell' | 'hold') => {
    if (signal === 'buy') return 'bg-success/10 border-success/30';
    if (signal === 'sell') return 'bg-danger/10 border-danger/30';
    return 'bg-warning/10 border-warning/30';
  };

  const getFearGreedLabel = (index: number) => {
    if (index < 25) return 'ترس شدید';
    if (index < 45) return 'ترس';
    if (index < 55) return 'خنثی';
    if (index < 75) return 'طمع';
    return 'طمع شدید';
  };

  const getFearGreedColor = (index: number) => {
    if (index < 25) return 'text-danger';
    if (index < 45) return 'text-warning';
    if (index < 55) return 'text-text-secondary';
    if (index < 75) return 'text-blue';
    return 'text-success';
  };

  const getFearGreedIcon = (index: number) => {
    if (index < 45) return <Frown className="w-6 h-6" />;
    if (index < 55) return <Meh className="w-6 h-6" />;
    return <Smile className="w-6 h-6" />;
  };

  return (
    <div className="bg-secondary rounded-xl border border-border-primary shadow-xl overflow-hidden">
      {/* Header */}
      <div className="bg-elevated border-b border-border-primary p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-blue/10 flex items-center justify-center">
            <Brain className="w-5 h-5 text-blue" />
          </div>
          <div>
            <h3 className="font-heading text-xl font-bold text-blue">آنالیزور مالی هوشمند</h3>
            <p className="text-text-tertiary text-xs mt-0.5">تحلیل جامع {selectedAsset.name}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2">
          {tabs.map(({ id, label, icon: Icon }) => (
            <motion.button
              key={id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab(id as TabType)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg transition-all duration-normal ${
                activeTab === id
                  ? 'bg-blue text-white shadow-md font-bold'
                  : 'bg-tertiary text-text-tertiary hover:bg-elevated hover:text-primary border border-border-secondary'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-sm">{label}</span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        <AnimatePresence mode="wait">
          {activeTab === 'technical' && (
            <motion.div
              key="technical"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              {/* RSI */}
              <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-gold" />
                    <h4 className="font-bold text-primary">RSI (شاخص قدرت نسبی)</h4>
                  </div>
                  {rsi !== null && (
                    <span className={`font-numbers text-2xl font-bold ${
                      rsi < 30 ? 'text-success' : rsi > 70 ? 'text-danger' : 'text-text-secondary'
                    }`}>
                      {rsi.toFixed(1)}
                    </span>
                  )}
                </div>
                {rsi !== null && (
                  <>
                    <div className="w-full bg-bg-elevated rounded-full h-3 mb-2">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${rsi}%` }}
                        className={`h-3 rounded-full ${
                          rsi < 30 ? 'bg-success' : rsi > 70 ? 'bg-danger' : 'bg-blue'
                        }`}
                      />
                    </div>
                    <div className="flex justify-between text-xs text-text-tertiary">
                      <span>اشباع فروش (&lt;30)</span>
                      <span>خنثی (30-70)</span>
                      <span>اشباع خرید (&gt;70)</span>
                    </div>
                    <p className="text-sm text-text-secondary mt-2">
                      {rsi < 30 && '💡 سیگنال خرید: بازار در ناحیه اشباع فروش'}
                      {rsi > 70 && '⚠️ سیگنال فروش: بازار در ناحیه اشباع خرید'}
                      {rsi >= 30 && rsi <= 70 && 'بازار در وضعیت خنثی'}
                    </p>
                  </>
                )}
              </div>

              {/* Moving Averages */}
              <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                <h4 className="font-bold text-primary mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-gold" />
                  میانگین‌های متحرک
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'SMA 20', value: sma20, color: 'text-gold' },
                    { label: 'SMA 50', value: sma50, color: 'text-blue' },
                    { label: 'EMA 12', value: ema12, color: 'text-success' },
                    { label: 'EMA 26', value: ema26, color: 'text-warning' }
                  ].map(({ label, value, color }) => (
                    <div key={label} className="bg-bg-elevated rounded-lg p-3">
                      <p className="text-xs text-text-tertiary mb-1">{label}</p>
                      <p className={`font-numbers text-lg font-bold ${color}`}>
                        {value !== null ? `$${value.toFixed(2)}` : 'N/A'}
                      </p>
                      {value !== null && (
                        <p className="text-xs mt-1">
                          {currentPrice > value ? (
                            <span className="text-success">↑ بالای میانگین</span>
                          ) : (
                            <span className="text-danger">↓ پایین میانگین</span>
                          )}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* MACD */}
              {macd.macd !== null && macd.signal !== null && (
                <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                  <h4 className="font-bold text-primary mb-3 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-gold" />
                    MACD
                  </h4>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-bg-elevated rounded-lg p-3">
                      <p className="text-xs text-text-tertiary mb-1">MACD</p>
                      <p className={`font-numbers text-lg font-bold ${
                        macd.macd > 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {macd.macd.toFixed(2)}
                      </p>
                    </div>
                    <div className="bg-bg-elevated rounded-lg p-3">
                      <p className="text-xs text-text-tertiary mb-1">Signal</p>
                      <p className="font-numbers text-lg font-bold text-blue">
                        {macd.signal.toFixed(2)}
                      </p>
                    </div>
                    <div className="bg-bg-elevated rounded-lg p-3">
                      <p className="text-xs text-text-tertiary mb-1">Histogram</p>
                      <p className={`font-numbers text-lg font-bold ${
                        (macd.histogram || 0) > 0 ? 'text-success' : 'text-danger'
                      }`}>
                        {(macd.histogram || 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Bollinger Bands */}
              {bb.middle !== null && (
                <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                  <h4 className="font-bold text-primary mb-3">نوارهای بولینگر</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-text-tertiary">باند بالا</span>
                      <span className="font-numbers font-bold text-warning">
                        ${bb.upper?.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-text-tertiary">میانه (SMA 20)</span>
                      <span className="font-numbers font-bold text-gold">
                        ${bb.middle.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-text-tertiary">باند پایین</span>
                      <span className="font-numbers font-bold text-blue">
                        ${bb.lower?.toFixed(2)}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-border-secondary">
                      <p className="text-xs text-text-secondary">
                        قیمت فعلی: 
                        {bb.lower && currentPrice < bb.lower && ' 🔥 زیر باند پایین (فرصت خرید)'}
                        {bb.upper && currentPrice > bb.upper && ' ⚠️ بالای باند بالا (احتمال بازگشت)'}
                        {bb.lower && bb.upper && currentPrice >= bb.lower && currentPrice <= bb.upper && ' در محدوده نرمال'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'sentiment' && (
            <motion.div
              key="sentiment"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              {/* Fear & Greed Index */}
              <div className="bg-gradient-to-br from-tertiary to-bg-elevated rounded-xl p-6 border border-border-secondary">
                <div className="text-center mb-6">
                  <h4 className="font-heading text-xl font-bold text-primary mb-2">
                    شاخص ترس و طمع
                  </h4>
                  <p className="text-text-tertiary text-sm">تحلیل احساسات بازار</p>
                </div>

                <div className="relative mb-6">
                  <div className="w-full h-4 bg-gradient-to-r from-danger via-warning via-text-secondary via-blue to-success rounded-full" />
                  <motion.div
                    initial={{ left: '50%' }}
                    animate={{ left: `${fearGreedIndex}%` }}
                    className="absolute -top-2 w-0.5 h-8 bg-white shadow-lg"
                    style={{ transform: 'translateX(-50%)' }}
                  >
                    <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 
                                    bg-white text-bg-primary px-3 py-1 rounded-lg font-bold text-sm shadow-xl">
                      {fearGreedIndex.toFixed(0)}
                    </div>
                  </motion.div>
                </div>

                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className={getFearGreedColor(fearGreedIndex)}>
                    {getFearGreedIcon(fearGreedIndex)}
                  </div>
                  <span className={`text-2xl font-heading font-extrabold ${getFearGreedColor(fearGreedIndex)}`}>
                    {getFearGreedLabel(fearGreedIndex)}
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-2 text-center text-xs">
                  <div className={fearGreedIndex < 25 ? 'text-danger font-bold' : 'text-text-tertiary'}>
                    ترس شدید<br/>(0-25)
                  </div>
                  <div className={fearGreedIndex >= 25 && fearGreedIndex < 45 ? 'text-warning font-bold' : 'text-text-tertiary'}>
                    ترس<br/>(25-45)
                  </div>
                  <div className={fearGreedIndex >= 45 && fearGreedIndex < 55 ? 'text-primary font-bold' : 'text-text-tertiary'}>
                    خنثی<br/>(45-55)
                  </div>
                  <div className={fearGreedIndex >= 55 && fearGreedIndex < 75 ? 'text-blue font-bold' : 'text-text-tertiary'}>
                    طمع<br/>(55-75)
                  </div>
                  <div className={fearGreedIndex >= 75 ? 'text-success font-bold' : 'text-text-tertiary'}>
                    طمع شدید<br/>(75-100)
                  </div>
                </div>
              </div>

              {/* Volatility & Liquidity */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                  <h4 className="font-bold text-primary mb-3">نوسان (Volatility)</h4>
                  <div className="text-center mb-3">
                    <span className={`text-4xl font-numbers font-extrabold ${
                      selectedAsset.volatility > 2 ? 'text-danger' : 
                      selectedAsset.volatility > 1.5 ? 'text-warning' : 'text-success'
                    }`}>
                      {selectedAsset.volatility.toFixed(1)}x
                    </span>
                  </div>
                  <div className="w-full bg-bg-elevated rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        selectedAsset.volatility > 2 ? 'bg-danger' :
                        selectedAsset.volatility > 1.5 ? 'bg-warning' : 'bg-success'
                      }`}
                      style={{ width: `${Math.min(100, (selectedAsset.volatility / 3) * 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-text-tertiary mt-2 text-center">
                    {selectedAsset.volatility > 2 && 'نوسان بسیار بالا ⚠️'}
                    {selectedAsset.volatility > 1.5 && selectedAsset.volatility <= 2 && 'نوسان متوسط'}
                    {selectedAsset.volatility <= 1.5 && 'نوسان پایین ✓'}
                  </p>
                </div>

                <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                  <h4 className="font-bold text-primary mb-3">نقدینگی (Liquidity)</h4>
                  <div className="text-center mb-3">
                    <span className={`text-4xl font-numbers font-extrabold ${
                      selectedAsset.liquidity > 1.7 ? 'text-success' : 
                      selectedAsset.liquidity > 1.3 ? 'text-blue' : 'text-warning'
                    }`}>
                      {selectedAsset.liquidity.toFixed(1)}x
                    </span>
                  </div>
                  <div className="w-full bg-bg-elevated rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        selectedAsset.liquidity > 1.7 ? 'bg-success' :
                        selectedAsset.liquidity > 1.3 ? 'bg-blue' : 'bg-warning'
                      }`}
                      style={{ width: `${(selectedAsset.liquidity / 2) * 100}%` }}
                    />
                  </div>
                  <p className="text-xs text-text-tertiary mt-2 text-center">
                    {selectedAsset.liquidity > 1.7 && 'نقدینگی عالی ✓'}
                    {selectedAsset.liquidity > 1.3 && selectedAsset.liquidity <= 1.7 && 'نقدینگی خوب'}
                    {selectedAsset.liquidity <= 1.3 && 'نقدینگی پایین'}
                  </p>
                </div>
              </div>

              {/* Sentiment Score */}
              {selectedAsset.sentiment !== undefined && (
                <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                  <h4 className="font-bold text-primary mb-3">سنتیمنت بازار</h4>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="w-full bg-bg-elevated rounded-full h-3">
                        <div
                          className={`h-3 rounded-full ${
                            selectedAsset.sentiment > 0.3 ? 'bg-success' :
                            selectedAsset.sentiment < -0.3 ? 'bg-danger' : 'bg-warning'
                          }`}
                          style={{ width: `${((selectedAsset.sentiment + 1) / 2) * 100}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-text-tertiary mt-1">
                        <span>منفی</span>
                        <span>خنثی</span>
                        <span>مثبت</span>
                      </div>
                    </div>
                    <span className={`text-2xl font-bold ${
                      selectedAsset.sentiment > 0.3 ? 'text-success' :
                      selectedAsset.sentiment < -0.3 ? 'text-danger' : 'text-warning'
                    }`}>
                      {selectedAsset.sentiment > 0 ? '+' : ''}{(selectedAsset.sentiment * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'signals' && (
            <motion.div
              key="signals"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              {/* Main Signal */}
              <div className={`rounded-xl p-6 border-2 ${getSignalBg(technicalSignals.signal)}`}>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {getSignalIcon(technicalSignals.signal)}
                    <div>
                      <h4 className="font-heading text-2xl font-extrabold text-primary">
                        {technicalSignals.signal === 'buy' && 'سیگنال خرید'}
                        {technicalSignals.signal === 'sell' && 'سیگنال فروش'}
                        {technicalSignals.signal === 'hold' && 'نگهداری موقعیت'}
                      </h4>
                      <p className="text-sm text-text-tertiary mt-1">
                        قدرت سیگنال: {technicalSignals.strength.toFixed(0)}%
                      </p>
                    </div>
                  </div>
                  <div className={`text-5xl font-extrabold ${getSignalColor(technicalSignals.signal)}`}>
                    {technicalSignals.signal === 'buy' && '↑'}
                    {technicalSignals.signal === 'sell' && '↓'}
                    {technicalSignals.signal === 'hold' && '→'}
                  </div>
                </div>
                
                <div className="w-full bg-bg-elevated rounded-full h-3 mb-4">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${technicalSignals.strength}%` }}
                    className={`h-3 rounded-full ${
                      technicalSignals.signal === 'buy' ? 'bg-success' :
                      technicalSignals.signal === 'sell' ? 'bg-danger' : 'bg-warning'
                    }`}
                  />
                </div>

                <p className={`text-sm font-medium ${getSignalColor(technicalSignals.signal)}`}>
                  {technicalSignals.signal === 'buy' && '💡 توصیه: این دارایی فرصت خرید مناسبی دارد.'}
                  {technicalSignals.signal === 'sell' && '⚠️ توصیه: در نظر گرفتن فروش یا حد ضرر.'}
                  {technicalSignals.signal === 'hold' && '📊 توصیه: نگهداری و صبر برای سیگنال واضح‌تر.'}
                </p>
              </div>

              {/* Reasons */}
              <div className="bg-tertiary rounded-xl p-4 border border-border-secondary">
                <h4 className="font-bold text-primary mb-3 flex items-center gap-2">
                  <Target className="w-4 h-4 text-gold" />
                  دلایل سیگنال
                </h4>
                <div className="space-y-2">
                  {technicalSignals.reasons.map((reason, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-start gap-2 text-sm bg-bg-elevated rounded-lg p-3"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-gold mt-1.5 flex-shrink-0" />
                      <span className="text-text-secondary">{reason}</span>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Warning */}
              <div className="bg-warning/10 border border-warning/30 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-warning">
                    <p className="font-bold mb-1">⚠️ هشدار مهم</p>
                    <p className="text-xs opacity-90">
                      این تحلیل فقط بر اساس داده‌های تکنیکال است و نباید به تنهایی برای تصمیم‌گیری استفاده شود.
                      همیشه تحقیقات بیشتر انجام دهید و مدیریت ریسک را رعایت کنید.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
