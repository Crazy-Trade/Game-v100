// محاسبات اندیکاتورهای تکنیکال
import { Asset } from '../types';

// میانگین متحرک ساده (SMA)
export function calculateSMA(prices: number[], period: number): number | null {
  if (prices.length < period) return null;
  const sum = prices.slice(-period).reduce((a, b) => a + b, 0);
  return sum / period;
}

// میانگین متحرک نمایی (EMA)
export function calculateEMA(prices: number[], period: number): number | null {
  if (prices.length < period) return null;
  
  const k = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  
  for (let i = period; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
  }
  
  return ema;
}

// شاخص قدرت نسبی (RSI)
export function calculateRSI(prices: number[], period: number = 14): number | null {
  if (prices.length < period + 1) return null;
  
  const changes = prices.slice(1).map((price, i) => price - prices[i]);
  const gains = changes.map(c => c > 0 ? c : 0);
  const losses = changes.map(c => c < 0 ? -c : 0);
  
  const recentGains = gains.slice(-period);
  const recentLosses = losses.slice(-period);
  
  const avgGain = recentGains.reduce((a, b) => a + b, 0) / period;
  const avgLoss = recentLosses.reduce((a, b) => a + b, 0) / period;
  
  if (avgLoss === 0) return 100;
  
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  
  return rsi;
}

// MACD
export interface MACDResult {
  macd: number | null;
  signal: number | null;
  histogram: number | null;
}

export function calculateMACD(prices: number[]): MACDResult {
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  
  if (ema12 === null || ema26 === null) {
    return { macd: null, signal: null, histogram: null };
  }
  
  const macd = ema12 - ema26;
  
  // برای محاسبه signal، نیاز به تاریخچه MACD داریم
  // ساده‌سازی: از EMA(9) روی قیمت فعلی استفاده می‌کنیم
  const signal = calculateEMA(prices, 9);
  const histogram = signal !== null ? macd - signal : null;
  
  return { macd, signal, histogram };
}

// Bollinger Bands
export interface BollingerBandsResult {
  upper: number | null;
  middle: number | null;
  lower: number | null;
}

export function calculateBollingerBands(
  prices: number[], 
  period: number = 20, 
  stdDev: number = 2
): BollingerBandsResult {
  const sma = calculateSMA(prices, period);
  
  if (sma === null) {
    return { upper: null, middle: null, lower: null };
  }
  
  const recentPrices = prices.slice(-period);
  const variance = recentPrices.reduce((sum, price) => {
    return sum + Math.pow(price - sma, 2);
  }, 0) / period;
  
  const std = Math.sqrt(variance);
  
  return {
    upper: sma + (stdDev * std),
    middle: sma,
    lower: sma - (stdDev * std)
  };
}

// محاسبه سیگنال خرید/فروش بر اساس اندیکاتورها
export interface TechnicalSignal {
  signal: 'buy' | 'sell' | 'hold';
  strength: number; // 0-100
  reasons: string[];
}

export function analyzeTechnicalSignals(asset: Asset): TechnicalSignal {
  const prices = asset.priceHistory.map(p => p.close);
  const currentPrice = asset.currentPrice;
  
  const signals: Array<{ signal: 'buy' | 'sell' | 'hold'; weight: number; reason: string }> = [];
  
  // RSI Analysis
  const rsi = calculateRSI(prices);
  if (rsi !== null) {
    if (rsi < 30) {
      signals.push({ signal: 'buy', weight: 25, reason: `RSI در ناحیه اشباع فروش (${rsi.toFixed(1)})` });
    } else if (rsi > 70) {
      signals.push({ signal: 'sell', weight: 25, reason: `RSI در ناحیه اشباع خرید (${rsi.toFixed(1)})` });
    } else {
      signals.push({ signal: 'hold', weight: 10, reason: `RSI خنثی (${rsi.toFixed(1)})` });
    }
  }
  
  // Moving Average Crossover
  const sma20 = calculateSMA(prices, 20);
  const sma50 = calculateSMA(prices, 50);
  if (sma20 !== null && sma50 !== null) {
    if (currentPrice > sma20 && sma20 > sma50) {
      signals.push({ signal: 'buy', weight: 20, reason: 'روند صعودی (قیمت بالای MA20 و MA50)' });
    } else if (currentPrice < sma20 && sma20 < sma50) {
      signals.push({ signal: 'sell', weight: 20, reason: 'روند نزولی (قیمت پایین MA20 و MA50)' });
    }
  }
  
  // MACD Analysis
  const macd = calculateMACD(prices);
  if (macd.macd !== null && macd.signal !== null) {
    if (macd.macd > macd.signal && macd.histogram !== null && macd.histogram > 0) {
      signals.push({ signal: 'buy', weight: 20, reason: 'MACD مثبت و بالای خط سیگنال' });
    } else if (macd.macd < macd.signal && macd.histogram !== null && macd.histogram < 0) {
      signals.push({ signal: 'sell', weight: 20, reason: 'MACD منفی و پایین خط سیگنال' });
    }
  }
  
  // Bollinger Bands
  const bb = calculateBollingerBands(prices);
  if (bb.lower !== null && bb.upper !== null) {
    if (currentPrice < bb.lower) {
      signals.push({ signal: 'buy', weight: 15, reason: 'قیمت زیر باند پایین بولینگر' });
    } else if (currentPrice > bb.upper) {
      signals.push({ signal: 'sell', weight: 15, reason: 'قیمت بالای باند بالای بولینگر' });
    }
  }
  
  // Volatility Analysis
  if (asset.volatility > 2.0) {
    signals.push({ signal: 'hold', weight: 10, reason: 'نوسان بسیار بالا - احتیاط' });
  }
  
  // Calculate final signal
  const buyScore = signals.filter(s => s.signal === 'buy').reduce((sum, s) => sum + s.weight, 0);
  const sellScore = signals.filter(s => s.signal === 'sell').reduce((sum, s) => sum + s.weight, 0);
  const holdScore = signals.filter(s => s.signal === 'hold').reduce((sum, s) => sum + s.weight, 0);
  
  const totalScore = buyScore + sellScore + holdScore;
  
  let finalSignal: 'buy' | 'sell' | 'hold';
  let strength: number;
  
  if (buyScore > sellScore && buyScore > holdScore) {
    finalSignal = 'buy';
    strength = (buyScore / totalScore) * 100;
  } else if (sellScore > buyScore && sellScore > holdScore) {
    finalSignal = 'sell';
    strength = (sellScore / totalScore) * 100;
  } else {
    finalSignal = 'hold';
    strength = (holdScore / totalScore) * 100;
  }
  
  return {
    signal: finalSignal,
    strength: Math.min(100, strength),
    reasons: signals.map(s => s.reason)
  };
}

// محاسبه Fear & Greed Index (ساده‌شده)
export function calculateFearGreedIndex(asset: Asset): number {
  // محاسبه بر اساس چند فاکتور:
  // 1. تغییرات قیمت اخیر
  // 2. نوسان
  // 3. سنتیمنت (اگر موجود باشد)
  // 4. RSI
  
  let score = 50; // خنثی
  
  // Price change
  const priceChange = asset.changePercent;
  score += priceChange * 2; // +/- 2 point per 1% change
  
  // Volatility (بالا = ترس)
  score -= (asset.volatility - 1) * 10;
  
  // Sentiment
  if (asset.sentiment !== undefined) {
    score += asset.sentiment * 25; // -25 to +25
  }
  
  // RSI
  const prices = asset.priceHistory.map(p => p.close);
  const rsi = calculateRSI(prices);
  if (rsi !== null) {
    if (rsi > 70) score -= 10; // اشباع خرید = طمع
    if (rsi < 30) score += 10; // اشباع فروش = ترس
  }
  
  // Normalize to 0-100
  return Math.max(0, Math.min(100, score));
}
