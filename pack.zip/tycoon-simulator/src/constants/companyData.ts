import type { Upgrade, Milestone } from '../types';

// ارتقاهای اولیه برای تمام بخش‌های شرکت
export const INITIAL_UPGRADES: Upgrade[] = [
  // Supply Chain Upgrades
  {
    id: 'supply_1',
    module: 'supply_chain',
    name: 'بهینه‌سازی انبارداری',
    description: 'کاهش هزینه‌های نگهداری موجودی',
    level: 0,
    maxLevel: 5,
    cost: 50000,
    effects: {
      costReduction: 5,
      qualityBonus: 2
    }
  },
  {
    id: 'supply_2',
    module: 'supply_chain',
    name: 'تأمین‌کنندگان ممتاز',
    description: 'دسترسی به تأمین‌کنندگان باکیفیت‌تر',
    level: 0,
    maxLevel: 3,
    cost: 100000,
    effects: {
      qualityBonus: 10,
      costReduction: -5
    }
  },
  {
    id: 'supply_3',
    module: 'supply_chain',
    name: 'اتوماسیون لجستیک',
    description: 'سرعت بخشیدن به فرآیند توزیع',
    level: 0,
    maxLevel: 4,
    cost: 150000,
    effects: {
      speedBonus: 15,
      costReduction: 8
    }
  },

  // R&D Upgrades
  {
    id: 'rd_1',
    module: 'rd',
    name: 'آزمایشگاه پیشرفته',
    description: 'تسریع پروژه‌های تحقیقاتی',
    level: 0,
    maxLevel: 5,
    cost: 200000,
    effects: {
      techBonus: 20,
      speedBonus: 10
    }
  },
  {
    id: 'rd_2',
    module: 'rd',
    name: 'استخدام محققین حرفه‌ای',
    description: 'افزایش کیفیت تحقیقات',
    level: 0,
    maxLevel: 4,
    cost: 250000,
    effects: {
      techBonus: 25,
      qualityBonus: 15
    }
  },
  {
    id: 'rd_3',
    module: 'rd',
    name: 'همکاری با دانشگاه‌ها',
    description: 'دسترسی به تحقیقات دانشگاهی',
    level: 0,
    maxLevel: 3,
    cost: 180000,
    effects: {
      techBonus: 15,
      costReduction: 10
    }
  },

  // HR Upgrades
  {
    id: 'hr_1',
    module: 'hr',
    name: 'برنامه‌های رفاهی',
    description: 'بهبود روحیه کارکنان',
    level: 0,
    maxLevel: 5,
    cost: 80000,
    effects: {
      moraleBonus: 10
    }
  },
  {
    id: 'hr_2',
    module: 'hr',
    name: 'دوره‌های آموزشی',
    description: 'افزایش بهره‌وری',
    level: 0,
    maxLevel: 4,
    cost: 120000,
    effects: {
      speedBonus: 12,
      qualityBonus: 8
    }
  },
  {
    id: 'hr_3',
    module: 'hr',
    name: 'سیستم پاداش عملکرد',
    description: 'انگیزش کارکنان برای عملکرد بهتر',
    level: 0,
    maxLevel: 5,
    cost: 100000,
    effects: {
      moraleBonus: 8,
      speedBonus: 10
    }
  },

  // Marketing Upgrades
  {
    id: 'marketing_1',
    module: 'marketing',
    name: 'بازاریابی دیجیتال',
    description: 'افزایش دسترسی آنلاین',
    level: 0,
    maxLevel: 5,
    cost: 150000,
    effects: {
      brandBonus: 15,
      revenueIncrease: 8
    }
  },
  {
    id: 'marketing_2',
    module: 'marketing',
    name: 'تبلیغات تلویزیونی',
    description: 'دسترسی به مخاطبان گسترده',
    level: 0,
    maxLevel: 3,
    cost: 300000,
    effects: {
      brandBonus: 25,
      revenueIncrease: 12
    }
  },
  {
    id: 'marketing_3',
    module: 'marketing',
    name: 'روابط عمومی',
    description: 'بهبود تصویر برند',
    level: 0,
    maxLevel: 4,
    cost: 180000,
    effects: {
      brandBonus: 20,
      influenceBonus: 10
    }
  },

  // Lobbying Upgrades
  {
    id: 'lobby_1',
    module: 'lobbying',
    name: 'روابط دولتی',
    description: 'دسترسی به قراردادهای دولتی',
    level: 0,
    maxLevel: 5,
    cost: 250000,
    effects: {
      influenceBonus: 20,
      revenueIncrease: 10
    }
  },
  {
    id: 'lobby_2',
    module: 'lobbying',
    name: 'شبکه‌سازی بین‌المللی',
    description: 'گسترش به بازارهای جهانی',
    level: 0,
    maxLevel: 4,
    cost: 350000,
    effects: {
      influenceBonus: 25,
      revenueIncrease: 15
    }
  },
  {
    id: 'lobby_3',
    module: 'lobbying',
    name: 'مشاوران حقوقی',
    description: 'کاهش ریسک‌های قانونی',
    level: 0,
    maxLevel: 3,
    cost: 200000,
    effects: {
      influenceBonus: 15,
      costReduction: 5
    }
  }
];

// Milestones اولیه برای رمزارز
export const INITIAL_CRYPTO_MILESTONES: Milestone[] = [
  {
    id: 'milestone_1',
    name: 'انتشار Whitepaper',
    description: 'مستندسازی کامل پروژه و چشم‌انداز',
    status: 'LOCKED',
    progress: 0,
    deadline: 30,
    requirements: {
      funding: 50000,
      developers: 2,
      techLevel: 2
    },
    effects: {
      priceImpact: 5,
      credibilityBonus: 10,
      adoptionIncrease: 5
    }
  },
  {
    id: 'milestone_2',
    name: 'توسعه Testnet',
    description: 'راه‌اندازی شبکه آزمایشی',
    status: 'LOCKED',
    progress: 0,
    deadline: 60,
    requirements: {
      funding: 100000,
      developers: 5,
      techLevel: 3
    },
    effects: {
      priceImpact: 10,
      credibilityBonus: 15,
      adoptionIncrease: 10,
      liquidityBonus: 5
    }
  },
  {
    id: 'milestone_3',
    name: 'قرارداد هوشمند',
    description: 'پیاده‌سازی Smart Contracts',
    status: 'LOCKED',
    progress: 0,
    deadline: 90,
    requirements: {
      funding: 150000,
      developers: 8,
      techLevel: 4
    },
    effects: {
      priceImpact: 15,
      credibilityBonus: 20,
      adoptionIncrease: 15,
      liquidityBonus: 10
    }
  },
  {
    id: 'milestone_4',
    name: 'ممیزی امنیتی',
    description: 'بررسی امنیت توسط شرکت‌های معتبر',
    status: 'LOCKED',
    progress: 0,
    deadline: 120,
    requirements: {
      funding: 200000,
      techLevel: 4
    },
    effects: {
      priceImpact: 20,
      credibilityBonus: 30,
      adoptionIncrease: 20
    }
  },
  {
    id: 'milestone_5',
    name: 'راه‌اندازی Mainnet',
    description: 'شبکه اصلی عملیاتی می‌شود',
    status: 'LOCKED',
    progress: 0,
    deadline: 150,
    requirements: {
      funding: 300000,
      developers: 10,
      marketing: 100000,
      techLevel: 5
    },
    effects: {
      priceImpact: 30,
      credibilityBonus: 40,
      adoptionIncrease: 30,
      liquidityBonus: 20
    }
  },
  {
    id: 'milestone_6',
    name: 'لیست در صرافی‌های بزرگ',
    description: 'پذیرش در صرافی‌های معتبر',
    status: 'LOCKED',
    progress: 0,
    deadline: 180,
    requirements: {
      funding: 500000,
      marketing: 200000
    },
    effects: {
      priceImpact: 40,
      credibilityBonus: 50,
      adoptionIncrease: 40,
      liquidityBonus: 30
    }
  },
  {
    id: 'milestone_7',
    name: 'پذیرش توسط کسب‌وکارها',
    description: 'استفاده واقعی در تجارت',
    status: 'LOCKED',
    progress: 0,
    deadline: 210,
    requirements: {
      marketing: 300000,
      techLevel: 5
    },
    effects: {
      priceImpact: 50,
      credibilityBonus: 60,
      adoptionIncrease: 50,
      liquidityBonus: 40
    }
  },
  {
    id: 'milestone_8',
    name: 'اکوسیستم DeFi',
    description: 'ایجاد پلتفرم مالی غیرمتمرکز',
    status: 'LOCKED',
    progress: 0,
    deadline: 240,
    requirements: {
      funding: 400000,
      developers: 15,
      techLevel: 6
    },
    effects: {
      priceImpact: 60,
      credibilityBonus: 70,
      adoptionIncrease: 60,
      liquidityBonus: 50
    }
  }
];
