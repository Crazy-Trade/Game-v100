import { Asset, AssetCategory } from '../types';

// لیست کامل 88 دارایی - نسخه 2.0
export const INITIAL_ASSETS: Omit<Asset, 'currentPrice' | 'previousPrice' | 'priceHistory' | 'changePercent'>[] = [
  // ========================================
  // سهام (Stocks) - 25 مورد
  // ========================================
  
  // فناوری (Technology)
  { id: 'aapl', name: 'اپل', symbol: 'AAPL', category: 'stock', volatility: 1.2, liquidity: 2.0, marketCap: 2800000000000, peRatio: 28.5, sentiment: 0.7 },
  { id: 'msft', name: 'مایکروسافت', symbol: 'MSFT', category: 'stock', volatility: 1.1, liquidity: 2.0, marketCap: 2500000000000, peRatio: 32.4, sentiment: 0.8 },
  { id: 'googl', name: 'گوگل', symbol: 'GOOGL', category: 'stock', volatility: 1.3, liquidity: 1.9, marketCap: 1700000000000, peRatio: 24.1, sentiment: 0.6 },
  { id: 'meta', name: 'متا', symbol: 'META', category: 'stock', volatility: 1.5, liquidity: 1.8, marketCap: 850000000000, peRatio: 21.3, sentiment: 0.5 },
  { id: 'nvda', name: 'انویدیا', symbol: 'NVDA', category: 'stock', volatility: 1.8, liquidity: 1.9, marketCap: 1200000000000, peRatio: 65.2, sentiment: 0.9 },
  { id: 'amd', name: 'AMD', symbol: 'AMD', category: 'stock', volatility: 1.7, liquidity: 1.7, marketCap: 180000000000, peRatio: 48.7, sentiment: 0.6 },
  { id: 'intc', name: 'اینتل', symbol: 'INTC', category: 'stock', volatility: 1.4, liquidity: 1.8, marketCap: 150000000000, peRatio: 35.2, sentiment: 0.3 },
  { id: 'tsla', name: 'تسلا', symbol: 'TSLA', category: 'stock', volatility: 2.0, liquidity: 1.9, marketCap: 780000000000, peRatio: 72.5, sentiment: 0.7 },
  
  // بانکداری و مالی (Banking & Finance)
  { id: 'jpm', name: 'جی‌پی‌مورگان', symbol: 'JPM', category: 'stock', volatility: 1.0, liquidity: 1.9, marketCap: 450000000000, peRatio: 10.8, sentiment: 0.4 },
  { id: 'bac', name: 'بانک آمریکا', symbol: 'BAC', category: 'stock', volatility: 1.1, liquidity: 1.9, marketCap: 280000000000, peRatio: 9.5, sentiment: 0.3 },
  { id: 'wfc', name: 'ولز فارگو', symbol: 'WFC', category: 'stock', volatility: 1.2, liquidity: 1.7, marketCap: 180000000000, peRatio: 11.2, sentiment: 0.2 },
  { id: 'gs', name: 'گلدمن ساکس', symbol: 'GS', category: 'stock', volatility: 1.3, liquidity: 1.6, marketCap: 125000000000, peRatio: 12.7, sentiment: 0.5 },
  { id: 'ms', name: 'مورگان استنلی', symbol: 'MS', category: 'stock', volatility: 1.2, liquidity: 1.6, marketCap: 145000000000, peRatio: 13.4, sentiment: 0.4 },
  
  // دارویی و بهداشت (Pharmaceutical & Healthcare)
  { id: 'pfe', name: 'فایزر', symbol: 'PFE', category: 'stock', volatility: 0.9, liquidity: 1.8, marketCap: 160000000000, peRatio: 15.6, sentiment: 0.3 },
  { id: 'jnj', name: 'جانسون اند جانسون', symbol: 'JNJ', category: 'stock', volatility: 0.8, liquidity: 1.9, marketCap: 380000000000, peRatio: 18.2, sentiment: 0.6 },
  { id: 'mrna', name: 'مدرنا', symbol: 'MRNA', category: 'stock', volatility: 2.2, liquidity: 1.5, marketCap: 45000000000, peRatio: 8.3, sentiment: 0.4 },
  { id: 'abbv', name: 'ابی‌وی', symbol: 'ABBV', category: 'stock', volatility: 1.0, liquidity: 1.7, marketCap: 270000000000, peRatio: 16.8, sentiment: 0.5 },
  
  // انرژی (Energy)
  { id: 'xom', name: 'اکسون‌موبیل', symbol: 'XOM', category: 'stock', volatility: 1.3, liquidity: 1.9, marketCap: 420000000000, peRatio: 9.7, sentiment: 0.2 },
  { id: 'cvx', name: 'شورون', symbol: 'CVX', category: 'stock', volatility: 1.2, liquidity: 1.8, marketCap: 290000000000, peRatio: 10.3, sentiment: 0.3 },
  { id: 'cop', name: 'کونوکوفیلیپس', symbol: 'COP', category: 'stock', volatility: 1.4, liquidity: 1.6, marketCap: 135000000000, peRatio: 11.5, sentiment: 0.4 },
  
  // خرده‌فروشی (Retail)
  { id: 'amzn', name: 'آمازون', symbol: 'AMZN', category: 'stock', volatility: 1.4, liquidity: 2.0, marketCap: 1600000000000, peRatio: 68.3, sentiment: 0.7 },
  { id: 'wmt', name: 'والمارت', symbol: 'WMT', category: 'stock', volatility: 0.9, liquidity: 1.8, marketCap: 420000000000, peRatio: 25.1, sentiment: 0.5 },
  { id: 'cost', name: 'کاستکو', symbol: 'COST', category: 'stock', volatility: 1.0, liquidity: 1.7, marketCap: 310000000000, peRatio: 38.6, sentiment: 0.6 },
  
  // صنعتی و خودرو (Industrial & Auto)
  { id: 'ge', name: 'جنرال الکتریک', symbol: 'GE', category: 'stock', volatility: 1.5, liquidity: 1.7, marketCap: 125000000000, peRatio: 22.4, sentiment: 0.4 },
  { id: 'f', name: 'فورد', symbol: 'F', category: 'stock', volatility: 1.6, liquidity: 1.8, marketCap: 48000000000, peRatio: 6.8, sentiment: 0.3 },
  
  // ========================================
  // کالاها (Commodities) - 18 مورد
  // ========================================
  
  // فلزات گرانبها (Precious Metals)
  { id: 'gold', name: 'طلا', symbol: 'GOLD', category: 'commodity', volatility: 1.0, liquidity: 2.0, volume24h: 180000000000 },
  { id: 'silver', name: 'نقره', symbol: 'SILVER', category: 'commodity', volatility: 1.3, liquidity: 1.8, volume24h: 45000000000 },
  { id: 'plat', name: 'پلاتین', symbol: 'PLAT', category: 'commodity', volatility: 1.5, liquidity: 1.4, volume24h: 8000000000 },
  { id: 'pall', name: 'پالادیوم', symbol: 'PALL', category: 'commodity', volatility: 1.7, liquidity: 1.2, volume24h: 4000000000 },
  
  // انرژی (Energy)
  { id: 'oil', name: 'نفت خام', symbol: 'OIL', category: 'commodity', volatility: 1.8, liquidity: 2.0, volume24h: 280000000000 },
  { id: 'brent', name: 'نفت برنت', symbol: 'BRENT', category: 'commodity', volatility: 1.7, liquidity: 1.9, volume24h: 240000000000 },
  { id: 'natgas', name: 'گاز طبیعی', symbol: 'NATGAS', category: 'commodity', volatility: 2.0, liquidity: 1.7, volume24h: 95000000000 },
  { id: 'coal', name: 'زغال سنگ', symbol: 'COAL', category: 'commodity', volatility: 1.6, liquidity: 1.3, volume24h: 12000000000 },
  { id: 'uranium', name: 'اورانیوم', symbol: 'URANIUM', category: 'commodity', volatility: 1.9, liquidity: 1.1, volume24h: 3500000000 },
  
  // فلزات صنعتی (Industrial Metals)
  { id: 'copper', name: 'مس', symbol: 'COPPER', category: 'commodity', volatility: 1.4, liquidity: 1.8, volume24h: 52000000000 },
  { id: 'alum', name: 'آلومینیوم', symbol: 'ALUM', category: 'commodity', volatility: 1.3, liquidity: 1.6, volume24h: 28000000000 },
  { id: 'zinc', name: 'روی', symbol: 'ZINC', category: 'commodity', volatility: 1.5, liquidity: 1.4, volume24h: 15000000000 },
  { id: 'nickel', name: 'نیکل', symbol: 'NICKEL', category: 'commodity', volatility: 1.7, liquidity: 1.3, volume24h: 18000000000 },
  
  // محصولات کشاورزی (Agricultural)
  { id: 'wheat', name: 'گندم', symbol: 'WHEAT', category: 'commodity', volatility: 1.4, liquidity: 1.5, volume24h: 22000000000 },
  { id: 'corn', name: 'ذرت', symbol: 'CORN', category: 'commodity', volatility: 1.3, liquidity: 1.6, volume24h: 28000000000 },
  { id: 'soybean', name: 'سویا', symbol: 'SOYBEAN', category: 'commodity', volatility: 1.4, liquidity: 1.5, volume24h: 25000000000 },
  { id: 'coffee', name: 'قهوه', symbol: 'COFFEE', category: 'commodity', volatility: 1.6, liquidity: 1.3, volume24h: 8500000000 },
  { id: 'sugar', name: 'شکر', symbol: 'SUGAR', category: 'commodity', volatility: 1.5, liquidity: 1.4, volume24h: 12000000000 },
  
  // ========================================
  // ارزها (Currencies/Forex) - 20 مورد
  // ========================================
  
  // ارزهای اصلی (Major Currencies)
  { id: 'usd', name: 'دلار آمریکا', symbol: 'USD', category: 'currency', volatility: 0.5, liquidity: 2.0, volume24h: 5000000000000 },
  { id: 'eur', name: 'یورو', symbol: 'EUR', category: 'currency', volatility: 0.6, liquidity: 2.0, volume24h: 3500000000000 },
  { id: 'gbp', name: 'پوند بریتانیا', symbol: 'GBP', category: 'currency', volatility: 0.7, liquidity: 1.9, volume24h: 1800000000000 },
  { id: 'jpy', name: 'ین ژاپن', symbol: 'JPY', category: 'currency', volatility: 0.6, liquidity: 2.0, volume24h: 2200000000000 },
  { id: 'chf', name: 'فرانک سوئیس', symbol: 'CHF', category: 'currency', volatility: 0.5, liquidity: 1.8, volume24h: 850000000000 },
  { id: 'cad', name: 'دلار کانادا', symbol: 'CAD', category: 'currency', volatility: 0.7, liquidity: 1.7, volume24h: 720000000000 },
  { id: 'aud', name: 'دلار استرالیا', symbol: 'AUD', category: 'currency', volatility: 0.8, liquidity: 1.7, volume24h: 680000000000 },
  { id: 'nzd', name: 'دلار نیوزیلند', symbol: 'NZD', category: 'currency', volatility: 0.9, liquidity: 1.5, volume24h: 420000000000 },
  
  // ارزهای نوظهور (Emerging Markets)
  { id: 'cny', name: 'یوان چین', symbol: 'CNY', category: 'currency', volatility: 0.6, liquidity: 1.8, volume24h: 950000000000 },
  { id: 'inr', name: 'روپیه هند', symbol: 'INR', category: 'currency', volatility: 0.8, liquidity: 1.6, volume24h: 580000000000 },
  { id: 'brl', name: 'رئال برزیل', symbol: 'BRL', category: 'currency', volatility: 1.1, liquidity: 1.4, volume24h: 320000000000 },
  { id: 'rub', name: 'روبل روسیه', symbol: 'RUB', category: 'currency', volatility: 1.3, liquidity: 1.2, volume24h: 280000000000 },
  { id: 'krw', name: 'وون کره جنوبی', symbol: 'KRW', category: 'currency', volatility: 0.7, liquidity: 1.5, volume24h: 450000000000 },
  { id: 'mxn', name: 'پزوی مکزیک', symbol: 'MXN', category: 'currency', volatility: 1.0, liquidity: 1.4, volume24h: 380000000000 },
  { id: 'zar', name: 'راند آفریقای جنوبی', symbol: 'ZAR', category: 'currency', volatility: 1.2, liquidity: 1.3, volume24h: 290000000000 },
  { id: 'try', name: 'لیر ترکیه', symbol: 'TRY', category: 'currency', volatility: 1.5, liquidity: 1.2, volume24h: 220000000000 },
  { id: 'idr', name: 'روپیه اندونزی', symbol: 'IDR', category: 'currency', volatility: 0.9, liquidity: 1.3, volume24h: 180000000000 },
  { id: 'thb', name: 'بات تایلند', symbol: 'THB', category: 'currency', volatility: 0.7, liquidity: 1.4, volume24h: 240000000000 },
  { id: 'sgd', name: 'دلار سنگاپور', symbol: 'SGD', category: 'currency', volatility: 0.6, liquidity: 1.6, volume24h: 380000000000 },
  { id: 'hkd', name: 'دلار هنگ‌کنگ', symbol: 'HKD', category: 'currency', volatility: 0.5, liquidity: 1.7, volume24h: 420000000000 },
  
  // ========================================
  // رمزارزها (Cryptocurrencies) - 15 مورد
  // ========================================
  
  // Top Tier
  { id: 'btc', name: 'بیت‌کوین', symbol: 'BTC', category: 'crypto', volatility: 2.2, liquidity: 2.0, marketCap: 850000000000, volume24h: 35000000000, sentiment: 0.6 },
  { id: 'eth', name: 'اتریوم', symbol: 'ETH', category: 'crypto', volatility: 2.4, liquidity: 2.0, marketCap: 280000000000, volume24h: 18000000000, sentiment: 0.7 },
  { id: 'bnb', name: 'بایننس کوین', symbol: 'BNB', category: 'crypto', volatility: 2.3, liquidity: 1.8, marketCap: 45000000000, volume24h: 2500000000, sentiment: 0.5 },
  { id: 'xrp', name: 'ریپل', symbol: 'XRP', category: 'crypto', volatility: 2.5, liquidity: 1.7, marketCap: 28000000000, volume24h: 1800000000, sentiment: 0.4 },
  { id: 'ada', name: 'کاردانو', symbol: 'ADA', category: 'crypto', volatility: 2.6, liquidity: 1.6, marketCap: 18000000000, volume24h: 950000000, sentiment: 0.5 },
  { id: 'sol', name: 'سولانا', symbol: 'SOL', category: 'crypto', volatility: 2.8, liquidity: 1.7, marketCap: 42000000000, volume24h: 2200000000, sentiment: 0.8 },
  { id: 'doge', name: 'دوج‌کوین', symbol: 'DOGE', category: 'crypto', volatility: 3.0, liquidity: 1.6, marketCap: 12000000000, volume24h: 850000000, sentiment: 0.3 },
  { id: 'matic', name: 'پالیگان', symbol: 'MATIC', category: 'crypto', volatility: 2.7, liquidity: 1.5, marketCap: 8500000000, volume24h: 580000000, sentiment: 0.6 },
  
  // DeFi & Layer 2
  { id: 'avax', name: 'آوالانچ', symbol: 'AVAX', category: 'crypto', volatility: 2.9, liquidity: 1.4, marketCap: 9200000000, volume24h: 420000000, sentiment: 0.5 },
  { id: 'dot', name: 'پولکادات', symbol: 'DOT', category: 'crypto', volatility: 2.7, liquidity: 1.5, marketCap: 7800000000, volume24h: 380000000, sentiment: 0.4 },
  { id: 'uni', name: 'یونی‌سواپ', symbol: 'UNI', category: 'crypto', volatility: 2.8, liquidity: 1.4, marketCap: 5200000000, volume24h: 280000000, sentiment: 0.5 },
  { id: 'link', name: 'چین‌لینک', symbol: 'LINK', category: 'crypto', volatility: 2.6, liquidity: 1.5, marketCap: 8800000000, volume24h: 520000000, sentiment: 0.6 },
  
  // Stablecoins
  { id: 'usdt', name: 'تتر', symbol: 'USDT', category: 'crypto', volatility: 0.1, liquidity: 2.0, marketCap: 95000000000, volume24h: 55000000000, sentiment: 0.0 },
  { id: 'usdc', name: 'USD Coin', symbol: 'USDC', category: 'crypto', volatility: 0.1, liquidity: 1.9, marketCap: 28000000000, volume24h: 8500000000, sentiment: 0.0 },
  { id: 'dai', name: 'دای', symbol: 'DAI', category: 'crypto', volatility: 0.2, liquidity: 1.7, marketCap: 5200000000, volume24h: 950000000, sentiment: 0.0 },
  
  // ========================================
  // شاخص‌ها (Indices) - 10 مورد
  // ========================================
  
  // شاخص‌های آمریکا
  { id: 'spx', name: 'اس‌اند‌پی ۵۰۰', symbol: 'SPX', category: 'index', volatility: 0.8, liquidity: 2.0, volume24h: 450000000000 },
  { id: 'dji', name: 'داو جونز', symbol: 'DJI', category: 'index', volatility: 0.7, liquidity: 1.9, volume24h: 280000000000 },
  { id: 'ixic', name: 'نزدک', symbol: 'IXIC', category: 'index', volatility: 1.0, liquidity: 1.9, volume24h: 380000000000 },
  { id: 'rut', name: 'راسل ۲۰۰۰', symbol: 'RUT', category: 'index', volatility: 1.1, liquidity: 1.6, volume24h: 150000000000 },
  
  // شاخص‌های اروپا
  { id: 'ftse', name: 'FTSE 100', symbol: 'FTSE', category: 'index', volatility: 0.8, liquidity: 1.7, volume24h: 180000000000 },
  { id: 'dax', name: 'DAX', symbol: 'DAX', category: 'index', volatility: 0.9, liquidity: 1.8, volume24h: 220000000000 },
  { id: 'cac', name: 'CAC 40', symbol: 'CAC', category: 'index', volatility: 0.9, liquidity: 1.6, volume24h: 140000000000 },
  
  // شاخص‌های آسیا
  { id: 'n225', name: 'نیکی ۲۲۵', symbol: 'N225', category: 'index', volatility: 0.9, liquidity: 1.7, volume24h: 190000000000 },
  { id: 'hsi', name: 'هنگ‌سنگ', symbol: 'HSI', category: 'index', volatility: 1.0, liquidity: 1.6, volume24h: 160000000000 },
  { id: 'ssec', name: 'شانگهای', symbol: 'SSEC', category: 'index', volatility: 1.1, liquidity: 1.5, volume24h: 280000000000 },
];

export const ASSET_CATEGORIES: Record<AssetCategory, string> = {
  stock: 'سهام',
  commodity: 'کالا',
  currency: 'ارز',
  crypto: 'رمزارز',
  index: 'شاخص',
};

// قیمت‌های پایه برای هر دسته (بر اساس منطق قیمت‌گذاری اولیه)
export const BASE_PRICES: Record<string, number> = {
  // سهام
  'aapl': 175, 'msft': 380, 'googl': 140, 'meta': 350, 'nvda': 480,
  'amd': 125, 'intc': 42, 'tsla': 245, 'jpm': 155, 'bac': 32,
  'wfc': 48, 'gs': 365, 'ms': 88, 'pfe': 28, 'jnj': 160,
  'mrna': 95, 'abbv': 152, 'xom': 110, 'cvx': 158, 'cop': 118,
  'amzn': 155, 'wmt': 162, 'cost': 580, 'ge': 115, 'f': 12,
  
  // کالاها
  'gold': 1950, 'silver': 24, 'plat': 980, 'pall': 1250,
  'oil': 82, 'brent': 86, 'natgas': 2.8, 'coal': 135, 'uranium': 68,
  'copper': 3.85, 'alum': 2.25, 'zinc': 2.65, 'nickel': 18.5,
  'wheat': 6.2, 'corn': 4.8, 'soybean': 14.5, 'coffee': 1.85, 'sugar': 0.22,
  
  // ارزها (نسبت به USD)
  'usd': 1.0, 'eur': 1.08, 'gbp': 1.26, 'jpy': 0.0067, 'chf': 1.13,
  'cad': 0.73, 'aud': 0.65, 'nzd': 0.60, 'cny': 0.14, 'inr': 0.012,
  'brl': 0.20, 'rub': 0.011, 'krw': 0.00075, 'mxn': 0.058, 'zar': 0.053,
  'try': 0.033, 'idr': 0.000064, 'thb': 0.028, 'sgd': 0.74, 'hkd': 0.128,
  
  // رمزارزها
  'btc': 43500, 'eth': 2280, 'bnb': 315, 'xrp': 0.54, 'ada': 0.48,
  'sol': 98, 'doge': 0.085, 'matic': 0.82, 'avax': 36, 'dot': 6.8,
  'uni': 6.2, 'link': 15.5, 'usdt': 1.0, 'usdc': 1.0, 'dai': 1.0,
  
  // شاخص‌ها
  'spx': 4580, 'dji': 36500, 'ixic': 14250, 'rut': 1950,
  'ftse': 7650, 'dax': 16800, 'cac': 7450,
  'n225': 33500, 'hsi': 17800, 'ssec': 3080,
};

export const LEVERAGE_OPTIONS = [1, 2, 5, 10, 20, 50, 100];

export const TICK_INTERVAL = 10000; // 10 ثانیه
export const TICKS_PER_DAY = 9; // 9 تیک در هر روز
export const DAY_DURATION = 90000; // 90 ثانیه
