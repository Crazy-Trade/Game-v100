import { Country } from '../types';

export const COUNTRIES: Country[] = [
  {
    id: 'usa',
    name: 'آمریکا',
    flag: '🇺🇸',
    bonus: {
      type: 'stocks',
      value: 10,
    },
  },
  {
    id: 'china',
    name: 'چین',
    flag: '🇨🇳',
    bonus: {
      type: 'production',
      value: 15,
    },
  },
  {
    id: 'germany',
    name: 'آلمان',
    flag: '🇩🇪',
    bonus: {
      type: 'exports',
      value: 10,
    },
  },
  {
    id: 'japan',
    name: 'ژاپن',
    flag: '🇯🇵',
    bonus: {
      type: 'tech',
      value: 10,
    },
  },
  {
    id: 'uae',
    name: 'امارات',
    flag: '🇦🇪',
    bonus: {
      type: 'energy',
      value: 8,
    },
  },
];

export const STARTING_CAPITAL = 100000;
