import { Achievement } from '../types';

export const ACHIEVEMENTS: Omit<Achievement, 'unlocked' | 'unlockedAt'>[] = [
  {
    id: 'first_million',
    name: 'میلیونر',
    description: 'اولین میلیون دلار خود را بسازید',
    reward: 10000,
  },
  {
    id: 'hundred_million',
    name: 'صد میلیونر',
    description: 'به ۱۰۰ میلیون دلار برسید',
    reward: 100000,
  },
  {
    id: 'billionaire',
    name: 'میلیاردر',
    description: 'به ۱ میلیارد دلار برسید',
    reward: 1000000,
  },
  {
    id: 'first_trade',
    name: 'معامله‌گر تازه‌کار',
    description: 'اولین معامله خود را انجام دهید',
    reward: 1000,
  },
  {
    id: 'margin_master',
    name: 'استاد مارجین',
    description: '۱۰ معامله مارجین موفق انجام دهید',
    reward: 25000,
  },
  {
    id: 'survived_crash',
    name: 'بازمانده بحران',
    description: 'از یک بحران بزرگ جان سالم به در ببرید',
    reward: 50000,
  },
  {
    id: 'company_founder',
    name: 'بنیانگذار',
    description: 'اولین شرکت خود را تاسیس کنید',
    reward: 100000,
  },
  {
    id: 'ipo_success',
    name: 'IPO موفق',
    description: 'شرکت خود را وارد بازار سهام کنید',
    reward: 500000,
  },
  {
    id: 'crypto_creator',
    name: 'خالق رمزارز',
    description: 'رمزارز خود را بسازید و لیست کنید',
    reward: 1000000,
  },
  {
    id: 'day_100',
    name: 'استقامت',
    description: 'به روز ۱۰۰ برسید',
    reward: 50000,
  },
  {
    id: 'day_365',
    name: 'یک سال کامل',
    description: 'یک سال کامل بازی کنید',
    reward: 200000,
  },
  {
    id: 'liquidated',
    name: 'لیکوئید شده',
    description: 'اولین لیکوئیدیشن خود را تجربه کنید',
    reward: 0,
  },
];
