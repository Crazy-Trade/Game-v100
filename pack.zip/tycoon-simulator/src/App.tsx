import { useGameStore } from './store/gameStore';
import { NotificationProvider } from './components/ui/NotificationProvider';
import CountrySelection from './components/game/CountrySelection';
import NewsTicker from './components/game/NewsTicker';
import GameControls from './components/game/GameControls';
import Tutorial from './components/game/Tutorial';
import AssetList from './components/market/AssetList';
import MarketChart from './components/market/MarketChart';
import TradingPanel from './components/trading/TradingPanel';
import Portfolio from './components/trading/Portfolio';
import CompanyModule from './components/company/CompanyModule';
import Achievements from './components/game/Achievements';
import FinancialAnalyzer from './components/analyzer/FinancialAnalyzer';
import { OrderBook } from './components/trading/OrderBook';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import ProfessionalChartDemo from './ProfessionalChartDemo';
import { useEffect } from 'react';

function App() {
  const player = useGameStore(state => state.player);
  const selectAsset = useGameStore(state => state.selectAsset);
  const assets = useGameStore(state => state.assets);
  const selectedAsset = useGameStore(state => state.selectedAsset);

  // Select first asset on mount
  useEffect(() => {
    if (assets.length > 0) {
      selectAsset(assets[0].id);
    }
  }, []);

  // Show country selection if not initialized
  if (!player.country) {
    return (
      <NotificationProvider>
        <CountrySelection />
      </NotificationProvider>
    );
  }

  return (
    <NotificationProvider>
      <div className="min-h-screen bg-primary">
        {/* Tutorial */}
        <Tutorial />

        {/* News Ticker - Always visible */}
        <NewsTicker />

        {/* Game Controls */}
        <GameControls />

        {/* Main Content */}
        <div className="max-w-[1920px] mx-auto p-6">
          <div className="grid grid-cols-12 gap-6">
            {/* Left Sidebar - Asset List */}
            <div className="col-span-12 lg:col-span-3">
              <AssetList />
            </div>

            {/* Center - Chart & Content */}
            <div className="col-span-12 lg:col-span-6">
              <div className="space-y-6">
                {/* Market Chart */}
                <div className="h-[600px]">
                  <MarketChart />
                </div>

                {/* Tabs for Portfolio, Company, Achievements, Analyzer */}
                <Tabs defaultValue="portfolio" className="w-full">
                  <TabsList className="grid w-full grid-cols-5 bg-secondary border border-border-primary">
                    <TabsTrigger value="portfolio" className="data-[state=active]:bg-gold data-[state=active]:text-bg-primary">
                      پورتفولیو
                    </TabsTrigger>
                    <TabsTrigger value="analyzer" className="data-[state=active]:bg-gold data-[state=active]:text-bg-primary">
                      آنالیزور
                    </TabsTrigger>
                    <TabsTrigger value="company" className="data-[state=active]:bg-gold data-[state=active]:text-bg-primary">
                      شرکت
                    </TabsTrigger>
                    <TabsTrigger value="achievements" className="data-[state=active]:bg-gold data-[state=active]:text-bg-primary">
                      دستاوردها
                    </TabsTrigger>
                    <TabsTrigger value="professional-chart" className="data-[state=active]:bg-gold data-[state=active]:text-bg-primary">
                      نمودار حرفه‌ای
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="portfolio" className="mt-4">
                    <Portfolio />
                  </TabsContent>
                  <TabsContent value="analyzer" className="mt-4">
                    <FinancialAnalyzer />
                  </TabsContent>
                  <TabsContent value="company" className="mt-4">
                    <CompanyModule />
                  </TabsContent>
                  <TabsContent value="achievements" className="mt-4">
                    <Achievements />
                  </TabsContent>
                  <TabsContent value="professional-chart" className="mt-0">
                    <div className="-mx-6 -my-6">
                      <ProfessionalChartDemo />
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>

            {/* Right Sidebar - Trading Panel */}
            <div className="col-span-12 lg:col-span-3">
              <div className="sticky top-6 space-y-6">
                <TradingPanel />
                {selectedAsset && (
                  <OrderBook
                    assetId={selectedAsset.id}
                    assetSymbol={selectedAsset.symbol}
                    currentPrice={selectedAsset.currentPrice}
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </NotificationProvider>
  );
}

export default App;
