// Real Market Data Service for Tycoon Simulator 3.0
import type { Asset, PricePoint, News } from '../types';

class RealMarketDataService {
  private static instance: RealMarketDataService;
  private marketData: any = null;
  private newsData: any = null;
  private lastUpdate: number = 0;
  private updateInterval: number = 60000; // 1 minute

  private constructor() {}

  static getInstance(): RealMarketDataService {
    if (!RealMarketDataService.instance) {
      RealMarketDataService.instance = new RealMarketDataService();
    }
    return RealMarketDataService.instance;
  }

  // Load real market data from JSON files
  async loadMarketData(): Promise<void> {
    try {
      // Load complete market data
      const [marketResponse, newsResponse] = await Promise.all([
        fetch('/data/complete_market_data_88_assets.json'),
        fetch('/data/news_impact_system.json')
      ]);

      if (!marketResponse.ok) {
        throw new Error(`Failed to load market data: ${marketResponse.status}`);
      }

      const marketData = await marketResponse.json();
      const newsData = newsResponse.ok ? await newsResponse.json() : null;

      this.marketData = marketData;
      this.newsData = newsData;
      this.lastUpdate = Date.now();

      console.log('✅ Real market data loaded successfully');
      console.log(`📊 Loaded ${Object.keys(marketData.assets || {}).length} assets`);
      
    } catch (error) {
      console.error('❌ Error loading real market data:', error);
      throw error;
    }
  }

  // Get all assets with real data
  async getAllAssets(): Promise<Asset[]> {
    if (!this.marketData) {
      await this.loadMarketData();
    }

    if (!this.marketData?.assets) {
      throw new Error('No market data available');
    }

    const assets: Asset[] = [];
    const assetClasses = ['stocks', 'cryptocurrencies', 'commodities', 'currencies', 'indices'];

    for (const assetClass of assetClasses) {
      const classData = this.marketData.assets[assetClass];
      if (!classData) continue;

      for (const [symbol, data] of Object.entries<any>(classData)) {
        if (!data) continue;

        const asset: Asset = {
          id: symbol.toLowerCase(),
          symbol: symbol.toUpperCase(),
          name: data.name || symbol,
          category: this.mapCategory(assetClass),
          currentPrice: data.currentPrice || data.price || 100,
          previousPrice: data.previousPrice || data.currentPrice || data.price || 100,
          changePercent: data.changePercent || data.change_24h || 0,
          priceHistory: this.generatePriceHistory(data),
          marketCap: data.marketCap,
          volume24h: data.volume24h,
          peRatio: data.peRatio,
          sentiment: data.sentiment || 0,
          volatility: data.volatility || 1.0,
          liquidity: data.liquidity || 1.0,
          realData: true,
          lastUpdated: Date.now()
        };

        assets.push(asset);
      }
    }

    return assets.sort((a, b) => a.symbol.localeCompare(b.symbol));
  }

  // Get specific asset by symbol
  async getAsset(symbol: string): Promise<Asset | null> {
    const assets = await this.getAllAssets();
    return assets.find(asset => asset.symbol.toUpperCase() === symbol.toUpperCase()) || null;
  }

  // Get real-time price for asset
  async getRealTimePrice(symbol: string): Promise<number | null> {
    const asset = await this.getAsset(symbol);
    if (!asset) return null;

    // Add small random fluctuation to simulate real-time changes
    const fluctuation = (Math.random() - 0.5) * 0.005; // ±0.25%
    const newPrice = asset.currentPrice * (1 + fluctuation);
    
    return Math.round(newPrice * 100) / 100;
  }

  // Update asset prices with real market data
  async updateAssetPrices(assets: Asset[]): Promise<Asset[]> {
    const updatedAssets: Asset[] = [];

    for (const asset of assets) {
      const realTimePrice = await this.getRealTimePrice(asset.symbol);
      if (realTimePrice !== null) {
        const lastPoint = asset.priceHistory[asset.priceHistory.length - 1];
        const newPoint: PricePoint = {
          timestamp: Date.now(),
          open: lastPoint.close,
          high: Math.max(lastPoint.close, realTimePrice),
          low: Math.min(lastPoint.close, realTimePrice),
          close: realTimePrice,
          volume: Math.floor(Math.random() * 1000000)
        };

        updatedAssets.push({
          ...asset,
          previousPrice: asset.currentPrice,
          currentPrice: realTimePrice,
          changePercent: ((realTimePrice - asset.previousPrice) / asset.previousPrice) * 100,
          priceHistory: [...asset.priceHistory.slice(-99), newPoint],
          lastUpdated: Date.now()
        });
      } else {
        updatedAssets.push(asset);
      }
    }

    return updatedAssets;
  }

  // Get news with impact
  async getNews(): Promise<News[]> {
    if (!this.newsData) {
      try {
        const response = await fetch('/data/news_impact_system.json');
        if (response.ok) {
          this.newsData = await response.json();
        }
      } catch (error) {
        console.warn('Could not load news data:', error);
        return this.getDefaultNews();
      }
    }

    // Convert news impact system to News array
    const news: News[] = [];
    
    if (this.newsData?.news_types) {
      for (const [type, data] of Object.entries<any>(this.newsData.news_types)) {
        if (data.impact_ranges) {
          const impact: Record<string, { min: number; max: number }> = {};
          for (const [asset, range] of Object.entries<any>(data.impact_ranges)) {
            impact[asset] = { min: range[0] || 0, max: range[1] || 0 };
          }

          news.push({
            id: `news_${type}_${Date.now()}`,
            title: this.translateNewsTitle(type),
            titleEn: this.getNewsTitleEn(type),
            description: this.translateNewsDescription(type),
            descriptionEn: this.getNewsDescriptionEn(type),
            impact,
            severity: data.severity || 'normal',
            category: this.mapNewsCategory(type),
            timestamp: Date.now(),
            applied: false
          });
        }
      }
    }

    return news.length > 0 ? news : this.getDefaultNews();
  }

  // Apply news impact to assets
  applyNewsImpact(asset: Asset, news: News): Asset {
    const impact = news.impact[asset.symbol];
    if (!impact) return asset;

    const impactValue = impact.min + Math.random() * (impact.max - impact.min);
    const newPrice = asset.currentPrice * (1 + impactValue / 100);
    
    const lastPoint = asset.priceHistory[asset.priceHistory.length - 1];
    const newPoint: PricePoint = {
      timestamp: Date.now(),
      open: lastPoint.close,
      high: Math.max(lastPoint.close, newPrice),
      low: Math.min(lastPoint.close, newPrice),
      close: newPrice,
      volume: Math.floor(Math.random() * 5000000)
    };

    return {
      ...asset,
      previousPrice: asset.currentPrice,
      currentPrice: newPrice,
      changePercent: ((newPrice - asset.previousPrice) / asset.previousPrice) * 100,
      priceHistory: [...asset.priceHistory.slice(-99), newPoint],
      lastUpdated: Date.now()
    };
  }

  // Get market correlation data
  getCorrelationMatrix(): Record<string, Record<string, number>> {
    return this.marketData?.correlation_analysis?.correlations || {};
  }

  // Get volatility data
  getVolatilityData(): Record<string, number> {
    return this.marketData?.volatility_24h || {};
  }

  // Private helper methods
  private mapCategory(assetClass: string): 'stock' | 'crypto' | 'commodity' | 'currency' | 'index' {
    const mapping: Record<string, 'stock' | 'crypto' | 'commodity' | 'currency' | 'index'> = {
      'stocks': 'stock',
      'cryptocurrencies': 'crypto',
      'commodities': 'commodity',
      'currencies': 'currency',
      'indices': 'index'
    };
    return mapping[assetClass] || 'stock';
  }

  private generatePriceHistory(data: any): PricePoint[] {
    if (data.price_history && Array.isArray(data.price_history)) {
      return data.price_history.map((point: any) => ({
        timestamp: point.timestamp || Date.now(),
        open: point.open || data.currentPrice || 100,
        high: point.high || data.currentPrice || 100,
        low: point.low || data.currentPrice || 100,
        close: point.close || data.currentPrice || 100,
        volume: point.volume || 0
      }));
    }

    // Generate basic price history if not available
    const history: PricePoint[] = [];
    const basePrice = data.currentPrice || data.price || 100;
    const now = Date.now();
    
    for (let i = 30; i >= 0; i--) {
      const timestamp = now - (i * 24 * 60 * 60 * 1000); // Daily data for 30 days
      const fluctuation = (Math.random() - 0.5) * 0.02; // ±1% daily change
      const price = basePrice * (1 + fluctuation);
      
      history.push({
        timestamp,
        open: price,
        high: price * (1 + Math.random() * 0.01),
        low: price * (1 - Math.random() * 0.01),
        close: price,
        volume: Math.floor(Math.random() * 1000000)
      });
    }

    return history;
  }

  private mapNewsCategory(type: string): 'economic' | 'political' | 'corporate' | 'technical' | 'regulatory' {
    const mapping: Record<string, 'economic' | 'political' | 'corporate' | 'technical' | 'regulatory'> = {
      'interest_rate': 'economic',
      'inflation': 'economic',
      'earnings': 'corporate',
      'merger': 'corporate',
      'regulation': 'regulatory',
      'technology': 'technical',
      'election': 'political'
    };
    return mapping[type] || 'economic';
  }

  private translateNewsTitle(type: string): string {
    const translations: Record<string, string> = {
      'interest_rate': 'تغییر نرخ بهره',
      'inflation': 'تورم غیرمترقبه',
      'earnings': 'اعلام درآمد فصلی',
      'merger': 'ادغام شرکت‌ها',
      'regulation': 'قوانین جدید',
      'technology': 'نوآوری تکنولوژیک',
      'election': 'نتایج انتخابات'
    };
    return translations[type] || 'اخبار بازار';
  }

  private getNewsTitleEn(type: string): string {
    const titles: Record<string, string> = {
      'interest_rate': 'Interest Rate Change',
      'inflation': 'Unexpected Inflation',
      'earnings': 'Quarterly Earnings Report',
      'merger': 'Corporate Merger Announcement',
      'regulation': 'New Regulations Implemented',
      'technology': 'Technological Innovation',
      'election': 'Election Results Released'
    };
    return titles[type] || 'Market News';
  }

  private translateNewsDescription(type: string): string {
    const descriptions: Record<string, string> = {
      'interest_rate': 'بانک مرکزی نرخ بهره را تغییر داده است که تأثیر قابل توجهی بر بازارها خواهد داشت.',
      'inflation': 'مقامات تورم غیرمترقبه اعلام کردند که انتظار می‌رود بر قیمت‌ها تأثیر بگذارد.',
      'earnings': 'شرکت‌ها گزارش‌های درآمد فصلی را منتشر کردند.',
      'merger': 'دو شرکت بزرگ اعلام ادغام کردند که تأثیر گسترده‌ای بر صنعت خواهد داشت.',
      'regulation': 'قوانین جدید اعلام شد که ممکن است بر صنایع مختلف تأثیر بگذارد.',
      'technology': 'نوآوری جدیدی اعلام شد که می‌تواند آینده صنعت را تغییر دهد.',
      'election': 'نتایج انتخابات منتشر شد که تأثیر سیاسی قابل توجهی خواهد داشت.'
    };
    return descriptions[type] || 'اخبار مهم بازار که ممکن است تأثیرگذار باشد.';
  }

  private getNewsDescriptionEn(type: string): string {
    const descriptions: Record<string, string> = {
      'interest_rate': 'The central bank has announced an interest rate change that will significantly impact markets.',
      'inflation': 'Officials announced unexpected inflation that is expected to affect prices.',
      'earnings': 'Companies have released quarterly earnings reports.',
      'merger': 'Two major companies announced a merger that will have a wide impact on the industry.',
      'regulation': 'New regulations have been announced that may affect various industries.',
      'technology': 'A new innovation has been announced that could change the future of the industry.',
      'election': 'Election results have been released with significant political impact.'
    };
    return descriptions[type] || 'Important market news that may have significant impact.';
  }

  private getDefaultNews(): News[] {
    return [
      {
        id: 'default_news_1',
        title: 'صعود بازار',
        titleEn: 'Market Rally',
        description: 'بازارها امروز عملکرد مثبت نشان دادند.',
        descriptionEn: 'Markets showed positive performance today.',
        impact: {},
        severity: 'normal',
        category: 'economic',
        timestamp: Date.now(),
        applied: false
      }
    ];
  }

  // Check if data is stale
  isDataStale(): boolean {
    return Date.now() - this.lastUpdate > this.updateInterval;
  }

  // Force update data
  async refreshData(): Promise<void> {
    this.lastUpdate = 0;
    await this.loadMarketData();
  }
}

export default RealMarketDataService;
