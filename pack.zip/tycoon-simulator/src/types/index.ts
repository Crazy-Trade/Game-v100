// Enhanced Types for Tycoon Simulator 3.0
export type AssetCategory = 'stock' | 'crypto' | 'commodity' | 'currency' | 'index';

export interface Asset {
  id: string;
  symbol: string;
  name: string;
  category: AssetCategory;
  currentPrice: number;
  previousPrice: number;
  changePercent: number;
  priceHistory: PricePoint[];
  marketCap?: number;
  volume24h?: number;
  peRatio?: number;
  sentiment?: number;
  volatility?: number;
  liquidity?: number;
  realData: boolean;
  lastUpdated: number;
}

export interface PricePoint {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// Trading Systems
export type OrderType = 
  | 'market' | 'limit' | 'stop' | 'stopLimit' | 'trailing' | 'iceberg' | 'fillOrKill';

export type TradeType = 'spot' | 'margin' | 'futures';
export type PositionSide = 'long' | 'short';

export interface Trade {
  id: string;
  assetId: string;
  assetName: string;
  type: TradeType;
  side: PositionSide;
  entryPrice: number;
  currentPrice?: number;
  amount: number;
  leverage: number;
  margin: number;
  pnl: number;
  pnlPercent: number;
  stopLoss?: number;
  takeProfit?: number;
  liquidationPrice?: number;
  openedAt: number;
  closedAt?: number;
}

export interface Order {
  id: string;
  assetId: string;
  assetName: string;
  type: OrderType;
  side: PositionSide;
  amount: number;
  leverage: number;
  price?: number;
  stopPrice?: number;
  createdAt: number;
  executedAt?: number;
  status: 'pending' | 'filled' | 'cancelled' | 'expired';
  trailingPercent?: number;
  icebergVisibleAmount?: number;
  ocoSecondPrice?: number;
}

// News System
export interface NewsImpact {
  [assetSymbol: string]: {
    min: number;
    max: number;
  };
}

export interface News {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  descriptionEn: string;
  impact: NewsImpact;
  severity: 'minor' | 'normal' | 'major' | 'critical';
  category: 'economic' | 'political' | 'corporate' | 'technical' | 'regulatory';
  timestamp: number;
  applied: boolean;
  source?: string;
}

// Game State
export interface GameState {
  isRunning: boolean;
  isPaused: boolean;
  currentDay: number;
  ticksInDay: number;
  secondsRemaining: number;
  totalDays: number;
  timeScale: number;
}

export interface PlayerStats {
  cash: number;
  totalAssets: number;
  totalValue: number;
  dailyPnL: number;
  totalPnL: number;
  startingCapital: number;
  country: string;
  level: number;
  experience: number;
  achievements: string[];
  reputation: number;
}

// Enhanced Company System
export interface CompanyModule {
  isUnlocked: boolean;
  companyName: string;
  companyValue: number;
  revenue: number;
  profit: number;
  cash: number;
  employees: number;
  morale: number;
  productionLevel: number;
  brandEquity: number;
  techLevel: number;
  researchPoints: number;
  supplyChain: SupplyChain;
  hr: HRSystem;
  techTree: TechNode[];
  valueHistory: CompanyValuePoint[];
  upgrades: Upgrade[];
  industry: string;
  marketPosition: number;
  competitiveRating: number;
  internationalPresence: number;
  ipPortfolio: number;
  sustainabilityScore: number;
}

export interface SupplyChain {
  supplier: 'basic' | 'premium' | 'luxury';
  warehouseLevel: number;
  qualityControl: number;
  inventory: number;
  monthlyCost: number;
  logisticsNetwork: string[];
  internationalSuppliers: number;
  costOptimization: number;
  riskAssessment: number;
}

export interface HRSystem {
  salaryLevel: number;
  trainingBudget: number;
  morale: number;
  productivity: number;
  strikeRisk: number;
  employeeSatisfaction: number;
  diversityIndex: number;
  turnoverRate: number;
  talentAcquisition: number;
}

export interface TechNode {
  id: string;
  name: string;
  description: string;
  cost: number;
  unlocked: boolean;
  researchPointsRequired: number;
  benefits: Record<string, number>;
  dependencies: string[];
  timeToResearch: number;
  category: 'production' | 'marketing' | 'research' | 'hr' | 'logistics';
}

export interface CompanyValuePoint {
  day: number;
  value: number;
  change: number;
  events: string[];
}

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  level: number;
  maxLevel: number;
  effects: Record<string, number>;
  category: 'production' | 'marketing' | 'research' | 'hr' | 'logistics';
  unlockRequirements: Record<string, number>;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: 'trading' | 'company' | 'social' | 'special';
  requirements: Record<string, number>;
  reward?: number;
  unlocked: boolean;
  unlockedAt?: number;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

// Advanced Systems
export interface LoanData {
  amount: number;
  interestRate: number;
  remainingPayments: number;
  monthlyPayment: number;
  takenAt: number;
  lender: string;
  collateral?: string;
}

export interface AnalystReport {
  assetId: string;
  analysis: string;
  recommendation: 'buy' | 'sell' | 'hold';
  targetPrice: number;
  accuracy: number;
  generatedAt: number;
  priceTargets: { short: number; medium: number; long: number };
  riskLevel: 'low' | 'medium' | 'high';
  keyFactors: string[];
}

export interface MarketingCampaign {
  id: string;
  type: 'digital' | 'social' | 'tv' | 'billboard' | 'influencer' | 'content';
  cost: number;
  duration: number;
  impact: number;
  startDay: number;
  roi: number;
  reach: number;
  engagement: number;
  brandLifting: number;
}

export interface IPOStatus {
  eligible: boolean;
  listed: boolean;
  phase: 'preparation' | 'audit' | 'pricing' | 'offering' | 'listed' | 'suspended';
  sharePrice: number;
  marketCap: number;
  quarterlyProfits: number[];
  dividendYield: number;
  daysInPhase: number;
  auditDuration: number;
  bankType: 'premium' | 'standard';
  underwriters: string[];
  prospectusApproved: boolean;
  roadshowCompleted: boolean;
  subscriptionRate: number;
}

export interface CryptoProject {
  launched: boolean;
  listed: boolean;
  phase: 'research' | 'development' | 'testing' | 'ico' | 'launched' | 'listed';
  tokenName: string;
  tokenSymbol: string;
  tokenPrice: number;
  marketCap: number;
  utility: string;
  roadmapProgress: number;
  daysInPhase: number;
  milestones: CryptoMilestone[];
  credibility: number;
  adoption: number;
  totalSupply: number;
  circulatingSupply: number;
  stakingRewards: number;
  governance: boolean;
  partnerships: string[];
  auditsCompleted: boolean;
  exchanges: string[];
}

export interface CryptoMilestone {
  id: string;
  name: string;
  description: string;
  status: 'LOCKED' | 'ACTIVE' | 'COMPLETED' | 'FAILED';
  startDay?: number;
  deadline: number;
  progress: number;
  requirements: {
    funding?: number;
    techLevel?: number;
    developers?: number;
    marketing?: number;
  };
  effects: {
    credibilityBonus: number;
    adoptionIncrease: number;
    priceImpact: number;
  };
  rewards?: {
    tokens?: number;
    unlocks?: string[];
  };
}

export interface NPCCompany {
  id: string;
  name: string;
  industry: string;
  size: 'small' | 'medium' | 'large';
  relationship: number;
  contractValue: number;
  requirements: {
    brandEquity: number;
    revenue: number;
    techLevel: number;
  };
  aiPersonality: string;
  negotiationStyle: 'aggressive' | 'cooperative' | 'analytical' | 'creative';
  marketPosition: number;
  innovationIndex: number;
  sustainabilityFocus: number;
}

export interface Contract {
  id: string;
  companyId: string;
  companyName: string;
  value: number;
  duration: number;
  startDay: number;
  revenue: number;
  completed: boolean;
  type: 'supply' | 'licensing' | 'partnership' | 'joint_venture' | 'franchise';
  terms: Record<string, any>;
  penalties?: number;
  bonuses?: number;
}

// Enhanced Market Data
export interface MarketDepth {
  bids: { price: number; volume: number }[];
  asks: { price: number; volume: number }[];
  spread: number;
  totalBidVolume: number;
  totalAskVolume: number;
  lastUpdate: number;
}

export interface TechnicalIndicator {
  name: string;
  value: number;
  signal: 'buy' | 'sell' | 'hold';
  strength: number;
  period: number;
  description: string;
}

export interface DrawingTool {
  id: string;
  type: 'trendline' | 'fibonacci' | 'support_resistance' | 'channel' | 'triangle' | 'pattern';
  points: { x: number; y: number }[];
  style: {
    color: string;
    lineWidth: number;
    lineStyle: 'solid' | 'dashed' | 'dotted';
  };
  isActive: boolean;
  createdAt: number;
}

export interface Alert {
  id: string;
  type: 'price' | 'technical' | 'news' | 'volume' | 'correlation';
  condition: Record<string, any>;
  assetId: string;
  message: string;
  isActive: boolean;
  createdAt: number;
  triggeredAt?: number;
  action: 'notification' | 'email' | 'sms' | 'sound';
  priority: 'low' | 'medium' | 'high' | 'critical';
}

export interface PortfolioMetrics {
  sharpeRatio: number;
  maxDrawdown: number;
  beta: number;
  alpha: number;
  volatility: number;
  correlationMatrix: Record<string, Record<string, number>>;
  riskScore: number;
  diversificationScore: number;
  performanceVsBenchmark: number;
}

export interface CompanyMetrics {
  roe: number;
  roa: number;
  debtToEquity: number;
  profitMargin: number;
  revenueGrowth: number;
  assetTurnover: number;
  inventoryTurnover: number;
  workingCapital: number;
  cashFlowFromOperations: number;
  returnOnCapitalEmployed: number;
}

export interface NewsSentiment {
  overall: number;
  byCategory: Record<string, number>;
  topKeywords: string[];
  sourceCredibility: number;
  marketImpact: number;
  timeDecay: number;
}

export interface RealTimeData {
  symbol: string;
  price: number;
  volume: number;
  change: number;
  changePercent: number;
  bid: number;
  ask: number;
  spread: number;
  timestamp: number;
  depth: MarketDepth;
}

// UI and Settings
export interface GameSettings {
  theme: 'light' | 'dark' | 'auto';
  language: 'en' | 'fa';
  autoSave: boolean;
  showTutorial: boolean;
  notifications: boolean;
  soundEnabled: boolean;
  volume: number;
  tradingConfirmations: boolean;
  chartTimeframe: '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w' | '1M';
  chartType: 'candlestick' | 'line' | 'area' | 'heikin_ashi' | 'renko';
  showVolume: boolean;
  showGrid: boolean;
  crosshairSync: boolean;
  performanceMode: boolean;
}

// Export interfaces for external use
export type { GameStore } from '../store/gameStore';

export interface Milestone {
  id: string;
  name: string;
  description: string;
  status: 'LOCKED' | 'ACTIVE' | 'COMPLETED' | 'FAILED';
  progress: number;  // 0-100
  deadline: number;  // day
  startDay?: number;
  requirements: {
    funding?: number;
    developers?: number;
    marketing?: number;
    techLevel?: number;
  };
  effects: {
    priceImpact: number;         // ±% impact on price
    credibilityBonus: number;    // credibility increase
    adoptionIncrease: number;    // adoption increase
    liquidityBonus?: number;     // liquidity increase
  };
  rewards?: {
    tokens?: number;
    unlocks?: string[];
  };
}

export interface CompanyValueHistory {
  day: number;
  value: number;
  change: number;
  events: string[];  // important events of the day
}

export interface OrderBookLevel {
  price: number;
  quantity: number;
  total: number;
}

export interface OrderBookData {
  bids: OrderBookLevel[];  // buys (green)
  asks: OrderBookLevel[];  // sells (red)
  spread: number;
  spreadPercent: number;
  lastPrice: number;
}

// Country System
export interface Country {
  id: string;
  name: string;
  nameEn: string;
  flag: string;
  bonus: {
    type: 'stocks' | 'production' | 'exports' | 'tech' | 'energy';
    value: number;
  };
  startingCapital: number;
  regulations: Record<string, number>;
  marketConditions: {
    volatility: number;
    liquidity: number;
    growth: number;
  };
  taxRate: number;
  language: 'en' | 'fa';
}

// Export all interfaces
export type {
  // Re-export existing types for backward compatibility
  TechNode as TechnologyNode,
  CompanyValueHistory as CompanyValueData,
  Milestone as CryptoMilestoneLegacy
};
