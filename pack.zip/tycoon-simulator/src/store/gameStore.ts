import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import {
  Asset,
  Trade,
  Order,
  News,
  GameState,
  PlayerStats,
  CompanyModule,
  Achievement,
  LoanData,
  AnalystReport,
  TechNode,
  MarketingCampaign,
  SupplyChain,
  HRSystem,
  IPOStatus,
  CryptoProject,
  PricePoint,
  NPCCompany,
  Contract,
  Upgrade,
  Milestone,
} from '../types';
import { INITIAL_ASSETS, BASE_PRICES, TICKS_PER_DAY } from '../constants/assets';
import { STARTING_CAPITAL } from '../constants/countries';
import { ACHIEVEMENTS } from '../constants/achievements';
import { INITIAL_UPGRADES, INITIAL_CRYPTO_MILESTONES } from '../constants/companyData';

interface GameStore {
  // Game State
  game: GameState;
  player: PlayerStats;
  
  // Market State
  assets: Asset[];
  selectedAsset: Asset | null;
  
  // Trading State
  openTrades: Trade[];
  closedTrades: Trade[];
  pendingOrders: Order[];
  
  // News State
  activeNews: News[];
  newsHistory: News[];
  
  // Company State
  company: CompanyModule | null;
  techTree: TechNode[];
  campaigns: MarketingCampaign[];
  supplyChain: SupplyChain | null;
  hr: HRSystem | null;
  ipo: IPOStatus | null;
  crypto: CryptoProject | null;
  npcCompanies: NPCCompany[];
  contracts: Contract[];
  
  // Support Systems
  achievements: Achievement[];
  loans: LoanData[];
  analystReports: AnalystReport[];
  
  // Actions
  initializeGame: (country: string) => void;
  startDay: () => void;
  pauseDay: () => void;
  resumeDay: () => void;
  updateTick: () => void;
  endDay: () => void;
  fastSimulate: (days: number) => void;
  
  selectAsset: (assetId: string) => void;
  
  openTrade: (trade: Omit<Trade, 'id' | 'pnl' | 'pnlPercent' | 'currentPrice' | 'openedAt'>) => void;
  closeTrade: (tradeId: string) => void;
  updateTradesPnL: () => void;
  checkLiquidations: () => void;
  
  placeOrder: (order: Omit<Order, 'id' | 'createdAt'>) => void;
  cancelOrder: (orderId: string) => void;
  executeOrders: () => void;
  
  publishNews: () => void;
  applyNewsImpact: (news: News) => void;
  
  unlockCompany: (name: string) => void;
  updateCompany: (updates: Partial<CompanyModule>) => void;
  purchaseUpgrade: (upgradeId: string) => void;
  
  // IPO Actions
  startIPO: (bankType: 'premium' | 'standard') => void;
  advanceIPOPhase: () => void;
  payDividend: () => void;
  
  // Crypto Actions
  startCrypto: (tokenName: string, tokenSymbol: string, utility: string) => void;
  advanceCryptoPhase: () => void;
  launchICO: () => void;
  listCrypto: () => void;
  startMilestone: (milestoneId: string) => void;
  updateMilestones: () => void;
  
  // Marketing Actions
  launchCampaign: (type: string, budget: number) => void;
  upgradeBrand: () => void;
  
  // Lobbying Actions
  improveRelationship: (companyId: string, amount: number) => void;
  signContract: (companyId: string) => void;
  
  unlockAchievement: (achievementId: string) => void;
  
  takeLoan: (amount: number, months: number) => void;
  repayLoan: (loanIndex: number) => void;
  
  requestAnalysis: (assetId: string) => void;
  
  saveGame: () => void;
  loadGame: (savedState: Partial<GameStore>) => void;
  resetGame: () => void;
}

const initializeAssets = (): Asset[] => {
  return INITIAL_ASSETS.map(asset => {
    const basePrice = BASE_PRICES[asset.id] || 100; // fallback به 100 اگر قیمت پیدا نشد
    return {
      ...asset,
      currentPrice: basePrice,
      previousPrice: basePrice,
      changePercent: 0,
      priceHistory: [{
        timestamp: Date.now(),
        open: basePrice,
        high: basePrice,
        low: basePrice,
        close: basePrice,
        volume: 0,
      }],
    };
  });
};

const initializeAchievements = (): Achievement[] => {
  return ACHIEVEMENTS.map(achievement => ({
    ...achievement,
    unlocked: false,
  }));
};

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      // Initial State
      game: {
        isRunning: false,
        isPaused: false,
        currentDay: 1,
        ticksInDay: 0,
        secondsRemaining: 90,
        totalDays: 0,
      },
      
      player: {
        cash: STARTING_CAPITAL,
        totalAssets: 0,
        totalValue: STARTING_CAPITAL,
        dailyPnL: 0,
        totalPnL: 0,
        startingCapital: STARTING_CAPITAL,
        country: '',
      },
      
      assets: initializeAssets(),
      selectedAsset: null,
      
      openTrades: [],
      closedTrades: [],
      pendingOrders: [],
      
      activeNews: [],
      newsHistory: [],
      
      company: null,
      techTree: [],
      campaigns: [],
      supplyChain: null,
      hr: null,
      ipo: null,
      crypto: null,
      npcCompanies: [
        {
          id: 'npc1',
          name: 'شرکت فناوری آتی',
          industry: 'تکنولوژی',
          size: 'small',
          relationship: 30,
          contractValue: 500000,
          requirements: { brandEquity: 30, revenue: 1000000, techLevel: 3 },
        },
        {
          id: 'npc2',
          name: 'صنایع پارس',
          industry: 'تولید',
          size: 'medium',
          relationship: 20,
          contractValue: 2000000,
          requirements: { brandEquity: 50, revenue: 5000000, techLevel: 4 },
        },
        {
          id: 'npc3',
          name: 'گروه بین‌المللی آسیا',
          industry: 'خدمات مالی',
          size: 'large',
          relationship: 10,
          contractValue: 10000000,
          requirements: { brandEquity: 75, revenue: 20000000, techLevel: 5 },
        },
      ],
      contracts: [],
      
      achievements: initializeAchievements(),
      loans: [],
      analystReports: [],
      
      // Actions
      initializeGame: (country: string) => {
        set({
          player: {
            ...get().player,
            country,
          },
          assets: initializeAssets(),
        });
      },
      
      startDay: () => {
        set({
          game: {
            ...get().game,
            isRunning: true,
            isPaused: false,
            ticksInDay: 0,
            secondsRemaining: 90,
          },
        });
      },
      
      pauseDay: () => {
        set({
          game: {
            ...get().game,
            isPaused: true,
          },
        });
      },
      
      resumeDay: () => {
        set({
          game: {
            ...get().game,
            isPaused: false,
          },
        });
      },
      
      updateTick: () => {
        const { game, assets } = get();
        
        // Update prices with random fluctuation
        const updatedAssets = assets.map(asset => {
          const fluctuation = (Math.random() - 0.5) * 0.01; // -0.5% to +0.5%
          const newPrice = asset.currentPrice * (1 + fluctuation);
          
          const lastPoint = asset.priceHistory[asset.priceHistory.length - 1];
          const newPoint: PricePoint = {
            timestamp: Date.now(),
            open: lastPoint.close,
            high: Math.max(lastPoint.close, newPrice),
            low: Math.min(lastPoint.close, newPrice),
            close: newPrice,
            volume: Math.floor(Math.random() * 1000000),
          };
          
          return {
            ...asset,
            previousPrice: asset.currentPrice,
            currentPrice: newPrice,
            changePercent: ((newPrice - asset.previousPrice) / asset.previousPrice) * 100,
            priceHistory: [...asset.priceHistory.slice(-100), newPoint], // Keep last 100 points
          };
        });
        
        set({
          assets: updatedAssets,
          game: {
            ...game,
            ticksInDay: game.ticksInDay + 1,
            secondsRemaining: game.secondsRemaining - 10,
          },
        });
        
        // Update trades P&L
        get().updateTradesPnL();
        
        // Check liquidations
        get().checkLiquidations();
        
        // Execute pending orders
        get().executeOrders();
        
        // Publish news randomly
        if (Math.random() < 0.3) { // 30% chance per tick
          get().publishNews();
        }
        
        // End day if all ticks completed
        if (game.ticksInDay + 1 >= TICKS_PER_DAY) {
          get().endDay();
        }
      },
      
      endDay: () => {
        const { game, player, openTrades, ipo, crypto, contracts, company } = get();
        
        const totalAssets = openTrades.reduce((sum, trade) => {
          return sum + (trade.amount * trade.currentPrice);
        }, 0);
        
        const totalValue = player.cash + totalAssets;
        const dailyPnL = totalValue - player.totalValue;
        
        // Update IPO phase days
        let updatedIpo = ipo;
        if (ipo && !ipo.listed) {
          updatedIpo = {
            ...ipo,
            daysInPhase: ipo.daysInPhase + 1,
          };
        }
        
        // Update Crypto phase days
        let updatedCrypto = crypto;
        if (crypto && !crypto.launched) {
          updatedCrypto = {
            ...crypto,
            daysInPhase: crypto.daysInPhase + 1,
          };
        }
        
        // Update contracts and add daily revenue
        let dailyContractRevenue = 0;
        const updatedContracts = contracts.map(contract => {
          if (!contract.completed) {
            const daysActive = game.currentDay - contract.startDay;
            if (daysActive >= contract.duration) {
              return { ...contract, completed: true };
            } else {
              dailyContractRevenue += contract.revenue;
              return contract;
            }
          }
          return contract;
        });
        
        // Add contract revenue to company cash
        let updatedCompany = company;
        if (company && dailyContractRevenue > 0) {
          updatedCompany = {
            ...company,
            cash: company.cash + dailyContractRevenue,
            revenue: company.revenue + dailyContractRevenue,
          };
        }
        
        // Update company value history
        if (updatedCompany && game.currentDay % 1 === 0) {
          const previousValue = updatedCompany.companyValue;
          const events: string[] = [];
          
          // اضافه کردن رویدادهای مهم
          if (dailyContractRevenue > 0) {
            events.push(`قرارداد: $${dailyContractRevenue.toLocaleString()}`);
          }
          
          // محاسبه تغییر ارزش
          const valueChange = updatedCompany.companyValue - (updatedCompany.valueHistory[updatedCompany.valueHistory.length - 1]?.value || previousValue);
          const changePercent = (valueChange / previousValue) * 100;
          
          updatedCompany = {
            ...updatedCompany,
            valueHistory: [
              ...updatedCompany.valueHistory,
              {
                day: game.currentDay + 1,
                value: updatedCompany.companyValue,
                change: changePercent,
                events
              }
            ]
          };
        }
        
        set({
          game: {
            ...game,
            isRunning: false,
            currentDay: game.currentDay + 1,
            totalDays: game.totalDays + 1,
            ticksInDay: 0,
            secondsRemaining: 90,
          },
          player: {
            ...player,
            totalAssets,
            totalValue,
            dailyPnL,
            totalPnL: player.totalPnL + dailyPnL,
          },
          ipo: updatedIpo,
          crypto: updatedCrypto,
          contracts: updatedContracts,
          company: updatedCompany,
        });
        
        // Update milestones
        get().updateMilestones();
        
        // Check achievements
        if (totalValue >= 1000000 && !get().achievements.find(a => a.id === 'first_million')?.unlocked) {
          get().unlockAchievement('first_million');
        }
        if (totalValue >= 100000000 && !get().achievements.find(a => a.id === 'hundred_million')?.unlocked) {
          get().unlockAchievement('hundred_million');
        }
        if (totalValue >= 1000000000 && !get().achievements.find(a => a.id === 'billionaire')?.unlocked) {
          get().unlockAchievement('billionaire');
        }
        
        // Check company unlock
        if (totalValue >= 5000000 && !get().company) {
          // Company can be unlocked
        }
      },
      
      fastSimulate: (days: number) => {
        // Fast simulation logic with chunking to prevent freeze
        const simulateDay = () => {
          get().startDay();
          for (let tick = 0; tick < TICKS_PER_DAY; tick++) {
            get().updateTick();
          }
        };
        
        // Process in chunks to avoid blocking UI
        let processed = 0;
        const chunkSize = 10; // Process 10 days at a time
        
        const processChunk = () => {
          const toProcess = Math.min(chunkSize, days - processed);
          for (let i = 0; i < toProcess; i++) {
            simulateDay();
          }
          processed += toProcess;
          
          if (processed < days) {
            // Continue processing next chunk
            setTimeout(processChunk, 0);
          }
        };
        
        processChunk();
      },
      
      selectAsset: (assetId: string) => {
        const asset = get().assets.find(a => a.id === assetId);
        set({ selectedAsset: asset || null });
      },
      
      openTrade: (tradeData) => {
        const { player, assets } = get();
        const asset = assets.find(a => a.id === tradeData.assetId);
        
        if (!asset) return;
        
        const totalCost = tradeData.type === 'spot' 
          ? tradeData.amount * asset.currentPrice
          : (tradeData.amount * asset.currentPrice) / tradeData.leverage;
        
        if (player.cash < totalCost) {
          alert('موجودی کافی نیست');
          return;
        }
        
        const liquidationPrice = tradeData.type === 'margin'
          ? tradeData.side === 'long'
            ? asset.currentPrice * (1 - 1 / tradeData.leverage)
            : asset.currentPrice * (1 + 1 / tradeData.leverage)
          : undefined;
        
        const newTrade: Trade = {
          ...tradeData,
          id: `trade_${Date.now()}_${Math.random()}`,
          currentPrice: asset.currentPrice,
          pnl: 0,
          pnlPercent: 0,
          liquidationPrice,
          openedAt: Date.now(),
        };
        
        set({
          openTrades: [...get().openTrades, newTrade],
          player: {
            ...player,
            cash: player.cash - totalCost,
          },
        });
        
        // Check first trade achievement
        if (get().openTrades.length === 1 && !get().achievements.find(a => a.id === 'first_trade')?.unlocked) {
          get().unlockAchievement('first_trade');
        }
      },
      
      closeTrade: (tradeId: string) => {
        const { openTrades, player, assets } = get();
        const trade = openTrades.find(t => t.id === tradeId);
        
        if (!trade) return;
        
        const asset = assets.find(a => a.id === trade.assetId);
        if (!asset) return;
        
        const closedTrade: Trade = {
          ...trade,
          closedAt: Date.now(),
          currentPrice: asset.currentPrice,
        };
        
        const returnAmount = trade.type === 'spot'
          ? trade.amount * asset.currentPrice
          : (trade.amount * asset.currentPrice) / trade.leverage + trade.pnl;
        
        set({
          openTrades: openTrades.filter(t => t.id !== tradeId),
          closedTrades: [...get().closedTrades, closedTrade],
          player: {
            ...player,
            cash: player.cash + Math.max(0, returnAmount),
          },
        });
      },
      
      updateTradesPnL: () => {
        const { openTrades, assets, player } = get();
        
        const updatedTrades = openTrades.map(trade => {
          const asset = assets.find(a => a.id === trade.assetId);
          if (!asset) return trade;
          
          const priceDiff = asset.currentPrice - trade.entryPrice;
          const pnl = trade.type === 'spot'
            ? priceDiff * trade.amount
            : priceDiff * trade.amount * trade.leverage * (trade.side === 'long' ? 1 : -1);
          
          const pnlPercent = (pnl / (trade.margin * trade.leverage)) * 100;
          
          // Check stop loss and take profit
          if (trade.stopLoss && asset.currentPrice <= trade.stopLoss) {
            setTimeout(() => get().closeTrade(trade.id), 0);
          }
          if (trade.takeProfit && asset.currentPrice >= trade.takeProfit) {
            setTimeout(() => get().closeTrade(trade.id), 0);
          }
          
          return {
            ...trade,
            currentPrice: asset.currentPrice,
            pnl,
            pnlPercent,
          };
        });
        
        // محاسبه ارزش کل دارایی‌ها
        const totalAssets = updatedTrades.reduce((sum, trade) => {
          return sum + (trade.amount * trade.currentPrice);
        }, 0);
        
        // محاسبه ارزش کل
        const totalValue = player.cash + totalAssets;
        
        set({ 
          openTrades: updatedTrades,
          player: {
            ...player,
            totalAssets,
            totalValue
          }
        });
      },
      
      checkLiquidations: () => {
        const { openTrades } = get();
        
        openTrades.forEach(trade => {
          if (trade.type === 'margin' && trade.liquidationPrice) {
            const shouldLiquidate = trade.side === 'long'
              ? trade.currentPrice <= trade.liquidationPrice
              : trade.currentPrice >= trade.liquidationPrice;
            
            if (shouldLiquidate) {
              get().closeTrade(trade.id);
              
              // Check liquidation achievement
              if (!get().achievements.find(a => a.id === 'liquidated')?.unlocked) {
                get().unlockAchievement('liquidated');
              }
            }
          }
        });
      },
      
      placeOrder: (orderData) => {
        const newOrder: Order = {
          ...orderData,
          id: `order_${Date.now()}_${Math.random()}`,
          createdAt: Date.now(),
        };
        
        set({
          pendingOrders: [...get().pendingOrders, newOrder],
        });
      },
      
      cancelOrder: (orderId: string) => {
        set({
          pendingOrders: get().pendingOrders.filter(o => o.id !== orderId),
        });
      },
      
      executeOrders: () => {
        const { pendingOrders, assets } = get();
        
        pendingOrders.forEach(order => {
          const asset = assets.find(a => a.id === order.assetId);
          if (!asset) return;
          
          let shouldExecute = false;
          
          if (order.type === 'market') {
            shouldExecute = true;
          } else if (order.type === 'limit') {
            shouldExecute = order.side === 'long'
              ? asset.currentPrice <= order.price
              : asset.currentPrice >= order.price;
          }
          
          if (shouldExecute) {
            get().openTrade({
              assetId: order.assetId,
              assetName: order.assetName,
              type: 'margin',
              side: order.side,
              entryPrice: asset.currentPrice,
              amount: order.amount,
              leverage: order.leverage,
              margin: (order.amount * asset.currentPrice) / order.leverage,
              stopLoss: order.stopLoss,
              takeProfit: order.takeProfit,
            });
            
            get().cancelOrder(order.id);
          }
        });
      },
      
      publishNews: async () => {
        try {
          const response = await fetch('/data/news/news-pool.json');
          const newsData = await response.json();
          
          const allNews = [...newsData.normalNews, ...newsData.majorNews];
          const randomNews = allNews[Math.floor(Math.random() * allNews.length)];
          
          const news: News = {
            id: randomNews.id,
            title: randomNews.title,
            description: randomNews.description,
            impact: randomNews.impact,
            severity: newsData.majorNews.some((n: any) => n.id === randomNews.id) ? 'major' : 'normal',
            timestamp: Date.now(),
            applied: false,
          };
          
          set({
            activeNews: [...get().activeNews, news],
          });
          
          // Apply news impact after a short delay
          setTimeout(() => {
            get().applyNewsImpact(news);
          }, 2000);
          
        } catch (error) {
          console.error('Error loading news:', error);
        }
      },
      
      applyNewsImpact: (news: News) => {
        const { assets } = get();
        
        const updatedAssets = assets.map(asset => {
          const impact = news.impact[asset.symbol];
          
          if (!impact) return asset;
          
          const impactValue = impact.min + Math.random() * (impact.max - impact.min);
          const newPrice = asset.currentPrice * (1 + impactValue / 100);
          
          const lastPoint = asset.priceHistory[asset.priceHistory.length - 1];
          const newPoint: PricePoint = {
            timestamp: Date.now(),
            open: lastPoint.close,
            high: Math.max(lastPoint.close, newPrice),
            low: Math.min(lastPoint.close, newPrice),
            close: newPrice,
            volume: Math.floor(Math.random() * 5000000), // Higher volume for news
          };
          
          return {
            ...asset,
            previousPrice: asset.currentPrice,
            currentPrice: newPrice,
            changePercent: ((newPrice - asset.currentPrice) / asset.currentPrice) * 100,
            priceHistory: [...asset.priceHistory.slice(-100), newPoint],
          };
        });
        
        set({
          assets: updatedAssets,
          activeNews: get().activeNews.map(n => 
            n.id === news.id ? { ...n, applied: true } : n
          ),
          newsHistory: [...get().newsHistory, { ...news, applied: true }],
        });
      },
      
      unlockCompany: (name: string) => {
        set({
          company: {
            isUnlocked: true,
            companyName: name,
            companyValue: 50000000,
            revenue: 0,
            profit: 0,
            employees: 10,
            morale: 70,
            productionLevel: 50,
            brandEquity: 0,
            techLevel: 1,
            researchPoints: 0,
            cash: 10000000, // سرمایه اولیه شرکت
            supplyChain: {
              supplier: 'premium',
              warehouseLevel: 50,
              qualityControl: 70,
              inventory: 1000,
              monthlyCost: 10000,
            },
            hr: {
              salaryLevel: 70,
              trainingBudget: 5000,
              morale: 70,
              productivity: 75,
              strikeRisk: 10,
            },
            techTree: [],
            valueHistory: [{
              day: get().game.currentDay,
              value: 50000000,
              change: 0,
              events: ['تأسیس شرکت']
            }],
            upgrades: INITIAL_UPGRADES.map(u => ({ ...u }))
          },
        });
        
        if (!get().achievements.find(a => a.id === 'company_founder')?.unlocked) {
          get().unlockAchievement('company_founder');
        }
      },
      
      updateCompany: (updates) => {
        const { company } = get();
        if (!company) return;
        
        set({
          company: {
            ...company,
            ...updates,
          },
        });
      },
      
      unlockAchievement: (achievementId: string) => {
        const achievement = get().achievements.find(a => a.id === achievementId);
        if (!achievement || achievement.unlocked) return;
        
        set({
          achievements: get().achievements.map(a =>
            a.id === achievementId ? { ...a, unlocked: true, unlockedAt: Date.now() } : a
          ),
          player: {
            ...get().player,
            cash: get().player.cash + (achievement.reward || 0),
          },
        });
      },
      
      takeLoan: (amount: number, months: number) => {
        const interestRate = 0.05 + Math.random() * 0.05; // 5-10%
        const monthlyPayment = (amount * (1 + interestRate)) / months;
        
        const loan: LoanData = {
          amount,
          interestRate,
          remainingPayments: months,
          monthlyPayment,
          takenAt: Date.now(),
        };
        
        set({
          loans: [...get().loans, loan],
          player: {
            ...get().player,
            cash: get().player.cash + amount,
          },
        });
      },
      
      repayLoan: (loanIndex: number) => {
        const { loans, player } = get();
        const loan = loans[loanIndex];
        
        if (!loan || player.cash < loan.monthlyPayment) return;
        
        const updatedLoans = [...loans];
        updatedLoans[loanIndex] = {
          ...loan,
          remainingPayments: loan.remainingPayments - 1,
        };
        
        set({
          loans: updatedLoans.filter(l => l.remainingPayments > 0),
          player: {
            ...player,
            cash: player.cash - loan.monthlyPayment,
          },
        });
      },
      
      requestAnalysis: (assetId: string) => {
        const { player, assets } = get();
        const asset = assets.find(a => a.id === assetId);
        
        if (!asset || player.cash < 35000) return;
        
        const accuracy = 0.6;
        const trend = Math.random() > 0.5 ? 'up' : 'down';
        const targetPrice = asset.currentPrice * (1 + (Math.random() - 0.5) * 0.2);
        
        const analyses = [
          `بر اساس تحلیل تکنیکال، ${asset.name} در روند ${trend === 'up' ? 'صعودی' : 'نزولی'} قرار دارد.`,
          `شاخص‌های بنیادی ${asset.name} نشان‌دهنده ${trend === 'up' ? 'قدرت' : 'ضعف'} است.`,
          `پیش‌بینی می‌شود ${asset.name} در کوتاه‌مدت به ${targetPrice.toFixed(2)} برسد.`,
        ];
        
        const report: AnalystReport = {
          assetId,
          analysis: analyses[Math.floor(Math.random() * analyses.length)],
          recommendation: trend === 'up' ? 'buy' : 'sell',
          targetPrice,
          accuracy,
          generatedAt: Date.now(),
        };
        
        set({
          analystReports: [...get().analystReports, report],
          player: {
            ...player,
            cash: player.cash - 35000,
          },
        });
      },
      
      // IPO Actions
      startIPO: (bankType: 'premium' | 'standard') => {
        const { company } = get();
        if (!company) return;
        
        const auditDuration = bankType === 'premium' ? 15 : 30;
        const fee = bankType === 'premium' ? company.companyValue * 0.07 : company.companyValue * 0.03;
        
        if (company.cash < fee) return;
        
        set({
          ipo: {
            eligible: true,
            listed: false,
            phase: 'preparation',
            sharePrice: company.companyValue / 10000000, // 10M shares
            marketCap: company.companyValue,
            quarterlyProfits: [],
            dividendYield: 0,
            daysInPhase: 0,
            auditDuration,
            bankType,
          },
          company: {
            ...company,
            cash: company.cash - fee,
          },
        });
      },
      
      advanceIPOPhase: () => {
        const { ipo } = get();
        if (!ipo) return;
        
        const phases: IPOStatus['phase'][] = ['preparation', 'audit', 'pricing', 'offering', 'listed'];
        const currentIndex = phases.indexOf(ipo.phase);
        
        if (currentIndex < phases.length - 1) {
          const nextPhase = phases[currentIndex + 1];
          set({
            ipo: {
              ...ipo,
              phase: nextPhase,
              daysInPhase: 0,
              listed: nextPhase === 'listed',
            },
          });
        }
      },
      
      payDividend: () => {
        const { company, ipo } = get();
        if (!company || !ipo || !ipo.listed) return;
        
        const dividendAmount = company.profit * 0.3;
        
        set({
          ipo: {
            ...ipo,
            quarterlyProfits: [...ipo.quarterlyProfits, dividendAmount],
            dividendYield: (dividendAmount / ipo.marketCap) * 100,
          },
          company: {
            ...company,
            profit: company.profit - dividendAmount,
          },
        });
      },
      
      // Crypto Actions
      startCrypto: (tokenName: string, tokenSymbol: string, utility: string) => {
        set({
          crypto: {
            launched: false,
            listed: false,
            phase: 'research',
            tokenName,
            tokenSymbol,
            tokenPrice: 0.01,
            marketCap: 0,
            utility,
            roadmapProgress: 0,
            daysInPhase: 0,
            milestones: INITIAL_CRYPTO_MILESTONES.map(m => ({ ...m })),
            credibility: 0,
            adoption: 0
          },
        });
      },
      
      advanceCryptoPhase: () => {
        const { crypto, company } = get();
        if (!crypto || !company) return;
        
        const phases: CryptoProject['phase'][] = ['research', 'development', 'ico', 'listed'];
        const currentIndex = phases.indexOf(crypto.phase);
        const costs = [500000, 1000000, 2000000, 0];
        
        if (currentIndex < phases.length - 1 && company.cash >= costs[currentIndex]) {
          const nextPhase = phases[currentIndex + 1];
          set({
            crypto: {
              ...crypto,
              phase: nextPhase,
              daysInPhase: 0,
              roadmapProgress: ((currentIndex + 1) / phases.length) * 100,
            },
            company: {
              ...company,
              cash: company.cash - costs[currentIndex],
            },
          });
        }
      },
      
      launchICO: () => {
        const { crypto, company } = get();
        if (!crypto || !company || company.cash < 2000000) return;
        
        const raised = 5000000 + Math.random() * 10000000;
        
        set({
          crypto: {
            ...crypto,
            marketCap: raised,
            tokenPrice: 0.5,
          },
          company: {
            ...company,
            cash: company.cash - 2000000 + raised,
          },
        });
      },
      
      listCrypto: () => {
        const { crypto, company } = get();
        if (!crypto || !company || company.cash < 5000000) return;
        
        set({
          crypto: {
            ...crypto,
            phase: 'listed',
            launched: true,
            tokenPrice: 1.0,
            marketCap: crypto.marketCap * 2,
            roadmapProgress: 100,
          },
          company: {
            ...company,
            cash: company.cash - 5000000,
          },
        });
      },
      
      // Marketing Actions
      launchCampaign: (type: string, budget: number) => {
        const { company, game } = get();
        if (!company || company.cash < budget) return;
        
        const impactMap: Record<string, [number, number]> = {
          digital: [5, 15],
          social: [10, 25],
          tv: [20, 40],
          billboard: [15, 30],
        };
        
        const durationMap: Record<string, number> = {
          digital: 15,
          social: 20,
          tv: 30,
          billboard: 45,
        };
        
        const impact = impactMap[type]?.[0] + 
          ((impactMap[type]?.[1] - impactMap[type]?.[0]) * (budget / 50000 - 1) / 4);
        
        const campaign: MarketingCampaign = {
          id: `campaign_${Date.now()}`,
          type: type as any,
          cost: budget,
          duration: durationMap[type] || 30,
          impact: impact || 10,
          startDay: game.currentDay,
        };
        
        set({
          campaigns: [...get().campaigns, campaign],
          company: {
            ...company,
            cash: company.cash - budget,
            brandEquity: Math.min(company.brandEquity + impact / 2, 100),
          },
        });
      },
      
      upgradeBrand: () => {
        const { company } = get();
        if (!company || company.cash < 200000 || company.brandEquity >= 100) return;
        
        set({
          company: {
            ...company,
            cash: company.cash - 200000,
            brandEquity: Math.min(company.brandEquity + 5, 100),
          },
        });
      },
      
      // Lobbying Actions
      improveRelationship: (companyId: string, amount: number) => {
        const { company, npcCompanies } = get();
        if (!company || company.cash < amount) return;
        
        const improvement = amount / 10000;
        
        set({
          npcCompanies: npcCompanies.map(npc =>
            npc.id === companyId
              ? { ...npc, relationship: Math.min(npc.relationship + improvement, 100) }
              : npc
          ),
          company: {
            ...company,
            cash: company.cash - amount,
          },
        });
      },
      
      signContract: (companyId: string) => {
        const { npcCompanies, game } = get();
        const npc = npcCompanies.find(c => c.id === companyId);
        
        if (!npc || npc.relationship < 70) return;
        
        const contract: Contract = {
          id: `contract_${Date.now()}`,
          companyId: npc.id,
          companyName: npc.name,
          value: npc.contractValue,
          duration: 90, // 90 days
          startDay: game.currentDay,
          revenue: npc.contractValue * 0.05,
          completed: false,
        };
        
        set({
          contracts: [...get().contracts, contract],
        });
      },
      
      // Upgrade System
      purchaseUpgrade: (upgradeId: string) => {
        const { company } = get();
        if (!company) return;
        
        const upgrade = company.upgrades.find(u => u.id === upgradeId);
        if (!upgrade || upgrade.level >= upgrade.maxLevel) return;
        
        if (company.cash < upgrade.cost) return;
        
        const newLevel = upgrade.level + 1;
        const costMultiplier = Math.pow(1.5, newLevel);
        const newCost = Math.floor(upgrade.cost * costMultiplier);
        
        // محاسبه تأثیر بر ارزش شرکت
        const valueIncrease = upgrade.cost * 1.2;
        const newValue = company.companyValue + valueIncrease;
        
        set({
          company: {
            ...company,
            cash: company.cash - upgrade.cost,
            companyValue: newValue,
            upgrades: company.upgrades.map(u =>
              u.id === upgradeId
                ? { ...u, level: newLevel, cost: newCost }
                : u
            ),
            valueHistory: [
              ...company.valueHistory,
              {
                day: get().game.currentDay,
                value: newValue,
                change: ((newValue - company.companyValue) / company.companyValue) * 100,
                events: [`ارتقاء: ${upgrade.name}`]
              }
            ]
          }
        });
      },
      
      // Milestone System
      startMilestone: (milestoneId: string) => {
        const { crypto, company } = get();
        if (!crypto || !company) return;
        
        const milestone = crypto.milestones.find(m => m.id === milestoneId);
        if (!milestone || milestone.status !== 'LOCKED') return;
        
        // چک کردن نیازمندی‌ها
        const req = milestone.requirements;
        if (req.funding && company.cash < req.funding) return;
        if (req.techLevel && company.techLevel < req.techLevel) return;
        if (req.developers && company.employees < req.developers) return;
        if (req.marketing && company.cash < (req.funding || 0) + req.marketing) return;
        
        // کم کردن هزینه‌ها
        const totalCost = (req.funding || 0) + (req.marketing || 0);
        
        set({
          crypto: {
            ...crypto,
            milestones: crypto.milestones.map(m =>
              m.id === milestoneId
                ? { ...m, status: 'ACTIVE', startDay: get().game.currentDay, progress: 0 }
                : m
            )
          },
          company: {
            ...company,
            cash: company.cash - totalCost
          }
        });
      },
      
      updateMilestones: () => {
        const { crypto } = get();
        if (!crypto) return;
        
        const currentDay = get().game.currentDay;
        let needsUpdate = false;
        const updatedMilestones = crypto.milestones.map(milestone => {
          if (milestone.status !== 'ACTIVE') return milestone;
          
          // پیشرفت روزانه: 100 / (deadline - startDay)
          const totalDays = milestone.deadline - (milestone.startDay || currentDay);
          const dailyProgress = 100 / Math.max(totalDays, 1);
          const newProgress = Math.min(100, milestone.progress + dailyProgress);
          
          // چک کردن تکمیل
          if (newProgress >= 100) {
            needsUpdate = true;
            
            // اعمال تأثیرات
            const crypto = get().crypto;
            if (crypto) {
              const newCredibility = Math.min(100, crypto.credibility + milestone.effects.credibilityBonus);
              const newAdoption = Math.min(100, crypto.adoption + milestone.effects.adoptionIncrease);
              const priceMultiplier = 1 + (milestone.effects.priceImpact / 100);
              const newPrice = crypto.tokenPrice * priceMultiplier;
              
              set({
                crypto: {
                  ...crypto,
                  tokenPrice: newPrice,
                  credibility: newCredibility,
                  adoption: newAdoption,
                  marketCap: newPrice * 1000000
                }
              });
            }
            
            return { ...milestone, status: 'COMPLETED' as const, progress: 100 };
          }
          
          // چک کردن شکست (گذشتن از ددلاین)
          if (currentDay > milestone.deadline) {
            needsUpdate = true;
            return { ...milestone, status: 'FAILED' as const };
          }
          
          return { ...milestone, progress: newProgress };
        });
        
        if (needsUpdate) {
          set({
            crypto: {
              ...get().crypto!,
              milestones: updatedMilestones
            }
          });
        }
      },
      
      saveGame: () => {
        // Automatically saved by zustand persist
        console.log('Game saved');
      },
      
      loadGame: (savedState) => {
        set(savedState);
      },
      
      resetGame: () => {
        set({
          game: {
            isRunning: false,
            isPaused: false,
            currentDay: 1,
            ticksInDay: 0,
            secondsRemaining: 90,
            totalDays: 0,
          },
          player: {
            cash: STARTING_CAPITAL,
            totalAssets: 0,
            totalValue: STARTING_CAPITAL,
            dailyPnL: 0,
            totalPnL: 0,
            startingCapital: STARTING_CAPITAL,
            country: '',
          },
          assets: initializeAssets(),
          selectedAsset: null,
          openTrades: [],
          closedTrades: [],
          pendingOrders: [],
          activeNews: [],
          newsHistory: [],
          company: null,
          techTree: [],
          campaigns: [],
          supplyChain: null,
          hr: null,
          ipo: null,
          crypto: null,
          npcCompanies: [
            {
              id: 'npc1',
              name: 'شرکت فناوری آتی',
              industry: 'تکنولوژی',
              size: 'small',
              relationship: 30,
              contractValue: 500000,
              requirements: { brandEquity: 30, revenue: 1000000, techLevel: 3 },
            },
            {
              id: 'npc2',
              name: 'صنایع پارس',
              industry: 'تولید',
              size: 'medium',
              relationship: 20,
              contractValue: 2000000,
              requirements: { brandEquity: 50, revenue: 5000000, techLevel: 4 },
            },
            {
              id: 'npc3',
              name: 'گروه بین‌المللی آسیا',
              industry: 'خدمات مالی',
              size: 'large',
              relationship: 10,
              contractValue: 10000000,
              requirements: { brandEquity: 75, revenue: 20000000, techLevel: 5 },
            },
          ],
          contracts: [],
          achievements: initializeAchievements(),
          loans: [],
          analystReports: [],
        });
      },
    }),
    {
      name: 'tycoon-game-storage',
    }
  )
);
