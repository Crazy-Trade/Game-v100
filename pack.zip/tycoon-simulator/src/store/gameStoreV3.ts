// Enhanced Game Store for Tycoon Simulator 3.0
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { 
  GameState, 
  PlayerStats, 
  Asset, 
  Trade, 
  Order, 
  News, 
  CompanyModule, 
  Achievement,
  LoanData,
  AnalystReport,
  TechNode,
  MarketingCampaign,
  SupplyChain,
  HRSystem,
  IPOStatus,
  CryptoProject,
  NPCCompany,
  Contract,
  Upgrade,
  CompanyValuePoint,
  TechnicalIndicator,
  DrawingTool,
  Alert,
  PortfolioMetrics,
  CompanyMetrics,
  NewsSentiment,
  RealTimeData,
  GameSettings
} from '../types';
import RealMarketDataService from '../services/realMarketDataService';

// Enhanced GameStore interface for version 3.0
interface GameStore {
  // Game State
  game: GameState;
  player: PlayerStats;
  settings: GameSettings;
  
  // Market State
  assets: Asset[];
  selectedAsset: Asset | null;
  realTimeData: Record<string, RealTimeData>;
  technicalIndicators: Record<string, TechnicalIndicator[]>;
  drawingTools: DrawingTool[];
  
  // Trading State
  openTrades: Trade[];
  closedTrades: Trade[];
  pendingOrders: Order[];
  portfolioMetrics: PortfolioMetrics;
  
  // News State
  activeNews: News[];
  newsHistory: News[];
  newsSentiment: NewsSentiment | null;
  
  // Company State
  company: CompanyModule | null;
  companyMetrics: CompanyMetrics | null;
  techTree: TechNode[];
  campaigns: MarketingCampaign[];
  supplyChain: SupplyChain | null;
  hr: HRSystem | null;
  ipo: IPOStatus | null;
  crypto: CryptoProject | null;
  npcCompanies: NPCCompany[];
  contracts: Contract[];
  alerts: Alert[];
  
  // UI State
  selectedTimeframe: '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w' | '1M';
  selectedChartType: 'candlestick' | 'line' | 'area' | 'heikin_ashi' | 'renko';
  
  // Actions
  initializeGame: (country: string) => void;
  startDay: () => void;
  pauseDay: () => void;
  resumeDay: () => void;
  updateTick: () => void;
  endDay: () => void;
  fastSimulate: (days: number) => void;
  
  selectAsset: (assetId: string) => void;
  setTimeframe: (timeframe: '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w' | '1M') => void;
  setChartType: (type: 'candlestick' | 'line' | 'area' | 'heikin_ashi' | 'renko') => void;
  
  openTrade: (trade: Omit<Trade, 'id' | 'pnl' | 'pnlPercent' | 'currentPrice' | 'openedAt'>) => void;
  closeTrade: (tradeId: string) => void;
  updateTradesPnL: () => void;
  checkLiquidations: () => void;
  
  placeOrder: (order: Omit<Order, 'id' | 'createdAt' | 'status'>) => void;
  cancelOrder: (orderId: string) => void;
  executeOrders: () => void;
  
  publishNews: () => void;
  applyNewsImpact: (news: News) => void;
  
  unlockCompany: (name: string, industry: string) => void;
  updateCompany: (updates: Partial<CompanyModule>) => void;
  purchaseUpgrade: (upgradeId: string) => void;
  
  // Advanced Company Actions
  startMergersAcquisition: (targetId: string, offerType: 'stock' | 'cash' | 'mixed') => void;
  negotiateJointVenture: (partnerId: string, industry: string) => void;
  applyForLicensing: (patentId: string) => void;
  startFranchising: (location: string) => void;
  improveHR: (aspect: keyof HRSystem, amount: number) => void;
  upgradeSupplyChain: (upgrade: string) => void;
  conductResearch: (researchId: string) => void;
  launchProductLine: (category: string) => void;
  
  // IPO Actions
  startIPO: (bankType: 'premium' | 'standard') => void;
  advanceIPOPhase: () => void;
  payDividend: () => void;
  
  // Crypto Actions
  startCrypto: (tokenName: string, tokenSymbol: string, utility: string) => void;
  advanceCryptoPhase: () => void;
  launchICO: () => void;
  listCrypto: () => void;
  startMilestone: (milestoneId: string) => void;
  updateMilestones: () => void;
  
  // Advanced Crypto Actions
  listOnExchange: (exchange: string, liquidity: number) => void;
  startStaking: (amount: number, duration: number) => void;
  implementGovernance: () => void;
  createNFT: (metadata: any) => void;
  provideLiquidity: (tokenA: string, tokenB: string, amountA: number, amountB: number) => void;
  
  // Marketing Actions
  launchCampaign: (type: string, budget: number, targeting?: any) => void;
  upgradeBrand: () => void;
  conductMarketResearch: (focus: string) => void;
  improveSustainability: () => void;
  
  // Business Actions
  improveRelationship: (companyId: string, amount: number) => void;
  signContract: (companyId: string) => void;
  negotiatePricing: (companyId: string, newTerms: any) => void;
  expandInternationally: (region: string) => void;
  filePatents: (innovation: string) => void;
  
  // Technical Analysis Actions
  addDrawingTool: (tool: Omit<DrawingTool, 'id' | 'createdAt'>) => void;
  removeDrawingTool: (toolId: string) => void;
  calculateIndicators: (assetId: string) => void;
  setAlert: (alert: Omit<Alert, 'id' | 'createdAt'>) => void;
  removeAlert: (alertId: string) => void;
  
  // UI Actions
  setTheme: (theme: 'light' | 'dark' | 'auto') => void;
  setLanguage: (language: 'en' | 'fa') => void;
  toggleVolume: () => void;
  toggleGrid: () => void;
  setCrosshairSync: (sync: boolean) => void;
  
  // Data Actions
  loadRealData: () => Promise<void>;
  updateRealTimePrice: (symbol: string) => void;
  calculatePortfolioMetrics: () => void;
  calculateCompanyMetrics: () => void;
  updateNewsSentiment: () => void;
  
  unlockAchievement: (achievementId: string) => void;
  takeLoan: (amount: number, months: number, collateral?: string) => void;
  repayLoan: (loanIndex: number) => void;
  requestAnalysis: (assetId: string) => void;
  
  saveGame: () => void;
  loadGame: (savedState: Partial<GameStore>) => void;
  resetGame: () => void;
  exportGameData: () => string;
  importGameData: (data: string) => void;
}

// Constants
const TICKS_PER_DAY = 9;
const REAL_DATA_SERVICE = RealMarketDataService.getInstance();

// Sample game data
const SAMPLE_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_trade',
    name: 'First Trade',
    description: 'Execute your first trade',
    icon: 'trade',
    category: 'trading',
    requirements: { trades: 1 },
    unlocked: false,
    rarity: 'common'
  },
  {
    id: 'company_founder',
    name: 'Company Founder',
    description: 'Establish your first company',
    icon: 'company',
    category: 'company',
    requirements: { companyValue: 1000000 },
    unlocked: false,
    rarity: 'rare'
  },
  {
    id: 'billionaire',
    name: 'Billionaire Tycoon',
    description: 'Accumulate a net worth of 1 billion',
    icon: 'billion',
    category: 'special',
    requirements: { netWorth: 1000000000 },
    unlocked: false,
    rarity: 'legendary'
  }
];

const SAMPLE_NPC_COMPANIES: NPCCompany[] = [
  {
    id: 'tech_giant',
    name: 'TechCorp Industries',
    industry: 'Technology',
    size: 'large',
    relationship: 30,
    contractValue: 10000000,
    requirements: { brandEquity: 50, revenue: 5000000, techLevel: 4 },
    aiPersonality: 'innovative',
    negotiationStyle: 'analytical',
    marketPosition: 8.5,
    innovationIndex: 9.2,
    sustainabilityFocus: 7.8
  },
  {
    id: 'energy_corp',
    name: 'Global Energy Solutions',
    industry: 'Energy',
    size: 'large',
    relationship: 20,
    contractValue: 15000000,
    requirements: { brandEquity: 60, revenue: 10000000, techLevel: 3 },
    aiPersonality: 'conservative',
    negotiationStyle: 'cooperative',
    marketPosition: 7.9,
    innovationIndex: 6.5,
    sustainabilityFocus: 8.7
  }
];

// Default settings
const DEFAULT_SETTINGS: GameSettings = {
  theme: 'dark',
  language: 'en',
  autoSave: true,
  showTutorial: true,
  notifications: true,
  soundEnabled: true,
  volume: 0.7,
  tradingConfirmations: true,
  chartTimeframe: '1h',
  chartType: 'candlestick',
  showVolume: true,
  showGrid: true,
  crosshairSync: true,
  performanceMode: false
};

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      // Initial State
      game: {
        isRunning: false,
        isPaused: false,
        currentDay: 1,
        ticksInDay: 0,
        secondsRemaining: 90,
        totalDays: 0,
        timeScale: 1
      },
      
      player: {
        cash: 100000,
        totalAssets: 0,
        totalValue: 100000,
        dailyPnL: 0,
        totalPnL: 0,
        startingCapital: 100000,
        country: '',
        level: 1,
        experience: 0,
        achievements: [],
        reputation: 50
      },
      
      settings: DEFAULT_SETTINGS,
      
      assets: [],
      selectedAsset: null,
      realTimeData: {},
      technicalIndicators: {},
      drawingTools: [],
      
      openTrades: [],
      closedTrades: [],
      pendingOrders: [],
      portfolioMetrics: {
        sharpeRatio: 0,
        maxDrawdown: 0,
        beta: 0,
        alpha: 0,
        volatility: 0,
        correlationMatrix: {},
        riskScore: 50,
        diversificationScore: 50,
        performanceVsBenchmark: 0
      },
      
      activeNews: [],
      newsHistory: [],
      newsSentiment: null,
      
      company: null,
      companyMetrics: null,
      techTree: [],
      campaigns: [],
      supplyChain: null,
      hr: null,
      ipo: null,
      crypto: null,
      npcCompanies: SAMPLE_NPC_COMPANIES,
      contracts: [],
      alerts: [],
      
      selectedTimeframe: '1h',
      selectedChartType: 'candlestick',
      
      // Core Game Actions
      initializeGame: async (country: string) => {
        try {
          // Load real market data
          await get().loadRealData();
          
          set({
            player: {
              ...get().player,
              country,
            },
          });
          
          console.log(`🎮 Game initialized for country: ${country}`);
        } catch (error) {
          console.error('Failed to initialize game:', error);
        }
      },
      
      startDay: () => {
        set({
          game: {
            ...get().game,
            isRunning: true,
            isPaused: false,
            ticksInDay: 0,
            secondsRemaining: 90,
          },
        });
      },
      
      pauseDay: () => {
        set({
          game: {
            ...get().game,
            isPaused: true,
          },
        });
      },
      
      resumeDay: () => {
        set({
          game: {
            ...get().game,
            isPaused: false,
          },
        });
      },
      
      updateTick: async () => {
        const { game, assets } = get();
        
        // Update real-time prices
        const dataService = REAL_DATA_SERVICE;
        if (dataService.isDataStale() || assets.length === 0) {
          const updatedAssets = await dataService.updateAssetPrices(assets);
          set({ assets: updatedAssets });
        }
        
        // Update trades P&L
        get().updateTradesPnL();
        
        // Check liquidations
        get().checkLiquidations();
        
        // Execute pending orders
        get().executeOrders();
        
        // Publish news randomly (lower chance for real data)
        if (Math.random() < 0.15) { // 15% chance per tick
          await get().publishNews();
        }
        
        // Update milestones and company operations
        if (game.ticksInDay % 3 === 0) { // Every 3 ticks
          get().updateMilestones();
        }
        
        set({
          game: {
            ...game,
            ticksInDay: game.ticksInDay + 1,
            secondsRemaining: Math.max(0, game.secondsRemaining - 10),
          },
        });
        
        // End day if all ticks completed
        if (game.ticksInDay + 1 >= TICKS_PER_DAY) {
          get().endDay();
        }
      },
      
      endDay: () => {
        const { game, player, openTrades } = get();
        
        const totalAssets = openTrades.reduce((sum, trade) => {
          return sum + (trade.amount * trade.currentPrice);
        }, 0);
        
        const totalValue = player.cash + totalAssets;
        const dailyPnL = totalValue - player.totalValue;
        
        set({
          game: {
            ...game,
            isRunning: false,
            currentDay: game.currentDay + 1,
            totalDays: game.totalDays + 1,
            ticksInDay: 0,
            secondsRemaining: 90,
          },
          player: {
            ...player,
            totalAssets,
            totalValue,
            dailyPnL,
            totalPnL: player.totalPnL + dailyPnL,
            experience: player.experience + Math.abs(dailyPnL) / 1000,
            level: Math.floor(player.experience / 1000) + 1
          },
        });
        
        // Check achievements
        if (totalValue >= 1000000) {
          get().unlockAchievement('first_million');
        }
        if (totalValue >= 1000000000) {
          get().unlockAchievement('billionaire');
        }
      },
      
      fastSimulate: (days: number) => {
        const simulateDay = () => {
          get().startDay();
          for (let tick = 0; tick < TICKS_PER_DAY; tick++) {
            get().updateTick();
          }
        };
        
        let processed = 0;
        const chunkSize = 10;
        
        const processChunk = () => {
          const toProcess = Math.min(chunkSize, days - processed);
          for (let i = 0; i < toProcess; i++) {
            simulateDay();
          }
          processed += toProcess;
          
          if (processed < days) {
            setTimeout(processChunk, 0);
          }
        };
        
        processChunk();
      },
      
      // Asset Management
      selectAsset: (assetId: string) => {
        const asset = get().assets.find(a => a.id === assetId);
        set({ selectedAsset: asset || null });
      },
      
      setTimeframe: (timeframe) => {
        set({ selectedTimeframe: timeframe });
      },
      
      setChartType: (type) => {
        set({ selectedChartType: type });
      },
      
      // Trading Actions
      openTrade: (tradeData) => {
        const { player, assets } = get();
        const asset = assets.find(a => a.id === tradeData.assetId);
        
        if (!asset) return;
        
        const totalCost = tradeData.type === 'spot' 
          ? tradeData.amount * asset.currentPrice
          : (tradeData.amount * asset.currentPrice) / tradeData.leverage;
        
        if (player.cash < totalCost) {
          alert('Insufficient balance');
          return;
        }
        
        const liquidationPrice = tradeData.type === 'margin'
          ? tradeData.side === 'long'
            ? asset.currentPrice * (1 - 1 / tradeData.leverage)
            : asset.currentPrice * (1 + 1 / tradeData.leverage)
          : undefined;
        
        const newTrade: Trade = {
          ...tradeData,
          id: `trade_${Date.now()}_${Math.random()}`,
          currentPrice: asset.currentPrice,
          pnl: 0,
          pnlPercent: 0,
          liquidationPrice,
          openedAt: Date.now(),
        };
        
        set({
          openTrades: [...get().openTrades, newTrade],
          player: {
            ...player,
            cash: player.cash - totalCost,
          },
        });
        
        // Check achievements
        if (get().openTrades.length === 1) {
          get().unlockAchievement('first_trade');
        }
      },
      
      closeTrade: (tradeId: string) => {
        const { openTrades, player, assets } = get();
        const trade = openTrades.find(t => t.id === tradeId);
        
        if (!trade) return;
        
        const asset = assets.find(a => a.id === trade.assetId);
        if (!asset) return;
        
        const closedTrade: Trade = {
          ...trade,
          closedAt: Date.now(),
          currentPrice: asset.currentPrice,
        };
        
        const returnAmount = trade.type === 'spot'
          ? trade.amount * asset.currentPrice
          : (trade.amount * asset.currentPrice) / trade.leverage + trade.pnl;
        
        set({
          openTrades: openTrades.filter(t => t.id !== tradeId),
          closedTrades: [...get().closedTrades, closedTrade],
          player: {
            ...player,
            cash: player.cash + Math.max(0, returnAmount),
          },
        });
      },
      
      updateTradesPnL: () => {
        const { openTrades, assets, player } = get();
        
        const updatedTrades = openTrades.map(trade => {
          const asset = assets.find(a => a.id === trade.assetId);
          if (!asset) return trade;
          
          const priceDiff = asset.currentPrice - trade.entryPrice;
          const pnl = trade.type === 'spot'
            ? priceDiff * trade.amount
            : priceDiff * trade.amount * trade.leverage * (trade.side === 'long' ? 1 : -1);
          
          const pnlPercent = (pnl / (trade.margin * trade.leverage)) * 100;
          
          // Check stop loss and take profit
          if (trade.stopLoss && asset.currentPrice <= trade.stopLoss) {
            setTimeout(() => get().closeTrade(trade.id), 0);
          }
          if (trade.takeProfit && asset.currentPrice >= trade.takeProfit) {
            setTimeout(() => get().closeTrade(trade.id), 0);
          }
          
          return {
            ...trade,
            currentPrice: asset.currentPrice,
            pnl,
            pnlPercent,
          };
        });
        
        const totalAssets = updatedTrades.reduce((sum, trade) => {
          return sum + (trade.amount * trade.currentPrice);
        }, 0);
        
        const totalValue = player.cash + totalAssets;
        
        set({ 
          openTrades: updatedTrades,
          player: {
            ...player,
            totalAssets,
            totalValue
          }
        });
      },
      
      checkLiquidations: () => {
        const { openTrades } = get();
        
        openTrades.forEach(trade => {
          if (trade.type === 'margin' && trade.liquidationPrice) {
            const shouldLiquidate = trade.side === 'long'
              ? trade.currentPrice <= trade.liquidationPrice
              : trade.currentPrice >= trade.liquidationPrice;
            
            if (shouldLiquidate) {
              get().closeTrade(trade.id);
            }
          }
        });
      },
      
      // Order Management
      placeOrder: (orderData) => {
        const newOrder: Order = {
          ...orderData,
          id: `order_${Date.now()}_${Math.random()}`,
          createdAt: Date.now(),
          status: 'pending',
        };
        
        set({
          pendingOrders: [...get().pendingOrders, newOrder],
        });
      },
      
      cancelOrder: (orderId: string) => {
        set({
          pendingOrders: get().pendingOrders.filter(o => o.id !== orderId),
        });
      },
      
      executeOrders: () => {
        const { pendingOrders, assets } = get();
        
        pendingOrders.forEach(order => {
          const asset = assets.find(a => a.id === order.assetId);
          if (!asset) return;
          
          let shouldExecute = false;
          
          if (order.type === 'market') {
            shouldExecute = true;
          } else if (order.type === 'limit') {
            shouldExecute = order.side === 'long'
              ? asset.currentPrice <= (order.price || 0)
              : asset.currentPrice >= (order.price || 0);
          }
          
          if (shouldExecute) {
            get().openTrade({
              assetId: order.assetId,
              assetName: order.assetName,
              type: 'margin',
              side: order.side,
              entryPrice: asset.currentPrice,
              amount: order.amount,
              leverage: order.leverage,
              margin: (order.amount * asset.currentPrice) / order.leverage,
            });
            
            get().cancelOrder(order.id);
          }
        });
      },
      
      // News System
      publishNews: async () => {
        try {
          const news = await REAL_DATA_SERVICE.getNews();
          if (news.length > 0) {
            const randomNews = news[Math.floor(Math.random() * news.length)];
            set({
              activeNews: [...get().activeNews, randomNews],
            });
            
            // Apply news impact after a short delay
            setTimeout(() => {
              get().applyNewsImpact(randomNews);
            }, 2000);
          }
        } catch (error) {
          console.error('Error loading news:', error);
        }
      },
      
      applyNewsImpact: (news: News) => {
        const { assets } = get();
        
        const updatedAssets = assets.map(asset => {
          const realTimeService = REAL_DATA_SERVICE;
          return realTimeService.applyNewsImpact(asset, news);
        });
        
        set({
          assets: updatedAssets,
          activeNews: get().activeNews.map(n => 
            n.id === news.id ? { ...n, applied: true } : n
          ),
          newsHistory: [...get().newsHistory, { ...news, applied: true }],
        });
      },
      
      // Company System
      unlockCompany: (name: string, industry: string) => {
        set({
          company: {
            isUnlocked: true,
            companyName: name,
            companyValue: 50000000,
            revenue: 0,
            profit: 0,
            cash: 10000000,
            employees: 10,
            morale: 70,
            productionLevel: 50,
            brandEquity: 0,
            techLevel: 1,
            researchPoints: 0,
            industry,
            marketPosition: 5.0,
            competitiveRating: 6.0,
            internationalPresence: 0,
            ipPortfolio: 0,
            sustainabilityScore: 50,
            supplyChain: {
              supplier: 'premium',
              warehouseLevel: 50,
              qualityControl: 70,
              inventory: 1000,
              monthlyCost: 10000,
              logisticsNetwork: [],
              internationalSuppliers: 0,
              costOptimization: 0,
              riskAssessment: 50
            },
            hr: {
              salaryLevel: 70,
              trainingBudget: 5000,
              morale: 70,
              productivity: 75,
              strikeRisk: 10,
              employeeSatisfaction: 70,
              diversityIndex: 50,
              turnoverRate: 15,
              talentAcquisition: 60
            },
            techTree: [],
            valueHistory: [{
              day: get().game.currentDay,
              value: 50000000,
              change: 0,
              events: ['Company Founded']
            }],
            upgrades: []
          },
        });
        
        get().unlockAchievement('company_founder');
      },
      
      updateCompany: (updates) => {
        const { company } = get();
        if (!company) return;
        
        set({
          company: {
            ...company,
            ...updates,
          },
        });
      },
      
      purchaseUpgrade: (upgradeId: string) => {
        const { company } = get();
        if (!company) return;
        
        const upgrade = company.upgrades.find(u => u.id === upgradeId);
        if (!upgrade || upgrade.level >= upgrade.maxLevel) return;
        
        if (company.cash < upgrade.cost) return;
        
        const newLevel = upgrade.level + 1;
        const costMultiplier = Math.pow(1.5, newLevel);
        const newCost = Math.floor(upgrade.cost * costMultiplier);
        
        const valueIncrease = upgrade.cost * 1.2;
        const newValue = company.companyValue + valueIncrease;
        
        set({
          company: {
            ...company,
            cash: company.cash - upgrade.cost,
            companyValue: newValue,
            upgrades: company.upgrades.map(u =>
              u.id === upgradeId
                ? { ...u, level: newLevel, cost: newCost }
                : u
            ),
            valueHistory: [
              ...company.valueHistory,
              {
                day: get().game.currentDay,
                value: newValue,
                change: ((newValue - company.companyValue) / company.companyValue) * 100,
                events: [`Upgrade: ${upgrade.name}`]
              }
            ]
          }
        });
      },
      
      // Advanced Company Actions
      startMergersAcquisition: (targetId, offerType) => {
        const { company } = get();
        if (!company) return;
        
        // Implementation for M&A
        console.log(`Starting M&A with ${targetId}, offer type: ${offerType}`);
      },
      
      negotiateJointVenture: (partnerId, industry) => {
        const { company } = get();
        if (!company) return;
        
        console.log(`Negotiating JV with ${partnerId} in ${industry}`);
      },
      
      applyForLicensing: (patentId) => {
        console.log(`Applying for licensing of ${patentId}`);
      },
      
      startFranchising: (location) => {
        console.log(`Starting franchise in ${location}`);
      },
      
      improveHR: (aspect, amount) => {
        const { company } = get();
        if (!company || !company.hr) return;
        
        set({
          company: {
            ...company,
            hr: {
              ...company.hr,
              [aspect]: Math.min(100, company.hr[aspect] + amount)
            }
          }
        });
      },
      
      upgradeSupplyChain: (upgrade) => {
        const { company } = get();
        if (!company || !company.supplyChain) return;
        
        console.log(`Upgrading supply chain: ${upgrade}`);
      },
      
      conductResearch: (researchId) => {
        console.log(`Conducting research: ${researchId}`);
      },
      
      launchProductLine: (category) => {
        console.log(`Launching product line: ${category}`);
      },
      
      // IPO Actions
      startIPO: (bankType) => {
        const { company } = get();
        if (!company) return;
        
        const auditDuration = bankType === 'premium' ? 15 : 30;
        const fee = bankType === 'premium' ? company.companyValue * 0.07 : company.companyValue * 0.03;
        
        if (company.cash < fee) return;
        
        set({
          ipo: {
            eligible: true,
            listed: false,
            phase: 'preparation',
            sharePrice: company.companyValue / 10000000,
            marketCap: company.companyValue,
            quarterlyProfits: [],
            dividendYield: 0,
            daysInPhase: 0,
            auditDuration,
            bankType,
            underwriters: [],
            prospectusApproved: false,
            roadshowCompleted: false,
            subscriptionRate: 0
          },
          company: {
            ...company,
            cash: company.cash - fee,
          },
        });
      },
      
      advanceIPOPhase: () => {
        const { ipo } = get();
        if (!ipo) return;
        
        const phases: IPOStatus['phase'][] = ['preparation', 'audit', 'pricing', 'offering', 'listed'];
        const currentIndex = phases.indexOf(ipo.phase);
        
        if (currentIndex < phases.length - 1) {
          const nextPhase = phases[currentIndex + 1];
          set({
            ipo: {
              ...ipo,
              phase: nextPhase,
              daysInPhase: 0,
              listed: nextPhase === 'listed',
            },
          });
        }
      },
      
      payDividend: () => {
        const { company, ipo } = get();
        if (!company || !ipo || !ipo.listed) return;
        
        const dividendAmount = company.profit * 0.3;
        
        set({
          ipo: {
            ...ipo,
            quarterlyProfits: [...ipo.quarterlyProfits, dividendAmount],
            dividendYield: (dividendAmount / ipo.marketCap) * 100,
          },
          company: {
            ...company,
            profit: company.profit - dividendAmount,
          },
        });
      },
      
      // Crypto Actions
      startCrypto: (tokenName, tokenSymbol, utility) => {
        set({
          crypto: {
            launched: false,
            listed: false,
            phase: 'research',
            tokenName,
            tokenSymbol,
            tokenPrice: 0.01,
            marketCap: 0,
            utility,
            roadmapProgress: 0,
            daysInPhase: 0,
            milestones: [],
            credibility: 0,
            adoption: 0,
            totalSupply: 1000000000,
            circulatingSupply: 0,
            stakingRewards: 0,
            governance: false,
            partnerships: [],
            auditsCompleted: false,
            exchanges: []
          },
        });
      },
      
      advanceCryptoPhase: () => {
        const { crypto, company } = get();
        if (!crypto || !company) return;
        
        const phases: CryptoProject['phase'][] = ['research', 'development', 'testing', 'ico', 'launched'];
        const currentIndex = phases.indexOf(crypto.phase);
        
        if (currentIndex < phases.length - 1) {
          const nextPhase = phases[currentIndex + 1];
          set({
            crypto: {
              ...crypto,
              phase: nextPhase,
              daysInPhase: 0,
              roadmapProgress: ((currentIndex + 1) / phases.length) * 100,
            },
          });
        }
      },
      
      launchICO: () => {
        const { crypto, company } = get();
        if (!crypto || !company) return;
        
        const raised = 5000000 + Math.random() * 10000000;
        
        set({
          crypto: {
            ...crypto,
            marketCap: raised,
            tokenPrice: 0.5,
            circulatingSupply: raised / 0.5
          },
          company: {
            ...company,
            cash: company.cash + raised,
          },
        });
      },
      
      listCrypto: () => {
        const { crypto, company } = get();
        if (!crypto || !company) return;
        
        set({
          crypto: {
            ...crypto,
            phase: 'listed',
            launched: true,
            tokenPrice: 1.0,
            marketCap: crypto.marketCap * 2,
            roadmapProgress: 100,
          },
          company: {
            ...company,
            cash: company.cash - 5000000,
          },
        });
      },
      
      startMilestone: (milestoneId) => {
        const { crypto } = get();
        if (!crypto) return;
        
        const milestone = crypto.milestones.find(m => m.id === milestoneId);
        if (!milestone) return;
        
        set({
          crypto: {
            ...crypto,
            milestones: crypto.milestones.map(m =>
              m.id === milestoneId
                ? { ...m, status: 'ACTIVE', startDay: get().game.currentDay, progress: 0 }
                : m
            )
          }
        });
      },
      
      updateMilestones: () => {
        const { crypto } = get();
        if (!crypto) return;
        
        const currentDay = get().game.currentDay;
        const updatedMilestones = crypto.milestones.map(milestone => {
          if (milestone.status !== 'ACTIVE') return milestone;
          
          const totalDays = milestone.deadline - (milestone.startDay || currentDay);
          const dailyProgress = 100 / Math.max(totalDays, 1);
          const newProgress = Math.min(100, milestone.progress + dailyProgress);
          
          if (newProgress >= 100) {
            return { ...milestone, status: 'COMPLETED' as const, progress: 100 };
          }
          
          if (currentDay > milestone.deadline) {
            return { ...milestone, status: 'FAILED' as const };
          }
          
          return { ...milestone, progress: newProgress };
        });
        
        set({
          crypto: {
            ...get().crypto!,
            milestones: updatedMilestones
          }
        });
      },
      
      // Advanced Crypto Actions
      listOnExchange: (exchange, liquidity) => {
        console.log(`Listing on ${exchange} with liquidity: ${liquidity}`);
      },
      
      startStaking: (amount, duration) => {
        console.log(`Starting staking: ${amount} for ${duration} days`);
      },
      
      implementGovernance: () => {
        const { crypto } = get();
        if (!crypto) return;
        
        set({
          crypto: {
            ...crypto,
            governance: true
          }
        });
      },
      
      createNFT: (metadata) => {
        console.log('Creating NFT:', metadata);
      },
      
      provideLiquidity: (tokenA, tokenB, amountA, amountB) => {
        console.log(`Providing liquidity: ${amountA} ${tokenA} and ${amountB} ${tokenB}`);
      },
      
      // Marketing Actions
      launchCampaign: (type, budget, targeting) => {
        const { company, game } = get();
        if (!company || company.cash < budget) return;
        
        const campaign: MarketingCampaign = {
          id: `campaign_${Date.now()}`,
          type: type as any,
          cost: budget,
          duration: 30,
          impact: budget / 1000,
          startDay: game.currentDay,
          roi: 0,
          reach: 0,
          engagement: 0,
          brandLifting: 0
        };
        
        set({
          campaigns: [...get().campaigns, campaign],
          company: {
            ...company,
            cash: company.cash - budget,
            brandEquity: Math.min(100, company.brandEquity + (budget / 10000)),
          },
        });
      },
      
      upgradeBrand: () => {
        const { company } = get();
        if (!company || company.cash < 200000 || company.brandEquity >= 100) return;
        
        set({
          company: {
            ...company,
            cash: company.cash - 200000,
            brandEquity: Math.min(100, company.brandEquity + 5),
          },
        });
      },
      
      conductMarketResearch: (focus) => {
        console.log(`Conducting market research on: ${focus}`);
      },
      
      improveSustainability: () => {
        const { company } = get();
        if (!company) return;
        
        set({
          company: {
            ...company,
            sustainabilityScore: Math.min(100, company.sustainabilityScore + 5)
          }
        });
      },
      
      // Business Actions
      improveRelationship: (companyId, amount) => {
        const { company, npcCompanies } = get();
        if (!company || company.cash < amount) return;
        
        const improvement = amount / 10000;
        
        set({
          npcCompanies: npcCompanies.map(npc =>
            npc.id === companyId
              ? { ...npc, relationship: Math.min(100, npc.relationship + improvement) }
              : npc
          ),
          company: {
            ...company,
            cash: company.cash - amount,
          },
        });
      },
      
      signContract: (companyId) => {
        const { npcCompanies, game } = get();
        const npc = npcCompanies.find(c => c.id === companyId);
        
        if (!npc || npc.relationship < 70) return;
        
        const contract: Contract = {
          id: `contract_${Date.now()}`,
          companyId: npc.id,
          companyName: npc.name,
          value: npc.contractValue,
          duration: 90,
          startDay: game.currentDay,
          revenue: npc.contractValue * 0.05,
          completed: false,
          type: 'partnership',
          terms: {}
        };
        
        set({
          contracts: [...get().contracts, contract],
        });
      },
      
      negotiatePricing: (companyId, newTerms) => {
        console.log(`Negotiating pricing with ${companyId}:`, newTerms);
      },
      
      expandInternationally: (region) => {
        const { company } = get();
        if (!company) return;
        
        set({
          company: {
            ...company,
            internationalPresence: Math.min(100, company.internationalPresence + 20)
          }
        });
      },
      
      filePatents: (innovation) => {
        const { company } = get();
        if (!company) return;
        
        set({
          company: {
            ...company,
            ipPortfolio: company.ipPortfolio + 1
          }
        });
      },
      
      // Technical Analysis Actions
      addDrawingTool: (tool) => {
        const newTool: DrawingTool = {
          ...tool,
          id: `tool_${Date.now()}_${Math.random()}`,
          createdAt: Date.now()
        };
        
        set({
          drawingTools: [...get().drawingTools, newTool]
        });
      },
      
      removeDrawingTool: (toolId) => {
        set({
          drawingTools: get().drawingTools.filter(t => t.id !== toolId)
        });
      },
      
      calculateIndicators: (assetId) => {
        console.log(`Calculating indicators for ${assetId}`);
        // Implementation for technical indicators calculation
      },
      
      setAlert: (alert) => {
        const newAlert: Alert = {
          ...alert,
          id: `alert_${Date.now()}_${Math.random()}`,
          createdAt: Date.now()
        };
        
        set({
          alerts: [...get().alerts, newAlert]
        });
      },
      
      removeAlert: (alertId) => {
        set({
          alerts: get().alerts.filter(a => a.id !== alertId)
        });
      },
      
      // UI Actions
      setTheme: (theme) => {
        set({
          settings: {
            ...get().settings,
            theme
          }
        });
      },
      
      setLanguage: (language) => {
        set({
          settings: {
            ...get().settings,
            language
          }
        });
      },
      
      toggleVolume: () => {
        set({
          settings: {
            ...get().settings,
            soundEnabled: !get().settings.soundEnabled
          }
        });
      },
      
      toggleGrid: () => {
        set({
          settings: {
            ...get().settings,
            showGrid: !get().settings.showGrid
          }
        });
      },
      
      setCrosshairSync: (sync) => {
        set({
          settings: {
            ...get().settings,
            crosshairSync: sync
          }
        });
      },
      
      // Data Actions
      loadRealData: async () => {
        try {
          await REAL_DATA_SERVICE.loadMarketData();
          const assets = await REAL_DATA_SERVICE.getAllAssets();
          set({ assets });
          console.log('✅ Real market data loaded');
        } catch (error) {
          console.error('❌ Failed to load real market data:', error);
        }
      },
      
      updateRealTimePrice: async (symbol) => {
        const price = await REAL_DATA_SERVICE.getRealTimePrice(symbol);
        if (price !== null) {
          const { assets } = get();
          const updatedAssets = assets.map(asset =>
            asset.symbol === symbol
              ? { ...asset, currentPrice: price, lastUpdated: Date.now() }
              : asset
          );
          set({ assets: updatedAssets });
        }
      },
      
      calculatePortfolioMetrics: () => {
        const { openTrades } = get();
        
        // Simplified calculation - in real implementation, use more sophisticated formulas
        const totalValue = openTrades.reduce((sum, trade) => sum + (trade.amount * trade.currentPrice), 0);
        const totalPnL = openTrades.reduce((sum, trade) => sum + trade.pnl, 0);
        
        set({
          portfolioMetrics: {
            ...get().portfolioMetrics,
            sharpeRatio: totalPnL / (totalValue * 0.15), // Simplified
            maxDrawdown: 0, // Would need historical data
            beta: 1.0, // Would need market correlation
            alpha: 0, // Would need benchmark comparison
            volatility: 0.15, // Standard assumption
            correlationMatrix: {},
            riskScore: 50,
            diversificationScore: openTrades.length >= 5 ? 75 : 25,
            performanceVsBenchmark: 0
          }
        });
      },
      
      calculateCompanyMetrics: () => {
        const { company } = get();
        if (!company) return;
        
        const roe = company.profit / (company.companyValue - company.cash) * 100;
        const profitMargin = company.revenue > 0 ? (company.profit / company.revenue) * 100 : 0;
        
        set({
          companyMetrics: {
            roe: isNaN(roe) ? 0 : roe,
            roa: 0, // Would need more detailed financial data
            debtToEquity: 0, // Would need debt information
            profitMargin,
            revenueGrowth: 0, // Would need historical data
            assetTurnover: 0, // Would need asset data
            inventoryTurnover: 0, // Would need inventory data
            workingCapital: 0, // Would need balance sheet data
            cashFlowFromOperations: 0, // Would need cash flow data
            returnOnCapitalEmployed: 0 // Would need capital employed data
          }
        });
      },
      
      updateNewsSentiment: () => {
        // Implementation for news sentiment analysis
        set({
          newsSentiment: {
            overall: 0,
            byCategory: {},
            topKeywords: [],
            sourceCredibility: 0,
            marketImpact: 0,
            timeDecay: 0
          }
        });
      },
      
      // Achievement System
      unlockAchievement: (achievementId) => {
        const achievement = SAMPLE_ACHIEVEMENTS.find(a => a.id === achievementId);
        if (!achievement) return;
        
        set({
          player: {
            ...get().player,
            achievements: [...get().player.achievements, achievementId],
            cash: get().player.cash + (achievement.reward || 0),
          },
        });
      },
      
      // Loan System
      takeLoan: (amount, months, collateral) => {
        const interestRate = 0.05 + Math.random() * 0.05; // 5-10%
        const monthlyPayment = (amount * (1 + interestRate)) / months;
        
        const loan: LoanData = {
          amount,
          interestRate,
          remainingPayments: months,
          monthlyPayment,
          takenAt: Date.now(),
          lender: 'Bank of Tycoon',
          collateral
        };
        
        set({
          loans: [...get().loans, loan],
          player: {
            ...get().player,
            cash: get().player.cash + amount,
          },
        });
      },
      
      repayLoan: (loanIndex) => {
        const { loans, player } = get();
        const loan = loans[loanIndex];
        
        if (!loan || player.cash < loan.monthlyPayment) return;
        
        const updatedLoans = [...loans];
        updatedLoans[loanIndex] = {
          ...loan,
          remainingPayments: loan.remainingPayments - 1,
        };
        
        set({
          loans: updatedLoans.filter(l => l.remainingPayments > 0),
          player: {
            ...player,
            cash: player.cash - loan.monthlyPayment,
          },
        });
      },
      
      requestAnalysis: (assetId) => {
        const { player, assets } = get();
        const asset = assets.find(a => a.id === assetId);
        
        if (!asset || player.cash < 35000) return;
        
        const report: AnalystReport = {
          assetId,
          analysis: `Based on technical analysis, ${asset.name} is showing ${Math.random() > 0.5 ? 'bullish' : 'bearish'} signals.`,
          recommendation: Math.random() > 0.5 ? 'buy' : 'sell',
          targetPrice: asset.currentPrice * (1 + (Math.random() - 0.5) * 0.2),
          accuracy: 0.6,
          generatedAt: Date.now(),
          priceTargets: {
            short: asset.currentPrice * 0.95,
            medium: asset.currentPrice,
            long: asset.currentPrice * 1.1
          },
          riskLevel: 'medium',
          keyFactors: ['Market sentiment', 'Technical indicators', 'Fundamental analysis']
        };
        
        set({
          analystReports: [...get().analystReports, report],
          player: {
            ...player,
            cash: player.cash - 35000,
          },
        });
      },
      
      // Game Management
      saveGame: () => {
        console.log('Game saved automatically');
      },
      
      loadGame: (savedState) => {
        set(savedState);
      },
      
      resetGame: () => {
        set({
          game: {
            isRunning: false,
            isPaused: false,
            currentDay: 1,
            ticksInDay: 0,
            secondsRemaining: 90,
            totalDays: 0,
            timeScale: 1
          },
          player: {
            cash: 100000,
            totalAssets: 0,
            totalValue: 100000,
            dailyPnL: 0,
            totalPnL: 0,
            startingCapital: 100000,
            country: '',
            level: 1,
            experience: 0,
            achievements: [],
            reputation: 50
          },
          settings: DEFAULT_SETTINGS,
          assets: [],
          selectedAsset: null,
          realTimeData: {},
          technicalIndicators: {},
          drawingTools: [],
          openTrades: [],
          closedTrades: [],
          pendingOrders: [],
          portfolioMetrics: {
            sharpeRatio: 0,
            maxDrawdown: 0,
            beta: 0,
            alpha: 0,
            volatility: 0,
            correlationMatrix: {},
            riskScore: 50,
            diversificationScore: 50,
            performanceVsBenchmark: 0
          },
          activeNews: [],
          newsHistory: [],
          newsSentiment: null,
          company: null,
          companyMetrics: null,
          techTree: [],
          campaigns: [],
          supplyChain: null,
          hr: null,
          ipo: null,
          crypto: null,
          npcCompanies: SAMPLE_NPC_COMPANIES,
          contracts: [],
          alerts: [],
          selectedTimeframe: '1h',
          selectedChartType: 'candlestick'
        });
      },
      
      exportGameData: () => {
        const state = get();
        return JSON.stringify({
          game: state.game,
          player: state.player,
          settings: state.settings,
          company: state.company,
          crypto: state.crypto,
          ipo: state.ipo,
          campaigns: state.campaigns,
          contracts: state.contracts,
          loans: state.loans,
          analystReports: state.analystReports
        }, null, 2);
      },
      
      importGameData: (data) => {
        try {
          const savedState = JSON.parse(data);
          get().loadGame(savedState);
          console.log('Game data imported successfully');
        } catch (error) {
          console.error('Failed to import game data:', error);
        }
      }
    }),
    {
      name: 'tycoon-simulator-v3-storage',
      partialize: (state) => ({
        game: state.game,
        player: state.player,
        settings: state.settings,
        company: state.company,
        crypto: state.crypto,
        ipo: state.ipo,
        campaigns: state.campaigns,
        contracts: state.contracts,
        loans: state.loans,
        analystReports: state.analystReports,
        selectedTimeframe: state.selectedTimeframe,
        selectedChartType: state.selectedChartType
      })
    }
  )
);

export const useGameStoreV3 = useGameStore;

export default useGameStore;
