/** @type {import('tailwindcss').Config} */
module.exports = {
	darkMode: ['class'],
	content: [
		'./pages/**/*.{ts,tsx}',
		'./components/**/*.{ts,tsx}',
		'./app/**/*.{ts,tsx}',
		'./src/**/*.{ts,tsx}',
	],
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px',
			},
		},
		extend: {
			colors: {
				// پس‌زمینه‌ها
				'bg-primary': 'var(--bg-primary)',
				'bg-secondary': 'var(--bg-secondary)',
				'bg-tertiary': 'var(--bg-tertiary)',
				'bg-elevated': 'var(--bg-elevated)',

				// لهجه‌های اصلی
				gold: {
					DEFAULT: 'var(--accent-gold)',
					light: 'var(--accent-gold-light)',
					dark: 'var(--accent-gold-dark)',
				},
				blue: {
					DEFAULT: 'var(--accent-blue)',
					light: 'var(--accent-blue-light)',
					dark: 'var(--accent-blue-dark)',
				},

				// رنگ‌های عملکردی
				success: {
					DEFAULT: 'var(--success)',
					light: 'var(--success-light)',
					dark: 'var(--success-dark)',
					bg: 'var(--success-bg)',
				},
				danger: {
					DEFAULT: 'var(--danger)',
					light: 'var(--danger-light)',
					dark: 'var(--danger-dark)',
					bg: 'var(--danger-bg)',
				},
				warning: {
					DEFAULT: 'var(--warning)',
					light: 'var(--warning-light)',
					dark: 'var(--warning-dark)',
					bg: 'var(--warning-bg)',
				},
				info: {
					DEFAULT: 'var(--info)',
					light: 'var(--info-light)',
					dark: 'var(--info-dark)',
					bg: 'var(--info-bg)',
				},

				// رنگ‌های متن
				'text-primary': 'var(--text-primary)',
				'text-secondary': 'var(--text-secondary)',
				'text-tertiary': 'var(--text-tertiary)',
				'text-disabled': 'var(--text-disabled)',

				// رنگ‌های مرز
				'border-primary': 'var(--border-primary)',
				'border-secondary': 'var(--border-secondary)',
				'border-focus': 'var(--border-focus)',

				// سازگاری با کامپوننت‌های قدیمی
				border: 'var(--border-primary)',
				input: 'var(--bg-tertiary)',
				ring: 'var(--accent-gold)',
				background: 'var(--bg-primary)',
				foreground: 'var(--text-primary)',
				primary: {
					DEFAULT: 'var(--accent-gold)',
					foreground: 'var(--bg-primary)',
				},
				secondary: {
					DEFAULT: 'var(--accent-blue)',
					foreground: 'var(--text-primary)',
				},
				accent: {
					DEFAULT: 'var(--accent-gold)',
					foreground: 'var(--bg-primary)',
				},
				destructive: {
					DEFAULT: 'var(--danger)',
					foreground: 'var(--text-primary)',
				},
				muted: {
					DEFAULT: 'var(--bg-secondary)',
					foreground: 'var(--text-secondary)',
				},
				popover: {
					DEFAULT: 'var(--bg-elevated)',
					foreground: 'var(--text-primary)',
				},
				card: {
					DEFAULT: 'var(--bg-secondary)',
					foreground: 'var(--text-primary)',
				},
			},
			fontFamily: {
				'primary-fa': 'var(--font-primary-fa)',
				'numbers-fa': 'var(--font-numbers-fa)',
				'heading-fa': 'var(--font-heading-fa)',
				'primary-en': 'var(--font-primary-en)',
				'numbers-en': 'var(--font-numbers-en)',
				'heading-en': 'var(--font-heading-en)',
				// Aliases
				sans: 'var(--font-primary-fa)',
				numbers: 'var(--font-numbers-fa)',
				heading: 'var(--font-heading-fa)',
			},
			fontSize: {
				xs: 'var(--text-xs)',
				sm: 'var(--text-sm)',
				base: 'var(--text-base)',
				lg: 'var(--text-lg)',
				xl: 'var(--text-xl)',
				'2xl': 'var(--text-2xl)',
				'3xl': 'var(--text-3xl)',
				'4xl': 'var(--text-4xl)',
				'5xl': 'var(--text-5xl)',
			},
			spacing: {
				0: 'var(--space-0)',
				1: 'var(--space-1)',
				2: 'var(--space-2)',
				3: 'var(--space-3)',
				4: 'var(--space-4)',
				5: 'var(--space-5)',
				6: 'var(--space-6)',
				8: 'var(--space-8)',
				10: 'var(--space-10)',
				12: 'var(--space-12)',
				16: 'var(--space-16)',
				20: 'var(--space-20)',
			},
			borderRadius: {
				sm: 'var(--radius-sm)',
				md: 'var(--radius-md)',
				lg: 'var(--radius-lg)',
				xl: 'var(--radius-xl)',
				'2xl': 'var(--radius-2xl)',
				full: 'var(--radius-full)',
			},
			boxShadow: {
				sm: 'var(--shadow-sm)',
				md: 'var(--shadow-md)',
				lg: 'var(--shadow-lg)',
				xl: 'var(--shadow-xl)',
				'2xl': 'var(--shadow-2xl)',
				gold: 'var(--shadow-gold)',
				'gold-lg': 'var(--shadow-gold-lg)',
			},
			transitionDuration: {
				fast: 'var(--duration-fast)',
				normal: 'var(--duration-normal)',
				slow: 'var(--duration-slow)',
				slower: 'var(--duration-slower)',
			},
			transitionTimingFunction: {
				'in': 'var(--ease-in)',
				'out': 'var(--ease-out)',
				'in-out': 'var(--ease-in-out)',
				'bounce': 'var(--ease-bounce)',
			},
			keyframes: {
				'fade-in': {
					from: { opacity: '0' },
					to: { opacity: '1' },
				},
				'slide-up': {
					from: { opacity: '0', transform: 'translateY(20px)' },
					to: { opacity: '1', transform: 'translateY(0)' },
				},
				'slide-down': {
					from: { opacity: '0', transform: 'translateY(-20px)' },
					to: { opacity: '1', transform: 'translateY(0)' },
				},
				'slide-right': {
					from: { opacity: '0', transform: 'translateX(-20px)' },
					to: { opacity: '1', transform: 'translateX(0)' },
				},
				'slide-left': {
					from: { opacity: '0', transform: 'translateX(20px)' },
					to: { opacity: '1', transform: 'translateX(0)' },
				},
				'scale-in': {
					from: { opacity: '0', transform: 'scale(0.9)' },
					to: { opacity: '1', transform: 'scale(1)' },
				},
				pulse: {
					'0%, 100%': { opacity: '1', transform: 'scale(1)' },
					'50%': { opacity: '0.8', transform: 'scale(1.05)' },
				},
				'pulse-glow': {
					'0%, 100%': { opacity: '1', boxShadow: '0 0 10px rgba(255, 184, 0, 0.3)' },
					'50%': { opacity: '0.9', boxShadow: '0 0 25px rgba(255, 184, 0, 0.6)' },
				},
				shimmer: {
					'0%': { backgroundPosition: '-1000px 0' },
					'100%': { backgroundPosition: '1000px 0' },
				},
				bounce: {
					'0%, 100%': { transform: 'translateY(0)' },
					'50%': { transform: 'translateY(-10px)' },
				},
				spin: {
					from: { transform: 'rotate(0deg)' },
					to: { transform: 'rotate(360deg)' },
				},
				'scroll-ticker': {
					'0%': { transform: 'translateX(0)' },
					'100%': { transform: 'translateX(-50%)' },
				},
			},
			animation: {
				'fade-in': 'fade-in var(--duration-normal) var(--ease-out)',
				'slide-up': 'slide-up var(--duration-normal) var(--ease-out)',
				'slide-down': 'slide-down var(--duration-normal) var(--ease-out)',
				'slide-right': 'slide-right var(--duration-normal) var(--ease-out)',
				'slide-left': 'slide-left var(--duration-normal) var(--ease-out)',
				'scale-in': 'scale-in var(--duration-normal) var(--ease-out)',
				pulse: 'pulse 2s var(--ease-in-out) infinite',
				'pulse-glow': 'pulse-glow 2s var(--ease-in-out) infinite',
				shimmer: 'shimmer 2s linear infinite',
				bounce: 'bounce 1s var(--ease-in-out) infinite',
				spin: 'spin 1s linear infinite',
				'scroll-ticker': 'scroll-ticker 30s linear infinite',
			},
			backdropBlur: {
				glass: 'var(--glass-blur)',
			},
		},
	},
	plugins: [require('tailwindcss-animate')],
}
