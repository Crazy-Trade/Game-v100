پیاده‌سازی مستقیم toast notification با استفاده از Radix UI Toast که قبلاً نصب شده است:

1. استفاده از @radix-ui/react-toast به جای react-hot-toast
2. ساخت یک کامپوننت Toast سفارشی
